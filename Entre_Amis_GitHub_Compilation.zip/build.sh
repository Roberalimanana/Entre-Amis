#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

sdk=${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}
build_tools=${ANDROID_BUILD_TOOLS:-${sdk:+$sdk/build-tools/35.0.0}}
android_jar=${ANDROID_JAR:-${sdk:+$sdk/platforms/android-35/android.jar}}
compiler=${JAVAC_BIN:-javac}
if [ ! -x "$build_tools/aapt2" ] || [ ! -f "$android_jar" ]; then
    echo "Indique ANDROID_SDK_ROOT ou ANDROID_BUILD_TOOLS et ANDROID_JAR." >&2
    exit 1
fi

tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp"/{gen,classes,dex} dist
"$build_tools/aapt2" compile --dir app/res -o "$tmp/resources.zip"
"$build_tools/aapt2" link -I "$android_jar" --manifest app/AndroidManifest.xml -A app/assets \
    --custom-package fr.entreamis.chat \
    --java "$tmp/gen" -o "$tmp/unsigned.apk" "$tmp/resources.zip"
mapfile -t sources < <(find app/src "$tmp/gen" -name '*.java' -type f)
"$compiler" -source 8 -target 8 -Xlint:-options -encoding UTF-8 -classpath "$android_jar" \
    -d "$tmp/classes" "${sources[@]}"
(cd "$tmp/classes" && zip -q -r "$tmp/classes.jar" .)
java -cp "$build_tools/lib/d8.jar" com.android.tools.r8.D8 --release --min-api 26 \
    --lib "$android_jar" --output "$tmp/dex" "$tmp/classes.jar"
(cd "$tmp/dex" && zip -q "$tmp/unsigned.apk" classes.dex)
"$build_tools/zipalign" -f 4 "$tmp/unsigned.apk" "$tmp/aligned.apk"

if [ -n "${ENTRE_AMIS_SIGNING_STORE:-}" ] && [ -n "${ENTRE_AMIS_PASSWORD_FILE:-}" ]; then
    signed="$tmp/Entre_Amis.apk"
    "$build_tools/apksigner" sign --ks "$ENTRE_AMIS_SIGNING_STORE" \
        --ks-key-alias entre-amis --ks-pass "file:$ENTRE_AMIS_PASSWORD_FILE" --out "$signed" "$tmp/aligned.apk"
    if [ -n "${ENTRE_AMIS_PREVIOUS_APK:-}" ]; then
        certificate() {
            "$build_tools/apksigner" verify --print-certs "$1" |
                awk -F': ' '/certificate SHA-256 digest:/ {print $2}'
        }
        before=$(certificate "$ENTRE_AMIS_PREVIOUS_APK")
        after=$(certificate "$signed")
        if [ -z "$before" ] || [ "$before" != "$after" ]; then
            echo "Certificat différent de celui de l’APK livré." >&2
            exit 1
        fi
    fi
    "$build_tools/apksigner" verify --verbose "$signed"
    cp "$signed" dist/Entre_Amis.apk
else
    cp "$tmp/aligned.apk" dist/Entre_Amis_NonSigne.apk
fi
(cd relay && zip -q -r "$tmp/Entre_Amis_Relais_Eclipse.zip" entre-amis-relais)
cp "$tmp/Entre_Amis_Relais_Eclipse.zip" dist/
