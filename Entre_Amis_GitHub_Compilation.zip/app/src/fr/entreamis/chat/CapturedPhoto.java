package fr.entreamis.chat;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

final class CapturedPhoto {
    static byte[] jpeg(File photo) throws IOException {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(photo.getPath(), options);
        if (options.outWidth <= 0 || options.outHeight <= 0) throw new IOException("Photo invalide");
        int maximum = Math.max(options.outWidth, options.outHeight);
        options.inJustDecodeBounds = false;
        options.inSampleSize = 1;
        while (maximum / options.inSampleSize > 1600) options.inSampleSize *= 2;
        Bitmap decoded = BitmapFactory.decodeFile(photo.getPath(), options);
        if (decoded == null) throw new IOException("Photo invalide");
        Bitmap bitmap = decoded;
        try {
            Matrix orientation = orientation(photo);
            if (!orientation.isIdentity()) {
                bitmap = Bitmap.createBitmap(decoded, 0, 0, decoded.getWidth(), decoded.getHeight(), orientation, true);
            }
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            for (int quality : new int[]{86, 70, 54, 38}) {
                output.reset();
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, quality, output)) throw new IOException("Photo invalide");
                if (output.size() <= Attachment.MAX_SIZE) return output.toByteArray();
            }
            throw new IOException("Photo trop grande");
        } finally {
            if (bitmap != decoded) bitmap.recycle();
            decoded.recycle();
        }
    }

    private static Matrix orientation(File photo) throws IOException {
        ExifInterface exif = new ExifInterface(photo.getPath());
        Matrix matrix = new Matrix();
        switch (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: matrix.setScale(-1, 1); break;
            case ExifInterface.ORIENTATION_ROTATE_180: matrix.setRotate(180); break;
            case ExifInterface.ORIENTATION_FLIP_VERTICAL: matrix.setScale(1, -1); break;
            case ExifInterface.ORIENTATION_TRANSPOSE: matrix.setRotate(90); matrix.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_ROTATE_90: matrix.setRotate(90); break;
            case ExifInterface.ORIENTATION_TRANSVERSE: matrix.setRotate(270); matrix.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_ROTATE_270: matrix.setRotate(270); break;
            default: break;
        }
        return matrix;
    }
}
