package fr.entreamis.chat;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class UnlockActivity extends Activity {
    private static final ExecutorService PASSWORD_WORKER = Executors.newSingleThreadExecutor();
    private static final String CALL = "incomingCall";
    private static final String CHANGE = "changePassword";

    private AppLock lock;
    private AppPassword passwords;
    private boolean creating;
    private boolean changing;
    private boolean resumed;
    private boolean busy;
    private EditText current;
    private EditText next;
    private EditText confirm;
    private Button submit;
    private TextView feedback;

    static Intent forCall(Context context, String call) {
        return new Intent(context, UnlockActivity.class).putExtra(CALL, call)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    }

    static Intent forChange(Context context) {
        return new Intent(context, UnlockActivity.class).putExtra(CHANGE, true);
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        lock = AppLock.of(this);
        passwords = new AppPassword(getSharedPreferences("entre_amis_lock", MODE_PRIVATE));
        changing = getIntent().getBooleanExtra(CHANGE, false) && lock.isUnlocked();
        if (RoomAlertService.incomingCall(getIntent().getStringExtra(CALL)) != null) {
            AppLock.showOverSwipeLock(this);
        }
        if (changing || !lock.isUnlocked()) showForm();
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        if (changing && !lock.isUnlocked()) {
            changing = false;
            showForm();
        }
        if (!changing && lock.isUnlocked()) open();
        else if (creating == passwords.configured() && !busy) showForm();
    }

    @Override protected void onPause() {
        resumed = false;
        clearFields();
        super.onPause();
    }

    @Override public void onUserInteraction() {
        super.onUserInteraction();
        if (changing) lock.touch();
    }

    private void showForm() {
        creating = !passwords.configured();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_VERTICAL);
        int padding = Math.round(24 * getResources().getDisplayMetrics().density);
        content.setPadding(padding, padding, padding, padding);
        content.setFocusableInTouchMode(true);
        scroll.addView(content);
        TextView title = new TextView(this);
        title.setText(creating ? "Créer le mot de passe"
                : changing ? "Changer le mot de passe" : "Entre Amis verrouillé");
        title.setTextSize(24);
        content.addView(title);

        current = creating ? null : passwordField(content, changing ? "Mot de passe actuel" : "Mot de passe");
        next = creating || changing ? passwordField(content, "Nouveau mot de passe (8 caractères minimum)") : null;
        confirm = next == null ? null : passwordField(content, "Confirmer le nouveau mot de passe");
        feedback = new TextView(this);
        if (creating) feedback.setText("Choisis un mot de passe personnel. Conserve-le pour pouvoir rouvrir tes conversations.");
        content.addView(feedback);
        submit = new Button(this);
        submit.setText(creating || changing ? "Enregistrer" : "Déverrouiller");
        submit.setOnClickListener(view -> checkPassword());
        content.addView(submit);
        setContentView(scroll);
        content.requestFocus();
    }

    private EditText passwordField(LinearLayout content, String hint) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setSingleLine(true);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        field.setSaveEnabled(false);
        field.setImportantForAutofill(EditText.IMPORTANT_FOR_AUTOFILL_NO);
        field.setFilters(new InputFilter[]{new InputFilter.LengthFilter(128)});
        content.addView(field);
        return field;
    }

    private void checkPassword() {
        if (busy) return;
        if (changing && !lock.isUnlocked()) {
            changing = false;
            showForm();
            return;
        }
        char[] entered = password(current);
        char[] replacement = password(next);
        char[] confirmation = password(confirm);
        if (entered != null && entered.length == 0) {
            feedback.setText("Saisis le mot de passe.");
        } else if (replacement != null && replacement.length < AppPassword.MIN_LENGTH) {
            feedback.setText("Choisis au moins 8 caractères.");
        } else if (!Arrays.equals(replacement, confirmation)) {
            feedback.setText("Les deux nouveaux mots de passe diffèrent.");
        } else {
            verify(entered, replacement);
            wipe(confirmation);
            return;
        }
        wipe(entered);
        wipe(replacement);
        wipe(confirmation);
    }

    private void verify(char[] entered, char[] replacement) {
        busy = true;
        submit.setEnabled(false);
        feedback.setText("Vérification…");
        boolean first = creating;
        long generation = lock.generation();
        clearFields();
        PASSWORD_WORKER.execute(() -> {
            String result;
            try {
                result = passwords.submit(entered, replacement, first, System.currentTimeMillis());
            } catch (GeneralSecurityException | IllegalArgumentException error) {
                result = "Impossible de vérifier ou d’enregistrer le mot de passe.";
            } finally {
                wipe(entered);
                wipe(replacement);
            }
            String message = result;
            runOnUiThread(() -> checked(message, generation));
        });
    }

    private void checked(String message, long generation) {
        if (isFinishing() || isDestroyed()) return;
        busy = false;
        submit.setEnabled(true);
        feedback.setText(message == null ? "" : message);
        if (!resumed || lock.generation() != generation) {
            if (resumed && (creating == passwords.configured() || changing && !lock.isUnlocked())) {
                changing = false;
                showForm();
            }
            return;
        }
        if (message != null) return;
        lock.unlock();
        if (changing) finish();
        else open();
    }

    private void open() {
        String call = getIntent().getStringExtra(CALL);
        RoomAlertService.Invitation incoming = RoomAlertService.incomingCall(call);
        if (incoming == null) {
            if (call != null) Toast.makeText(this, "Cette invitation a expiré.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        } else {
            SharedPreferences preferences = getSharedPreferences(MainActivity.PREFERENCES, MODE_PRIVATE);
            String device = preferences.getString("device", "");
            String name = preferences.getString("nickname", "");
            RoomAlertService.dismissCall(call);
            startActivity(CallActivity.intent(this, incoming.room, device, name,
                    incoming.signal.kind.substring(5), incoming.signal)
                    .putExtra(CallActivity.FROM_LOCK_ALERT, true));
        }
        finish();
    }

    private void clearFields() {
        if (current != null) current.getText().clear();
        if (next != null) next.getText().clear();
        if (confirm != null) confirm.getText().clear();
    }

    private static char[] password(EditText field) {
        if (field == null) return null;
        Editable value = field.getText();
        char[] password = new char[value.length()];
        value.getChars(0, value.length(), password, 0);
        return password;
    }

    private static void wipe(char[] value) {
        if (value != null) Arrays.fill(value, '\0');
    }
}
