package fr.entreamis.chat;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class CallAlertActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable checkCall = this::checkCall;
    private String call;
    private Button join;
    private boolean unlocking;

    static Intent intent(Context context, String call) {
        return new Intent(context, CallAlertActivity.class)
                .setData(new Uri.Builder().scheme("entreamis").authority("appel").appendPath(call).build())
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        showCall(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        showCall(intent);
    }

    private void showCall(Intent intent) {
        ui.removeCallbacks(checkCall);
        unlocking = false;
        call = intent.getData() == null ? null : intent.getData().getLastPathSegment();
        RoomAlertService.Invitation incoming = RoomAlertService.incomingCall(call);
        if (incoming == null) {
            finish();
            return;
        }
        if (Build.VERSION.SDK_INT < 27) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);
        int padding = Math.round(24 * getResources().getDisplayMetrics().density);
        content.setPadding(padding, padding, padding, padding);
        TextView title = new TextView(this);
        title.setText("ring-meeting".equals(incoming.signal.kind) ? "Invitation à une réunion"
                : CallActivity.title(incoming.signal.kind.substring(5)) + " entrant");
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        content.addView(title, new LinearLayout.LayoutParams(-1, -2));

        join = new Button(this);
        join.setText("Rejoindre");
        join.setOnClickListener(view -> answer());
        content.addView(join, new LinearLayout.LayoutParams(-1, -2));
        Button decline = new Button(this);
        decline.setText("Refuser");
        decline.setOnClickListener(view -> {
            RoomAlertService.rejectCall(call);
            finish();
        });
        content.addView(decline, new LinearLayout.LayoutParams(-1, -2));
        setContentView(content);
        checkCall();
    }

    private void checkCall() {
        RoomAlertService.Invitation incoming = RoomAlertService.incomingCall(call);
        if (incoming == null) finish();
        else if (unlocking && !getSystemService(KeyguardManager.class).isDeviceLocked()) openCall();
        else ui.postDelayed(checkCall, Math.min(1000, incoming.remaining()));
    }

    private void answer() {
        KeyguardManager keyguard = getSystemService(KeyguardManager.class);
        String requested = call;
        if (keyguard.isDeviceLocked()) {
            unlocking = true;
            join.setEnabled(false);
            keyguard.requestDismissKeyguard(this, new KeyguardManager.KeyguardDismissCallback() {
                @Override public void onDismissSucceeded() {
                    if (isCurrentAnswer()) openCall();
                }
                @Override public void onDismissCancelled() { resetAnswer(); }
                @Override public void onDismissError() { resetAnswer(); }

                private boolean isCurrentAnswer() {
                    return unlocking && !isFinishing() && !isDestroyed() && requested.equals(call);
                }

                private void resetAnswer() {
                    if (!isCurrentAnswer()) return;
                    unlocking = false;
                    join.setEnabled(true);
                }
            });
        } else {
            openCall();
        }
    }

    private void openCall() {
        unlocking = false;
        ui.removeCallbacks(checkCall);
        if (RoomAlertService.incomingCall(call) != null) startActivity(UnlockActivity.forCall(this, call));
        finish();
    }

    @Override protected void onDestroy() {
        ui.removeCallbacks(checkCall);
        super.onDestroy();
    }
}
