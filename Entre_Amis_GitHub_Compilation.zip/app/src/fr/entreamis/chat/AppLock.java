package fr.entreamis.chat;

import android.app.Activity;
import android.app.Application;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public final class AppLock extends Application {
    static final long IDLE_MS = 120_000;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Set<ProtectedActivity> screens = new HashSet<>();
    private final Runnable checkIdle = this::checkIdle;
    private long deadline;
    private long generation;
    private CallActivity foregroundCall;

    @Override public void onCreate() {
        super.onCreate();
        BroadcastReceiver screenOff = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) { lock(); }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenOff, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(screenOff, filter);
    }

    static AppLock of(Activity activity) { return (AppLock) activity.getApplication(); }

    static void showOverSwipeLock(Activity activity) {
        KeyguardManager keyguard = activity.getSystemService(KeyguardManager.class);
        if (!keyguard.isKeyguardLocked() || keyguard.isDeviceSecure()) return;
        if (Build.VERSION.SDK_INT >= 27) activity.setShowWhenLocked(true);
        else activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
    }

    void register(ProtectedActivity screen) { screens.add(screen); }

    void unregister(ProtectedActivity screen) { screens.remove(screen); }

    long generation() { return generation; }

    boolean isUnlocked() {
        return deadline != 0 && (foregroundCall != null || SystemClock.elapsedRealtime() < deadline);
    }

    void unlock() { resetDeadline(); }

    void touch() {
        if (isUnlocked()) resetDeadline();
    }

    void callResumed(CallActivity call) {
        foregroundCall = call;
        touch();
    }

    void callPaused(CallActivity call) {
        if (foregroundCall != call) return;
        touch();
        foregroundCall = null;
    }

    private void resetDeadline() {
        deadline = SystemClock.elapsedRealtime() + IDLE_MS;
        ui.removeCallbacks(checkIdle);
        ui.postDelayed(checkIdle, IDLE_MS);
    }

    private void checkIdle() {
        if (foregroundCall != null) return;
        long remaining = deadline - SystemClock.elapsedRealtime();
        if (remaining > 0) ui.postDelayed(checkIdle, remaining);
        else lock();
    }

    private void lock() {
        generation++;
        deadline = 0;
        foregroundCall = null;
        ui.removeCallbacks(checkIdle);
        for (ProtectedActivity screen : new ArrayList<>(screens)) screen.closeForLock();
    }
}
