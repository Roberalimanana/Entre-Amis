package fr.entreamis.chat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class RoomAlertService extends Service implements CallChannel.Listener {
    static final String ENABLED = "room_alerts";
    private static final String STOP = "fr.entreamis.chat.STOP_ALERTS";
    private static final String SERVICE_CHANNEL = "room_monitor";
    private static final String MESSAGE_CHANNEL = "room_messages";
    private static final String CALL_CHANNEL = "room_calls";
    private static final int MONITOR = 31;
    private static final int MESSAGE = 32;
    private static final int CALL = 33;
    private static volatile boolean chatVisible;
    private static volatile boolean callVisible;
    private static RoomAlertService active;
    private static String rejectedCall;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Relay relay = new Relay(Relay.ECLIPSE);
    private SharedPreferences preferences;
    private NotificationManager notifications;
    private Room room;
    private CallChannel calls;
    private Thread messages;
    private Invitation pending;
    private String lastAlertedCall;

    static final class Invitation {
        final Room room;
        final CallChannel.Signal signal;
        final long expiresAt;

        Invitation(Room room, CallChannel.Signal signal, long remaining) {
            this.room = room;
            this.signal = signal;
            this.expiresAt = SystemClock.elapsedRealtime() + remaining;
        }

        long remaining() { return expiresAt - SystemClock.elapsedRealtime(); }
    }

    static void setChatVisible(boolean visible) {
        chatVisible = visible;
        if (visible && active != null) {
            active.notifications.cancel(MESSAGE);
            active.notifications.cancel(CALL);
        }
    }

    static void setCallVisible(boolean visible) {
        callVisible = visible;
    }

    static CallChannel.Signal takeCall(Room room) {
        if (active == null || active.pending == null || !active.pending.room.topic.equals(room.topic)
                || !MainActivity.contactAllowed(active.preferences, room)) return null;
        Invitation invitation = active.pending;
        CallChannel.Signal call = invitation.signal;
        long remaining = invitation.remaining();
        dismissCall(call.call);
        if (remaining <= 0) return null;
        return new CallChannel.Signal(call.call, call.sender, call.kind, call.data, 30 - (remaining + 999) / 1000);
    }

    static Invitation incomingCall(String call) {
        if (active == null || active.pending == null || !active.pending.signal.call.equals(call)
                || active.pending.remaining() <= 0
                || !MainActivity.contactAllowed(active.preferences, active.pending.room)) return null;
        return active.pending;
    }

    static void dismissCall(String call) {
        if (active != null && active.pending != null && active.pending.signal.call.equals(call)) {
            active.pending = null;
            active.notifications.cancel(CALL);
        }
    }

    static void rejectCall(String call) {
        rejectedCall = call;
        dismissCall(call);
    }

    static boolean wasRejected(String call) { return call.equals(rejectedCall); }

    @Override public void onCreate() {
        super.onCreate();
        preferences = getSharedPreferences(MainActivity.PREFERENCES, MODE_PRIVATE);
        notifications = getSystemService(NotificationManager.class);
        notifications.createNotificationChannel(new NotificationChannel(SERVICE_CHANNEL, "Réception en arrière-plan", NotificationManager.IMPORTANCE_LOW));
        notifications.createNotificationChannel(new NotificationChannel(MESSAGE_CHANNEL, "Nouveaux messages", NotificationManager.IMPORTANCE_DEFAULT));
        notifications.createNotificationChannel(new NotificationChannel(CALL_CHANNEL, "Appels entrants", NotificationManager.IMPORTANCE_HIGH));
        active = this;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) {
            preferences.edit().putBoolean(ENABLED, false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            String code = preferences.getString("room", "");
            String device = preferences.getString("device", "");
            if (!preferences.getBoolean(ENABLED, false) || !notifications.areNotificationsEnabled()
                    || code.isEmpty() || device.isEmpty()) {
                stopSelf();
                return START_NOT_STICKY;
            }
            if (room != null && room.invite.equals(code)) {
                if (!MainActivity.contactAllowed(preferences, room)) stopSelf();
                return START_NOT_STICKY;
            }
            stopWatchers();
            room = Room.join(code);
            if (!MainActivity.contactAllowed(preferences, room)) {
                stopSelf();
                return START_NOT_STICKY;
            }
            PendingIntent stop = PendingIntent.getService(this, MONITOR,
                    new Intent(this, RoomAlertService.class).setAction(STOP), PendingIntent.FLAG_IMMUTABLE);
            startForeground(MONITOR, notice(SERVICE_CHANNEL, getString(R.string.app_name),
                    "Surveillance du salon ouvert").setOngoing(true).setOnlyAlertOnce(true)
                    .addAction(new Notification.Action.Builder(null, "Arrêter", stop).build()).build());
            calls = new CallChannel(relay, room, device, "", 0, ui, this);
            calls.start();
            Room destination = room;
            messages = new Thread(() -> watchMessages(destination, device), "EntreAmis-notifications");
            messages.start();
        } catch (GeneralSecurityException | IllegalArgumentException | SecurityException | IllegalStateException failure) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private Notification.Builder notice(String channel, String title, String detail) {
        Intent open = new Intent(this, UnlockActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, channel).setSmallIcon(R.drawable.notification_icon)
                .setContentTitle(title).setContentText(detail).setContentIntent(tap)
                .setVisibility(Notification.VISIBILITY_PRIVATE);
    }

    private void watchMessages(Room destination, String device) {
        Thread worker = Thread.currentThread();
        String cursorKey = "alert_cursor_" + destination.topic;
        long delay = 0;
        try (History history = new History(getApplicationContext())) {
            long cursor = preferences.getLong(cursorKey, 0);
            while (!worker.isInterrupted()) {
                Thread.sleep(delay);
                if (!MainActivity.contactAllowed(preferences, destination)) return;
                try {
                    cursor = Math.max(cursor, history.lastId(destination.topic));
                    JSONObject page = new JSONObject(relay.poll(destination, cursor));
                    if (worker.isInterrupted() || !MainActivity.contactAllowed(preferences, destination)) return;
                    JSONArray rows = page.getJSONArray("messages");
                    boolean unread = false;
                    for (int i = 0; i < rows.length(); i++) {
                        JSONObject row = rows.getJSONObject(i);
                        long id = row.getLong("id");
                        if (id <= cursor) continue;
                        cursor = id;
                        if (!chatVisible && !callVisible && remoteMessage(destination, device, row)) unread = true;
                    }
                    if (rows.length() > 0) preferences.edit().putLong(cursorKey, cursor).apply();
                    if (unread) ui.post(() -> {
                        if (messages == worker && !chatVisible && !callVisible
                                && MainActivity.contactAllowed(preferences, destination)) {
                            notifications.notify(MESSAGE, notice(MESSAGE_CHANNEL, "Nouveau message",
                                    "Ouvre Entre Amis pour le lire.").setAutoCancel(true).build());
                        }
                    });
                    delay = page.optBoolean("more") ? 750 : 8500;
                } catch (IOException | JSONException failure) {
                    long retry = failure instanceof Relay.HttpError ? ((Relay.HttpError) failure).retryMs : 0;
                    delay = Math.max(15000, retry);
                }
            }
        } catch (InterruptedException stopped) {
            worker.interrupt();
        }
    }

    private static boolean remoteMessage(Room room, String device, JSONObject row) {
        String action = row.optString("action_type", "");
        if ("edit".equals(action) || "delete".equals(action)) return false;
        try {
            JSONObject message = new JSONObject(room.decrypt(row.getString("payload")));
            String sender = message.getString("device");
            return sender.matches(CallChannel.UUID_FORMAT) && !device.equals(sender)
                    && row.getString("uid").equals(message.getString("uid"));
        } catch (GeneralSecurityException | JSONException | IllegalArgumentException invalid) {
            return false;
        }
    }

    @Override public void signals(CallChannel source, long cursor, List<CallChannel.Signal> signals) {
        if (source != calls || !MainActivity.contactAllowed(preferences, room)) return;
        for (CallChannel.Signal signal : signals) {
            if (pending != null && pending.signal.call.equals(signal.call) && pending.signal.sender.equals(signal.sender)
                    && ("end".equals(signal.kind) || "taken".equals(signal.kind))) {
                dismissCall(signal.call);
            }
            if (chatVisible || callVisible || signal.age >= 30 || wasRejected(signal.call)) continue;
            String title;
            switch (signal.kind) {
                case "ring-audio": title = "Appel audio entrant"; break;
                case "ring-video": title = "Appel vidéo entrant"; break;
                case "ring-meeting":
                    if (room.privateRoom) continue;
                    title = "Invitation à une réunion";
                    break;
                default: continue;
            }
            long remaining = (30 - signal.age) * 1000;
            pending = new Invitation(room, signal, remaining);
            if (!signal.call.equals(lastAlertedCall)) {
                lastAlertedCall = signal.call;
                PendingIntent open = PendingIntent.getActivity(this, CALL, CallAlertActivity.intent(this, signal.call),
                        PendingIntent.FLAG_IMMUTABLE);
                Notification.Builder alert = notice(CALL_CHANNEL, title, "Touchez pour répondre.")
                        .setContentIntent(open).setVisibility(Notification.VISIBILITY_PUBLIC)
                        .setCategory(Notification.CATEGORY_CALL).setTimeoutAfter(remaining).setAutoCancel(true);
                if (Build.VERSION.SDK_INT < 34 || notifications.canUseFullScreenIntent()) {
                    alert.setFullScreenIntent(open, true);
                }
                notifications.notify(CALL, alert.build());
            }
        }
    }

    @Override public void error(CallChannel source, IOException failure) {
        // The call watcher retries independently of message notifications.
    }

    private void stopWatchers() {
        if (calls != null) calls.interrupt();
        if (messages != null) messages.interrupt();
        calls = null;
        messages = null;
        pending = null;
        lastAlertedCall = null;
        notifications.cancel(MESSAGE);
        notifications.cancel(CALL);
    }

    @Override public void onTimeout(int startId, int fgsType) {
        stopSelf();
    }

    @Override public void onDestroy() {
        stopWatchers();
        stopForeground(STOP_FOREGROUND_REMOVE);
        if (active == this) active = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
