package fr.entreamis.chat;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Handler;
import android.text.InputFilter;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.function.Consumer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class ContactsPanel {
    private static final long REFRESH_MS = 12_000;
    private final MainActivity activity;
    private final Relay relay;
    private final SharedPreferences preferences;
    private final ExecutorService worker;
    private final Handler ui;
    private final String device;
    private final Runnable refresh = this::heartbeat;
    private String nickname = "";
    private String session;
    private String connection = "Connexion des contacts…";
    private AlertDialog dialog;
    private AlertDialog selection;
    private TextView status;
    private Button search;
    private Button directory;
    private Button incoming;
    private JSONArray requests = new JSONArray();
    private boolean ready;
    private boolean busy;
    private KeyPair keys;
    private String proof;

    private interface Task<T> { T run(String session) throws Exception; }

    ContactsPanel(MainActivity activity, Relay relay, SharedPreferences preferences,
                  ExecutorService worker, Handler ui, String device) {
        this.activity = activity;
        this.relay = relay;
        this.preferences = preferences;
        this.worker = worker;
        this.ui = ui;
        this.device = device;
    }

    void start(String name) {
        if (session != null && nickname.equals(name)) return;
        stop();
        if (name.isEmpty()) return;
        nickname = name;
        session = UUID.randomUUID().toString();
        connection = "Connexion des contacts…";
        heartbeat();
    }

    void stop() {
        String previous = session;
        session = null;
        ready = false;
        close();
        ui.removeCallbacks(refresh);
        if (previous == null) return;
        worker.execute(() -> {
            if (proof == null) return;
            try { call(previous, "hidden", "", ""); }
            catch (IOException | JSONException ignored) { /* La présence expire automatiquement. */ }
        });
    }

    void show() {
        if (dialog != null) return;
        LinearLayout form = new LinearLayout(activity);
        form.setOrientation(LinearLayout.VERTICAL);
        int padding = Math.round(22 * activity.getResources().getDisplayMetrics().density);
        form.setPadding(padding, 0, padding, 0);
        TextView help = new TextView(activity);
        help.setText("Ton pseudo figure dans l’annuaire. Seul le premier échange avec un contact demande une acceptation.");
        form.addView(help);
        status = new TextView(activity);
        status.setText(connection);
        form.addView(status);
        EditText name = new EditText(activity);
        name.setSingleLine(true);
        name.setHint("Pseudo du contact");
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(30)});
        form.addView(name);
        search = new Button(activity);
        search.setText("Rechercher");
        form.addView(search);
        directory = new Button(activity);
        directory.setText("Tous les utilisateurs");
        form.addView(directory);
        incoming = new Button(activity);
        form.addView(incoming);

        search.setOnClickListener(view -> {
            String query = name.getText().toString().trim();
            if (query.isEmpty()) {
                name.setError("Saisis un pseudo.");
                return;
            }
            find(query, "");
        });
        directory.setOnClickListener(view -> find("", ""));
        incoming.setOnClickListener(view -> choose(requests, true, "", ""));
        AlertDialog window = new AlertDialog.Builder(activity).setTitle("Contacts connectés").setView(form)
                .setNegativeButton("Fermer", null).create();
        dialog = window;
        window.setOnDismissListener(ignored -> { if (dialog == window) close(); });
        buttons();
        window.show();
    }

    void manageContact(String peer, String name) {
        show();
        if (session != null && ready) manage(peer, name, true, false, false, false);
    }

    private void close() {
        if (selection != null) {
            selection.dismiss();
            selection = null;
        }
        AlertDialog previous = dialog;
        dialog = null;
        busy = false;
        if (previous != null) previous.dismiss();
    }

    private void heartbeat() {
        String current = session;
        if (current == null) return;
        String name = nickname;
        worker.execute(() -> {
            try {
                loadKeys();
                JSONObject data = base(current, "visible").put("nickname", name)
                        .put("publicKey", ContactKeys.encode(keys.getPublic().getEncoded()));
                JSONObject reply = response(data);
                if (reply.optInt("protocol") != 2) throw new Relay.HttpError(426, null);
                JSONArray received = reply.getJSONArray("requests");
                ui.post(() -> {
                    if (!current.equals(session)) return;
                    boolean newRequest = hasNewRequest(received);
                    requests = received;
                    ready = true;
                    String previous = connection;
                    connection = "En ligne sous " + name;
                    if (dialog != null && !busy && status.getText().toString().equals(previous)) {
                        status.setText(connection);
                    }
                    activity.updateContactRequests(requests.length(), newRequest && dialog == null);
                    buttons();
                    ui.postDelayed(refresh, REFRESH_MS);
                });
            } catch (IOException | JSONException | GeneralSecurityException | RuntimeException error) {
                ui.post(() -> {
                    if (!current.equals(session)) return;
                    ready = false;
                    connection = errorMessage(error);
                    if (dialog != null) status.setText(connection);
                    buttons();
                    ui.postDelayed(refresh, REFRESH_MS);
                });
            }
        });
    }

    private boolean hasNewRequest(JSONArray received) {
        for (int index = 0; index < received.length(); index++) {
            JSONObject next = received.optJSONObject(index);
            if (next == null) continue;
            String id = next.optString("device");
            boolean known = false;
            for (int previous = 0; previous < requests.length(); previous++) {
                JSONObject old = requests.optJSONObject(previous);
                if (old != null && id.equals(old.optString("device"))) known = true;
            }
            if (!known) return true;
        }
        return false;
    }

    private void loadKeys() throws GeneralSecurityException, IOException {
        if (keys != null) return;
        String saved = preferences.getString("contactPrivate", "");
        if (saved.isEmpty()) {
            KeyPair created = ContactKeys.generate();
            String credential = Room.newOwnerProof();
            if (!preferences.edit().putString("contactProof", credential)
                    .putString("contactPublic", ContactKeys.encode(created.getPublic().getEncoded()))
                    .putString("contactPrivate", ContactKeys.encode(created.getPrivate().getEncoded())).commit()) {
                throw new IOException("Clé de contact indisponible");
            }
            proof = credential;
            keys = created;
        } else {
            String credential = preferences.getString("contactProof", "");
            if (!credential.matches("[0-9a-f]{64}")) throw new GeneralSecurityException("Clé de contact indisponible");
            keys = ContactKeys.restore(preferences.getString("contactPublic", ""), saved);
            proof = credential;
        }
    }

    private JSONObject base(String current, String action) throws JSONException {
        return new JSONObject().put("protocol", 2).put("action", action)
                .put("device", device).put("session", current);
    }

    private JSONObject call(String current, String action, String key, String value)
            throws JSONException, IOException {
        JSONObject data = base(current, action);
        if (!key.isEmpty()) data.put(key, value);
        return response(data);
    }

    private JSONObject response(JSONObject data) throws JSONException, IOException {
        JSONObject result = new JSONObject(relay.contacts(data.toString(), proof));
        if (!result.optBoolean("ok")) throw new IOException("Réponse de contacts invalide");
        return result;
    }

    private void find(String query, String after) {
        submit(current -> {
            JSONObject data = base(current, query.isEmpty() ? "directory" : "search").put("after", after);
            if (!query.isEmpty()) data.put("nickname", query);
            return response(data);
        }, result -> choose(result.optJSONArray("contacts"), false, query, result.optString("next")));
    }

    private void choose(JSONArray choices, boolean request, String query, String next) {
        if (dialog == null || !ready || busy || choices == null) return;
        if (choices.length() == 0) {
            status.setText(request ? "Aucune demande reçue." : "Aucun utilisateur trouvé.");
            return;
        }
        String[] labels = new String[choices.length()];
        for (int i = 0; i < labels.length; i++) {
            JSONObject peer = choices.optJSONObject(i);
            if (peer == null) return;
            String id = peer.optString("device");
            if (id.length() != 36) return;
            String state = peer.optInt("blocked") == 1 ? "Bloqué"
                    : peer.optInt("pending") == 1 ? "En attente"
                    : peer.optInt("online") == 1 ? "En ligne" : "Hors ligne";
            labels[i] = peer.optString("nickname") + " · " + id.substring(0, 6)
                    + (request ? "" : "\n" + state);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(activity)
                .setTitle(request ? "Demandes reçues" : "Choisir un utilisateur")
                .setItems(labels, (window, index) -> select(choices.optJSONObject(index), request))
                .setNegativeButton("Fermer", null);
        if (!next.isEmpty()) builder.setPositiveButton("Page suivante", (window, which) -> find(query, next));
        selection = builder.show();
        if (!request) {
            selection.getListView().setOnItemLongClickListener((parent, view, index, id) -> {
                selection.dismiss();
                JSONObject peer = choices.optJSONObject(index);
                manage(peer.optString("device"), peer.optString("nickname"),
                        peer.optInt("trusted") == 1, peer.optInt("pending") == 1, peer.optInt("blocked") == 1, false);
                return true;
            });
        }
    }

    private void select(JSONObject peer, boolean request) {
        String id = peer.optString("device");
        boolean trusted = peer.optInt("trusted") == 1;
        if (trusted && !request) {
            connect("open", id);
            return;
        }
        manage(id, peer.optString("nickname"), trusted, peer.optInt("pending") == 1,
                peer.optInt("blocked") == 1, request);
    }

    private void manage(String peer, String name, boolean trusted, boolean pending, boolean blocked, boolean request) {
        AlertDialog.Builder prompt = new AlertDialog.Builder(activity).setTitle(name).setNegativeButton("Fermer", null);
        if (blocked) {
            prompt.setItems(new String[]{"Débloquer"}, (window, index) ->
                    change("unblock", peer, "Contact débloqué."));
        } else if (request) {
            prompt.setItems(new String[]{"Accepter", "Refuser", "Bloquer"}, (window, index) -> {
                if (index == 0) connect("accept", peer);
                else if (index == 1) change("dismiss", peer, "Demande refusée.");
                else confirmBlock(peer);
            });
        } else {
            String first = trusted ? "Ouvrir la discussion" : pending ? "Annuler la demande" : "Envoyer une demande";
            String[] actions = trusted ? new String[]{first, "Bloquer", "Retirer le contact"} : new String[]{first, "Bloquer"};
            prompt.setItems(actions, (window, index) -> {
                if (index == 1) confirmBlock(peer);
                else if (index == 2) selection = new AlertDialog.Builder(activity).setTitle("Retirer ce contact ?")
                        .setMessage("Une nouvelle acceptation sera nécessaire pour discuter.")
                        .setNegativeButton("Annuler", null).setPositiveButton("Retirer",
                                (confirm, which) -> change("remove", peer, "Contact retiré.")).show();
                else if (pending) change("cancel", peer, "Demande annulée.");
                else connect(trusted ? "open" : "invite", peer);
            });
        }
        selection = prompt.show();
    }

    private void confirmBlock(String peer) {
        selection = new AlertDialog.Builder(activity).setTitle("Bloquer ce contact ?")
                .setMessage("Les demandes et la discussion privée avec ce contact seront suspendues. L’historique est conservé.")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Bloquer", (window, which) -> change("block", peer, "Contact bloqué.")).show();
    }

    private void connect(String action, String peer) {
        submit(current -> {
            JSONObject result = call(current, action, "peer", peer);
            JSONObject contact = result.optJSONObject("contact");
            if (contact == null && result.optBoolean("pending") && action.equals("invite")) return null;
            if (contact == null || !peer.equals(contact.optString("device"))) throw new IOException("Contact invalide");
            Room room = ContactKeys.room(keys, device, contact.getString("public_key"), peer);
            String name = contact.getString("nickname");
            return (Runnable) () -> {
                forgetRequest(peer);
                close();
                activity.openContactConversation(room, peer, name);
            };
        }, result -> {
            if (result == null) status.setText("Demande envoyée. Rouvre le contact après acceptation.");
            else result.run();
        });
    }

    private void change(String action, String peer, String message) {
        submit(current -> {
            JSONObject result = call(current, action, "peer", peer);
            if (action.equals("block") || action.equals("unblock") || action.equals("remove")) {
                SharedPreferences.Editor edit = preferences.edit();
                if (action.equals("remove")) edit.putBoolean("contactRemoved_" + peer, true);
                else edit.putBoolean("contactBlocked_" + peer, action.equals("block"));
                edit.apply();
                ui.post(() -> activity.contactRestrictionChanged(peer, message));
            }
            return result;
        }, ignored -> {
            if (action.equals("block") || action.equals("dismiss") || action.equals("remove")) forgetRequest(peer);
            status.setText(message);
            buttons();
        });
    }

    private void forgetRequest(String peer) {
        for (int index = 0; index < requests.length(); index++) {
            JSONObject item = requests.optJSONObject(index);
            if (item != null && peer.equals(item.optString("device"))) {
                requests.remove(index);
                activity.updateContactRequests(requests.length(), false);
                return;
            }
        }
    }

    private <T> void submit(Task<T> operation, Consumer<T> done) {
        AlertDialog origin = dialog;
        String current = session;
        if (origin == null || current == null || !ready || busy || !activity.requireUnlock()) return;
        activity.lock.touch();
        busy = true;
        buttons();
        worker.execute(() -> {
            try {
                T result = operation.run(current);
                ui.post(() -> {
                    if (!current.equals(session) || !activity.requireUnlock()) return;
                    if (dialog != origin) return;
                    busy = false;
                    buttons();
                    done.accept(result);
                });
            } catch (Exception error) {
                ui.post(() -> {
                    if (!current.equals(session) || dialog != origin) return;
                    busy = false;
                    buttons();
                    status.setText(errorMessage(error));
                });
            }
        });
    }

    private void buttons() {
        if (dialog == null) return;
        search.setEnabled(ready && !busy);
        directory.setEnabled(ready && !busy);
        incoming.setEnabled(ready && !busy && requests.length() != 0);
        incoming.setText("Demandes reçues (" + requests.length() + ")");
    }

    private static String errorMessage(Exception error) {
        if (error instanceof Relay.HttpError) {
            int code = ((Relay.HttpError) error).code;
            if (code == 404 || code == 426) return "Installe le relais Eclipse 1.3.1 pour l’annuaire.";
            if (code == 409) return "Contact ou demande indisponible. Actualise l’annuaire.";
            if (code == 429) return "Trop de requêtes. Patiente quelques secondes.";
        }
        return "Contacts indisponibles. Vérifie la connexion.";
    }
}
