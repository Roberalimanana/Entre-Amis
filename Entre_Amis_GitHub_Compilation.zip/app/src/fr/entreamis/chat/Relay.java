package fr.entreamis.chat;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

final class Relay {
    static final String ECLIPSE = "https://eklipse.tech/wp-json/entre-amis/v1";
    private final String base;

    Relay(String base) {
        this.base = base;
    }

    String health() throws IOException {
        return get(request("/etat", 6_000, 6_000), 8_192);
    }

    String contacts(String json, String proof) throws IOException {
        return postJson("/contacts", "X-Entre-Amis-Contact", json, proof, 7_000, 16_384);
    }

    String profile(String json, String proof) throws IOException {
        return postJson("/profil", "X-Entre-Amis-Profile", json, proof, 14_000, 750_000);
    }

    private String postJson(String path, String header, String json, String proof, int readMs, int limit) throws IOException {
        byte[] body = json.getBytes(StandardCharsets.UTF_8);
        HttpURLConnection request = request(path, 6_000, readMs);
        request.setRequestProperty(header, proof);
        request.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        request.setRequestMethod("POST");
        request.setFixedLengthStreamingMode(body.length);
        request.setDoOutput(true);
        try {
            try (OutputStream output = request.getOutputStream()) {
                output.write(body);
            }
            return get(request, limit);
        } finally {
            request.disconnect();
        }
    }

    String poll(Room room, long after) throws IOException {
        return get(room, "?after=" + after, 300_000);
    }

    String fetchFile(Room room, String uid) throws IOException {
        return get(room, "/fichiers/" + uid, Attachment.MAX_ENCODED + 32);
    }

    String pollCalls(Room room, String device, String call, long after) throws IOException {
        return get(room, "/appels?after=" + after + "&device=" + device + "&call=" + call, 1_100_000);
    }

    void publishCall(Room room, String call, String sender, String recipient, String signal)
            throws IOException {
        if (signal.length() > 49156) {
            throw new IOException("Signal d’appel trop long");
        }
        post(room, "/appels", "{\"call\":\"" + call + "\",\"sender\":\"" + sender
                + "\",\"recipient\":\"" + recipient + "\",\"signal\":\"" + signal + "\"}");
    }

    private String get(Room room, String path, int maxBytes) throws IOException {
        return get(request(room, path), maxBytes);
    }

    private static String get(HttpURLConnection request, int maxBytes) throws IOException {
        try {
            checkStatus(request);
            try (InputStream input = request.getInputStream()) {
                return new String(Attachment.read(input, maxBytes), StandardCharsets.UTF_8);
            }
        } finally {
            request.disconnect();
        }
    }

    void publish(Room room, String uid, String payload, byte[] file, String owner) throws IOException {
        if (payload.length() > 4096 || (file != null && file.length > Attachment.MAX_PACKET)) {
            throw new IOException("Message trop long");
        }
        String field = file == null ? "" : ",\"file\":\""
                + Base64.getUrlEncoder().withoutPadding().encodeToString(file) + "\"";
        String management = owner.isEmpty() ? "" : ",\"owner\":\"" + owner + "\"";
        post(room, file == null ? "" : "/fichiers/" + uid,
                "{\"uid\":\"" + uid + "\",\"payload\":\"" + payload + "\"" + field + management + "}");
    }

    void change(Room room, String uid, String proof, String value) throws IOException {
        post(room, "/messages/" + uid, value, proof);
    }

    private void post(Room room, String path, String value) throws IOException {
        post(room, path, value, "");
    }

    private void post(Room room, String path, String value, String proof) throws IOException {
        byte[] body = value.getBytes(StandardCharsets.US_ASCII);
        HttpURLConnection request = request(room, path);
        try {
            request.setRequestMethod("POST");
            if (!proof.isEmpty()) request.setRequestProperty("X-Entre-Amis-Owner", proof);
            request.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            request.setFixedLengthStreamingMode(body.length);
            request.setDoOutput(true);
            try (OutputStream output = request.getOutputStream()) {
                output.write(body);
            }
            checkStatus(request);
        } finally {
            request.disconnect();
        }
    }

    private HttpURLConnection request(Room room, String path) throws IOException {
        boolean call = path.startsWith("/appels");
        HttpURLConnection request = request("/salons/" + room.topic + path,
                call ? 6_000 : 12_000, call ? 7_000 : 25_000);
        request.setRequestProperty("X-Entre-Amis-Key", room.accessKey);
        return request;
    }

    private HttpURLConnection request(String path, int connectMs, int readMs) throws IOException {
        HttpURLConnection request = (HttpURLConnection) new URL(base + path).openConnection();
        request.setUseCaches(false);
        request.setInstanceFollowRedirects(false);
        request.setConnectTimeout(connectMs);
        request.setReadTimeout(readMs);
        request.setRequestProperty("Accept", "application/json");
        request.setRequestProperty("Cache-Control", "no-cache");
        request.setRequestProperty("User-Agent", "EntreAmis/1.2");
        return request;
    }

    private static void checkStatus(HttpURLConnection request) throws IOException {
        int code = request.getResponseCode();
        if (code != HttpURLConnection.HTTP_OK) {
            throw new HttpError(code, request.getHeaderField("Retry-After"));
        }
    }

    static final class HttpError extends IOException {
        final int code;
        final long retryMs;

        HttpError(int code, String retryAfter) {
            super("HTTP " + code);
            this.code = code;
            retryMs = retryAfter != null && retryAfter.matches("[0-9]{1,8}")
                    ? Long.parseLong(retryAfter) * 1000 : 0;
        }
    }
}
