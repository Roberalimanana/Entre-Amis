package fr.entreamis.chat;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.json.JSONException;
import org.json.JSONObject;

final class Attachment {
    static final int MAX_SIZE = 2 * 1024 * 1024;
    static final int MAX_PACKET = MAX_SIZE + 28;
    static final int MAX_ENCODED = (MAX_PACKET * 4 + 2) / 3;
    private static final String BINARY = "application/octet-stream";
    final String name;
    final String type;
    final int size;

    Attachment(String name, String type, int size) {
        String safeName = name == null ? "" : name.replace('/', '_').replace('\\', '_')
                .replaceAll("\\p{Cntrl}", "_").trim();
        if (safeName.length() > 100) {
            safeName = safeName.substring(0, Character.isHighSurrogate(safeName.charAt(99)) ? 99 : 100);
        }
        this.name = safeName.isEmpty() || safeName.equals(".") || safeName.equals("..")
                ? "piece-jointe" : safeName;
        this.type = type != null && type.length() <= 100
                && type.matches("[A-Za-z0-9][A-Za-z0-9.+_-]*/[A-Za-z0-9][A-Za-z0-9.+_-]*") ? type : BINARY;
        if (size < 1 || size > MAX_SIZE) {
            throw new IllegalArgumentException("Taille de fichier invalide");
        }
        this.size = size;
    }

    JSONObject json() throws JSONException {
        JSONObject result = new JSONObject();
        result.put("name", name);
        result.put("type", type);
        result.put("size", size);
        return result;
    }

    static Attachment fromJson(JSONObject data) throws JSONException {
        return new Attachment(data.getString("name"), data.getString("type"), data.getInt("size"));
    }

    static byte[] read(InputStream source, int maxBytes) throws IOException {
        if (source == null) {
            throw new IOException("Fichier inaccessible");
        }
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int count;
        while ((count = source.read(buffer)) != -1) {
            if (data.size() + count > maxBytes) {
                throw new TooLarge();
            }
            data.write(buffer, 0, count);
        }
        return data.toByteArray();
    }

    static final class TooLarge extends IOException {}
}
