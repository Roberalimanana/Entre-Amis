package fr.entreamis.chat;

import android.Manifest;
import android.media.AudioManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class CallActivity extends ProtectedActivity implements CallChannel.Listener {
    static final String FROM_LOCK_ALERT = "fromLockAlert";
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    private static final String PATH = ORIGIN + "/entre-amis/";
    private static final String PAGE = PATH + "appel.html";
    private static final int MEDIA_PERMISSION = 40;
    private static final int CAMERA_PERMISSION = 41;
    private static final int SAVE_SCREENSHOT = 42;
    private static final int MAX_MEMBERS = 4;
    private static final long MEDIA_TIMEOUT_MS = 45_000;
    private static final long ANSWER_TIMEOUT_MS = 85_000;
    private static final long CONNECTION_TIMEOUT_MS = 45_000;
    private static final String ICE_SERVERS = "[{urls:'stun:stun.l.google.com:19302'}]";

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable connectionTimeout = this::onConnectionTimeout;
    private final ExecutorService outgoing = Executors.newSingleThreadExecutor();
    private final Relay relay = new Relay(Relay.ECLIPSE);
    private final Map<String, Member> peers = new LinkedHashMap<>();
    private Room room;
    private String device;
    private String name;
    private String mode;
    private String call;
    private String host;
    private String hostName;
    private CallChannel channel;
    private WebView screen;
    private TextView status;
    private Button micButton;
    private Button cameraButton;
    private Button handButton;
    private Button captureButton;
    private boolean ready;
    private boolean announced;
    private boolean admitted;
    private boolean muted;
    private boolean camera;
    private boolean raised;
    private boolean permissionPending;
    private boolean screenshotPending;
    private byte[] screenshot;
    private AudioManager audioManager;
    private int previousAudioMode;
    private volatile boolean ended;

    private static final class Member {
        final String name;
        boolean connected;

        Member(String name) {
            this.name = name;
        }
    }

    static Intent intent(Context context, Room room, String device, String name, String mode,
                         CallChannel.Signal incoming) {
        Intent intent = new Intent(context, CallActivity.class);
        intent.putExtra("room", room.invite).putExtra("device", device).putExtra("name", name)
                .putExtra("mode", mode);
        if (incoming != null) {
            intent.putExtra("call", incoming.call).putExtra("host", incoming.sender)
                    .putExtra("hostName", incoming.data);
        }
        return intent;
    }

    static String title(String mode) {
        if ("video".equals(mode)) return "Appel vidéo";
        if ("meeting".equals(mode)) return "Réunion";
        return "Appel audio";
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (!requireUnlock()) return;
        if (state != null) {
            finish();
            return;
        }
        try {
            room = Room.join(getIntent().getStringExtra("room"));
            device = getIntent().getStringExtra("device");
            name = safeName(getIntent().getStringExtra("name"));
            mode = getIntent().getStringExtra("mode");
            call = getIntent().getStringExtra("call");
            host = getIntent().getStringExtra("host");
            hostName = safeName(getIntent().getStringExtra("hostName"));
            if (host == null) {
                host = device;
                call = UUID.randomUUID().toString();
                hostName = name;
            }
            if (!validId(device) || !validId(call) || !validId(host)
                    || !("audio".equals(mode) || "video".equals(mode) || "meeting".equals(mode))) {
                throw new IllegalArgumentException("Appel invalide");
            }
        } catch (GeneralSecurityException | RuntimeException error) {
            finish();
            return;
        }
        if (getIntent().getBooleanExtra(FROM_LOCK_ALERT, false)) AppLock.showOverSwipeLock(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        draw();
        List<String> permissions = new ArrayList<>();
        if (!allowed(Manifest.permission.RECORD_AUDIO)) permissions.add(Manifest.permission.RECORD_AUDIO);
        if (mode.equals("video") && !allowed(Manifest.permission.CAMERA)) permissions.add(Manifest.permission.CAMERA);
        if (permissions.isEmpty()) loadScreen();
        else {
            permissionPending = true;
            requestPermissions(permissions.toArray(new String[0]), MEDIA_PERMISSION);
        }
    }

    private void draw() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(10), dp(10), dp(8));
        root.setBackgroundColor(0xff17132a);
        TextView heading = label(title(mode), 23);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);
        status = label("Préparation du micro…", 13);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(3), 0, dp(8));
        root.addView(status);

        screen = new WebView(this);
        screen.setBackgroundColor(0xff17132a);
        root.addView(screen, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout controls = new LinearLayout(this);
        micButton = control(controls, "Couper le micro", () -> {
            muted = !muted;
            js("setMuted(" + muted + ")");
            micButton.setText(muted ? "Allumer le micro" : "Couper le micro");
            shareState("mic", muted);
        });
        if (!mode.equals("audio")) cameraButton = control(controls, "Allumer la caméra", this::cameraToggle);
        root.addView(controls);
        if (meeting()) {
            LinearLayout tools = new LinearLayout(this);
            handButton = control(tools, "Lever la main", () -> {
                raised = !raised;
                js("showHand(" + quote(device) + "," + raised + ")");
                handButton.setText(raised ? "Baisser la main" : "Lever la main");
                shareState("hand", raised);
            });
            captureButton = control(tools, "Capture PNG", () -> js("captureMeeting()"));
            root.addView(tools);
        }
        LinearLayout ending = new LinearLayout(this);
        Button hangup = control(ending, meeting() && isHost() ? "Terminer la réunion" : "Raccrocher",
                () -> closeCall("", true));
        hangup.setEnabled(true);
        hangup.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffb44257));
        hangup.setTextColor(Color.WHITE);
        root.addView(ending);
        setContentView(root);
    }

    private TextView label(String text, int size) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(0xfff4efff);
        view.setTextSize(size);
        return view;
    }

    private Button control(LinearLayout parent, String title, Runnable click) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(title);
        button.setTextSize(13);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffeae4ff));
        button.setTextColor(0xff29203d);
        button.setMinHeight(dp(48));
        button.setEnabled(false);
        button.setOnClickListener(view -> click.run());
        LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(0, -2, 1);
        layout.setMargins(dp(3), dp(3), dp(3), 0);
        parent.addView(button, layout);
        return button;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void loadScreen() {
        audioManager = getSystemService(AudioManager.class);
        previousAudioMode = audioManager.getMode();
        audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
        setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);
        screen.getSettings().setJavaScriptEnabled(true);
        screen.getSettings().setMediaPlaybackRequiresUserGesture(false);
        screen.getSettings().setAllowFileAccess(false);
        screen.getSettings().setAllowContentAccess(false);
        screen.addJavascriptInterface(new Bridge(), "EntreAmisCall");
        screen.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true;
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.equals(PAGE) || url.equals(PATH + "appel.js")) {
                    try {
                        String file = url.endsWith(".js") ? "appel.js" : "appel.html";
                        String type = url.endsWith(".js") ? "text/javascript" : "text/html";
                        return new WebResourceResponse(type, "UTF-8", getAssets().open(file));
                    } catch (IOException ignored) {
                        // A missing asset is handled by the setup timeout.
                    }
                }
                return new WebResourceResponse("text/plain", "UTF-8",
                        new ByteArrayInputStream(new byte[0]));
            }
        });
        screen.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                ui.post(() -> {
                    Uri origin = request.getOrigin();
                    if (ended || !"https".equals(origin.getScheme()) || (origin.getPort() != -1 && origin.getPort() != 443)
                            || !"appassets.androidplatform.net".equals(origin.getHost())) {
                        request.deny();
                        return;
                    }
                    for (String resource : request.getResources()) {
                        boolean permitted = PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                                && allowed(Manifest.permission.RECORD_AUDIO);
                        permitted |= PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                                && !mode.equals("audio") && allowed(Manifest.permission.CAMERA);
                        if (!permitted) { request.deny(); return; }
                    }
                    request.grant(request.getResources());
                });
            }
        });
        screen.loadUrl(PAGE);
        ui.postDelayed(() -> {
            if (!ready && !ended) closeCall("Impossible de préparer le micro ou la caméra.", false);
        }, MEDIA_TIMEOUT_MS);
    }

    private boolean allowed(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        permissionPending = false;
        if (ended || !requireUnlock()) return;
        if (request == MEDIA_PERMISSION) {
            if (allowed(Manifest.permission.RECORD_AUDIO)
                    && (!mode.equals("video") || allowed(Manifest.permission.CAMERA))) loadScreen();
            else closeCall("Autorise le micro et la caméra demandés pour cet appel.", false);
        } else if (request == CAMERA_PERMISSION) {
            if (allowed(Manifest.permission.CAMERA)) changeCamera(true);
            else toast("La caméra n’a pas été autorisée.");
        }
    }

    private final class Bridge {
        @JavascriptInterface public void status(String state, String peer) {
            ui.post(() -> mediaState(state, peer));
        }

        @JavascriptInterface public void signal(String kind, String peer, String data) {
            if (data == null || data.length() > 35000) return;
            ui.post(() -> {
                if (!ended && peers.containsKey(peer)
                        && ("offer".equals(kind) || "answer".equals(kind) || "ice".equals(kind))) {
                    send(kind, peer, data, !kind.equals("ice"));
                }
            });
        }

        @JavascriptInterface public void capture(String encoded) {
            if (encoded == null || encoded.length() > 5_600_000) return;
            ui.post(() -> prepareScreenshot(encoded));
        }
    }

    private void mediaState(String state, String peer) {
        if (ended) return;
        switch (state) {
            case "page-ready":
                js("startCall(" + quote(device) + "," + quote(name) + "," + quote(mode) + "," + ICE_SERVERS + ")");
                break;
            case "media-ready":
                mediaReady();
                break;
            case "media-error":
                closeCall("Impossible d’ouvrir le micro ou la caméra.", true);
                break;
            case "audio-playback-error":
                toast("Le son distant n’a pas pu démarrer.");
                break;
            case "camera-on":
            case "camera-off":
            case "camera-error":
                camera = state.equals("camera-on");
                cameraButton.setText(camera ? "Couper la caméra" : "Allumer la caméra");
                cameraButton.setEnabled(true);
                shareState("camera", camera);
                if (state.equals("camera-error")) toast("La caméra est indisponible.");
                break;
            case "peer-connected":
                if (peers.containsKey(peer)) {
                    peers.get(peer).connected = true;
                    ui.removeCallbacks(connectionTimeout);
                    updateStatus();
                }
                break;
            case "peer-disconnected":
            case "peer-failed":
            case "peer-error":
                Member disconnected = peers.get(peer);
                if (disconnected != null) {
                    disconnected.connected = false;
                    updateStatus();
                    if (isHost() && meeting()) ui.postDelayed(() -> {
                        if (!ended && peers.get(peer) == disconnected && !disconnected.connected) {
                            removePeer(peer);
                            send("removed", "", peer, false);
                        }
                    }, 22000);
                }
                if (state.equals("peer-failed") && !meeting()) {
                    closeCall("La liaison directe a échoué sur ce réseau.", true);
                }
                break;
            default:
                break;
        }
    }

    private void mediaReady() {
        if (ready) return;
        ready = true;
        camera = mode.equals("video");
        micButton.setEnabled(true);
        if (cameraButton != null) {
            cameraButton.setText(camera ? "Couper la caméra" : "Allumer la caméra");
            cameraButton.setEnabled(true);
        }
        if (handButton != null) handButton.setEnabled(true);
        if (captureButton != null) captureButton.setEnabled(true);
        channel = new CallChannel(relay, room, device, call, 0, ui, this);
        channel.start();
        announced = true;
        if (isHost()) {
            admitted = true;
            broadcastRing();
        } else {
            addPeer(host, hostName);
            send("accept", host, name, true);
        }
        updateStatus();
        if (!isHost() || !meeting()) {
            waitForConnection(isHost() ? ANSWER_TIMEOUT_MS : CONNECTION_TIMEOUT_MS);
        }
    }

    private void waitForConnection(long delay) {
        ui.removeCallbacks(connectionTimeout);
        ui.postDelayed(connectionTimeout, delay);
    }

    private void onConnectionTimeout() {
        if (ended || connectedCount() > 0) return;
        closeCall(isHost() && peers.isEmpty() ? "Aucune réponse reçue pour cet appel."
                : "La liaison avec le participant n’a pas pu être établie.", true);
    }

    private void broadcastRing() {
        if (ended || !isHost()) return;
        if (peers.size() < (meeting() ? MAX_MEMBERS - 1 : 1)) {
            send("ring-" + mode, "", name, true);
        }
        if (meeting()) ui.postDelayed(this::broadcastRing, 18000);
    }

    private void send(String kind, String to, String data, boolean important) {
        outgoing.execute(() -> {
            if (ended && !(kind.equals("end") || kind.equals("leave"))) return;
            try {
                CallChannel.send(relay, room, call, device, to, kind, data);
            } catch (IOException | JSONException | GeneralSecurityException error) {
                if (!important) return;
                ui.post(() -> {
                    if (ended) return;
                    if (error instanceof Relay.HttpError && ((Relay.HttpError) error).code == 404) {
                        closeCall("Installe et active le relais Eclipse 1.2 pour les appels.", false);
                    } else if (connectedCount() == 0) {
                        status.setText("Signal d’appel indisponible · vérifie la connexion");
                    }
                });
            }
        });
    }

    @Override public void signals(CallChannel source, long cursor, List<CallChannel.Signal> incoming) {
        if (ended || source != channel) return;
        for (CallChannel.Signal signal : incoming) {
            if (ended) return;
            handle(signal);
        }
    }

    @Override public void error(CallChannel source, IOException error) {
        if (ended || source != channel) return;
        if (error instanceof Relay.HttpError && ((Relay.HttpError) error).code == 404) {
            closeCall("Installe et active le relais Eclipse 1.2 pour les appels.", false);
        } else if (connectedCount() == 0) {
            status.setText("Connexion au relais interrompue · nouvel essai");
        }
    }

    private void handle(CallChannel.Signal signal) {
        String from = signal.sender;
        boolean fromHost = host.equals(from);
        switch (signal.kind) {
            case "accept":
                if (isHost()) admit(from, safeName(signal.data));
                return;
            case "welcome":
                if (meeting() && fromHost && !isHost() && !admitted) joinMeeting(signal.data);
                return;
            case "peer":
                if (meeting() && fromHost && admitted) readMember(signal.data, false);
                return;
            case "taken":
                if (!meeting() && fromHost && !device.equals(signal.data)) {
                    closeCall("Cet appel a déjà été pris.", false);
                }
                return;
            case "removed":
                if (meeting() && fromHost && validId(signal.data)) {
                    if (device.equals(signal.data)) closeCall("Connexion perdue. Tu peux rejoindre la réunion à nouveau.", false);
                    else removePeer(signal.data);
                }
                return;
            case "full":
                if (fromHost && !admitted) closeCall("La réunion est complète.", false);
                return;
            case "end":
                if (fromHost || (!meeting() && peers.containsKey(from))) closeCall("Appel terminé.", false);
                return;
            default:
                break;
        }
        if (!peers.containsKey(from)) return;
        switch (signal.kind) {
            case "offer":
            case "answer":
            case "ice":
                js("applySignal(" + quote(from) + "," + quote(signal.kind) + "," + quote(signal.data) + ")");
                if (signal.kind.equals("offer")) sendParticipantState(from);
                break;
            case "hand":
                if (meeting()) js("showHand(" + quote(from) + "," + "true".equals(signal.data) + ")");
                break;
            case "camera":
                js("showCamera(" + quote(from) + "," + "true".equals(signal.data) + ")");
                break;
            case "mic":
                js("showMic(" + quote(from) + "," + "true".equals(signal.data) + ")");
                break;
            case "leave":
                if (!meeting() || fromHost) {
                    closeCall("Appel terminé.", false);
                } else {
                    removePeer(from);
                }
                break;
            default:
                break;
        }
    }

    private void admit(String id, String nickname) {
        if (peers.containsKey(id)) return;
        if (!meeting()) {
            if (!peers.isEmpty()) return;
            addPeer(id, nickname);
            waitForConnection(CONNECTION_TIMEOUT_MS);
            send("taken", "", id, false);
            js("makeOffer(" + quote(id) + ")");
            sendParticipantState(id);
            updateStatus();
            return;
        }
        if (peers.size() >= MAX_MEMBERS - 1) {
            send("full", id, "", false);
            return;
        }
        JSONArray list = new JSONArray();
        list.put(memberData(device, name));
        String addition = memberData(id, nickname).toString();
        for (Map.Entry<String, Member> member : peers.entrySet()) {
            list.put(memberData(member.getKey(), member.getValue().name));
            send("peer", member.getKey(), addition, true);
        }
        addPeer(id, nickname);
        send("welcome", id, list.toString(), true);
        sendParticipantState(id);
        updateStatus();
    }

    private JSONObject memberData(String id, String nickname) {
        try {
            return new JSONObject().put("id", id).put("name", nickname);
        } catch (JSONException error) {
            throw new IllegalStateException(error);
        }
    }

    private void joinMeeting(String payload) {
        try {
            JSONArray list = new JSONArray(payload);
            if (list.length() < 1 || list.length() >= MAX_MEMBERS) return;
            admitted = true;
            for (int index = 0; index < list.length(); index++) readMember(list.getJSONObject(index).toString(), true);
            updateStatus();
        } catch (JSONException ignored) {
            // Keep waiting for a valid invitation from the organizer.
        }
    }

    private void readMember(String data, boolean initiate) {
        try {
            JSONObject member = new JSONObject(data);
            String id = member.getString("id");
            if (!validId(id) || device.equals(id)) return;
            addPeer(id, safeName(member.getString("name")));
            if (!peers.containsKey(id)) return;
            sendParticipantState(id);
            if (initiate) js("makeOffer(" + quote(id) + ")");
            updateStatus();
        } catch (JSONException ignored) {
            // Ignore malformed participant descriptions.
        }
    }

    private void addPeer(String id, String nickname) {
        if (peers.containsKey(id) || peers.size() >= MAX_MEMBERS - 1) return;
        peers.put(id, new Member(nickname));
        js("ensurePeer(" + quote(id) + "," + quote(nickname) + ")");
    }

    private void removePeer(String id) {
        if (peers.remove(id) != null) {
            js("dropPeer(" + quote(id) + ")");
            updateStatus();
        }
    }

    private void sendParticipantState(String id) {
        if (meeting()) send("hand", id, Boolean.toString(raised), false);
        if (!mode.equals("audio")) send("camera", id, Boolean.toString(camera), false);
        send("mic", id, Boolean.toString(muted), false);
    }

    private void shareState(String kind, boolean value) {
        for (String peer : peers.keySet()) send(kind, peer, Boolean.toString(value), false);
    }

    private void cameraToggle() {
        if (!camera && !allowed(Manifest.permission.CAMERA)) {
            permissionPending = true;
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
        } else changeCamera(!camera);
    }

    private void changeCamera(boolean enabled) {
        cameraButton.setEnabled(false);
        js("setCamera(" + enabled + ")");
    }

    private int connectedCount() {
        int count = 0;
        for (Member peer : peers.values()) if (peer.connected) count++;
        return count;
    }

    private void updateStatus() {
        int connected = connectedCount();
        if (meeting() && admitted) {
            status.setText((1 + connected) + "/" + MAX_MEMBERS + " en ligne"
                    + (peers.size() > connected ? " · connexion en cours…" : ""));
        } else if (connected > 0) status.setText("En communication");
        else status.setText(peers.isEmpty() ? "En attente d’une réponse…" : "Connexion en cours…");
    }

    private boolean isHost() { return device.equals(host); }
    private boolean meeting() { return mode.equals("meeting"); }
    private static boolean validId(String id) { return id != null && id.matches(CallChannel.UUID_FORMAT); }
    private static String quote(String text) { return JSONObject.quote(text); }

    private static String safeName(String input) {
        if (input == null) return "Un ami";
        String trimmed = input.trim();
        return trimmed.isEmpty() || trimmed.length() > 30 ? "Un ami" : trimmed;
    }

    private void js(String code) {
        if (screen != null) screen.evaluateJavascript(code, null);
    }

    private void prepareScreenshot(String encoded) {
        if (ended || !meeting() || screenshotPending) return;
        try {
            screenshot = Base64.getDecoder().decode(encoded);
        } catch (IllegalArgumentException error) {
            toast("Capture indisponible.");
            return;
        }
        screenshotPending = true;
        Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("image/png").putExtra(Intent.EXTRA_TITLE, "Entre_Amis_Reunion_"
                        + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new Date()) + ".png");
        startActivityForResult(save, SAVE_SCREENSHOT);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (!requireUnlock()) return;
        if (request != SAVE_SCREENSHOT) return;
        screenshotPending = false;
        byte[] bytes = screenshot;
        screenshot = null;
        if (result != RESULT_OK || data == null || data.getData() == null || bytes == null) return;
        Uri target = data.getData();
        new Thread(() -> {
            String message;
            try (OutputStream stream = getContentResolver().openOutputStream(target, "wt")) {
                if (stream == null) throw new IOException("Fichier inaccessible");
                stream.write(bytes);
                message = "Capture enregistrée.";
            } catch (IOException | RuntimeException error) {
                message = "Impossible d’enregistrer la capture.";
            }
            String feedback = message;
            ui.post(() -> toast(feedback));
        }, "EntreAmis-capture").start();
    }

    private void closeCall(String reason, boolean notify) {
        if (ended) return;
        ended = true;
        if (notify && announced) {
            if (isHost()) send("end", "", "", false);
            else send("leave", "", "", false);
        }
        if (channel != null) channel.interrupt();
        js("stopCall()");
        if (!reason.isEmpty()) toast(reason);
        finish();
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    @Override public void onBackPressed() { closeCall("", true); }

    @Override void closeForLock() { closeCall("", true); }

    @Override protected void onStart() {
        super.onStart();
        if (isFinishing()) return;
        RoomAlertService.setCallVisible(true);
    }

    @Override protected void onResume() {
        super.onResume();
        if (!isFinishing()) lock.callResumed(this);
    }

    @Override protected void onPause() {
        lock.callPaused(this);
        super.onPause();
    }

    @Override protected void onStop() {
        RoomAlertService.setCallVisible(false);
        if (!isFinishing() && !isChangingConfigurations() && !permissionPending && !screenshotPending) {
            closeCall("", true);
        }
        super.onStop();
    }

    @Override protected void onDestroy() {
        ended = true;
        if (channel != null) channel.interrupt();
        outgoing.shutdown();
        ui.removeCallbacksAndMessages(null);
        if (screen != null) {
            screen.removeJavascriptInterface("EntreAmisCall");
            if (screen.getParent() instanceof ViewGroup) ((ViewGroup) screen.getParent()).removeView(screen);
            screen.destroy();
            screen = null;
        }
        if (audioManager != null && audioManager.getMode() == AudioManager.MODE_IN_COMMUNICATION) {
            audioManager.setMode(previousAudioMode);
        }
        super.onDestroy();
    }
}
