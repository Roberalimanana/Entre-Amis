package fr.entreamis.chat;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import javax.net.ssl.SSLException;
import org.json.JSONException;
import org.json.JSONObject;

final class RelayDiagnostic {
    private static final String INVALID = "Réponse inattendue de eklipse.tech. L’hébergeur peut vérifier le relais Entre Amis.";

    static String check(Relay relay) {
        try {
            JSONObject reply = new JSONObject(relay.health());
            return health(reply.optBoolean("ok"), reply.optInt("version"), reply.optBoolean("calls"));
        } catch (JSONException error) {
            return INVALID;
        } catch (IOException error) {
            return failure(error);
        }
    }

    static String health(boolean ok, int version, boolean calls) {
        if (!ok || version < 1) return INVALID;
        return "Le relais Entre Amis répond sur eklipse.tech (protocole " + version + ").\n"
                + (calls ? "La signalisation des appels est annoncée par le relais."
                        : "Cette version du relais ne signale pas la prise en charge des appels.");
    }

    static String failure(IOException error) {
        if (error instanceof Relay.HttpError) {
            int code = ((Relay.HttpError) error).code;
            if (code == 404) {
                return "Adresse du relais introuvable sur eklipse.tech (HTTP 404). Vérifie l’activation de l’extension Entre Amis dans WordPress.";
            }
            if (code == 401 || code == 403) return "Accès au relais refusé par eklipse.tech (HTTP " + code + ").";
            if (code == 429) return "Trop de requêtes vers eklipse.tech (HTTP 429). Réessaie dans un instant.";
            if (code >= 500 && code < 600) return "Erreur du serveur eklipse.tech (HTTP " + code + ").";
            return "Réponse inattendue de eklipse.tech (HTTP " + code + ").";
        }
        if (error instanceof UnknownHostException) return "Adresse eklipse.tech introuvable (DNS). Vérifie ta connexion Internet.";
        if (error instanceof SocketTimeoutException) return "Délai d’attente dépassé pour eklipse.tech. Réessaie depuis un autre réseau.";
        if (error instanceof SSLException) return "Échec de la connexion sécurisée (HTTPS) à eklipse.tech.";
        if (error instanceof ConnectException) return "Connexion à eklipse.tech impossible. Réessaie depuis un autre réseau.";
        return "Impossible de lire la réponse de eklipse.tech. Réessaie dans un instant.";
    }
}
