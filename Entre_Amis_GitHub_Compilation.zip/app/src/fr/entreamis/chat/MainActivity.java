package fr.entreamis.chat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.telephony.PhoneNumberUtils;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class MainActivity extends ProtectedActivity {
    static final String PREFERENCES = "entre_amis";
    private static final String APPEARANCE = "appearance";
    private static final int FOLLOW_SYSTEM = 0;
    private static final int LIGHT = 1;
    private static final int DARK = 2;
    private static final int MESSAGE_LIMIT = 450;
    private static final int PICK_ATTACHMENT = 10;
    private static final int SAVE_ATTACHMENT = 11;
    private static final int NOTIFICATION_PERMISSION = 12;
    private static final int CAPTURE_PHOTO = 13;
    private static final int PHOTO_PERMISSION = 14;
    private static final int PICK_PHONE_CONTACT = 15;
    private static final String UUID_FORMAT = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
    private static History sharedHistory;

    private final Relay relay = new Relay(Relay.ECLIPSE);
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService sender = Executors.newSingleThreadExecutor();
    private final ExecutorService searchWorker = Executors.newSingleThreadExecutor();
    private final ExecutorService contactWorker = Executors.newSingleThreadExecutor();
    private final Set<String> sending = new HashSet<>();
    private SharedPreferences preferences;
    private History history;
    private String device;
    private String ownerProof;
    private CallChannel callWatcher;
    private long callCursor;
    private String currentRing;
    private String ringingDevice;
    private AlertDialog ringDialog;
    private boolean openingCall;
    private String nickname;
    private Room room;
    private Receiver receiver;
    private boolean visible;
    private TextView status;
    private EditText composer;
    private ListView list;
    private CursorAdapter bubbles;
    private Drafts drafts;
    private String downloadUid;
    private Attachment downloadFile;
    private File capture;
    private String captureTopic;
    private File photoReview;
    private ContactsPanel contacts;
    private ProfilePanel profile;
    private Button contactsButton;
    private int contactRequests;
    private String phoneInviteTopic;

    @Override protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        int appearance = base.getSharedPreferences(PREFERENCES, MODE_PRIVATE).getInt(APPEARANCE, FOLLOW_SYSTEM);
        if (appearance == LIGHT || appearance == DARK) {
            Configuration override = new Configuration();
            override.uiMode = appearance == DARK ? Configuration.UI_MODE_NIGHT_YES : Configuration.UI_MODE_NIGHT_NO;
            applyOverrideConfiguration(override);
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (!lock.isUnlocked()) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
            return;
        }
        preferences = getSharedPreferences(PREFERENCES, MODE_PRIVATE);
        drafts = new Drafts(preferences);
        if (sharedHistory == null) {
            sharedHistory = new History(getApplicationContext());
        }
        history = sharedHistory;
        device = preferences.getString("device", "");
        if (device.isEmpty()) {
            device = UUID.randomUUID().toString();
            preferences.edit().putString("device", device).apply();
        }
        ownerProof = preferences.getString("ownerProof", "");
        if (ownerProof.isEmpty()) {
            ownerProof = Room.newOwnerProof();
            preferences.edit().putString("ownerProof", ownerProof).apply();
        }
        nickname = preferences.getString("nickname", "");
        contacts = new ContactsPanel(this, relay, preferences, contactWorker, ui, device);
        profile = new ProfilePanel(this, relay, preferences, searchWorker, ui, ownerProof);
        String savedCode = preferences.getString("room", "");
        if (state != null) {
            callCursor = state.getLong("callCursor");
            downloadUid = state.getString("downloadUid");
            downloadFile = readAttachment(state.getString("downloadFile", ""));
            capture = PhotoProvider.file(this, state.getString("capture"));
            captureTopic = state.getString("captureTopic");
            phoneInviteTopic = state.getString("phoneInviteTopic");
        }
        if (!savedCode.isEmpty()) {
            try {
                room = Room.join(savedCode);
                if (!contactAllowed(preferences, room)) {
                    room = null;
                    preferences.edit().remove("room").apply();
                }
            } catch (GeneralSecurityException | IllegalArgumentException ignored) {
                preferences.edit().remove("room").apply();
            }
        }
        if (room == null) {
            showHome();
        } else {
            if (state != null && state.containsKey("draft") && drafts.read(room.topic).isEmpty()) {
                drafts.write(room.topic, state.getString("draft", ""));
            }
            showChat();
        }
    }

    @Override protected void onStart() {
        super.onStart();
        if (isFinishing()) return;
        visible = true;
        openingCall = false;
        if (contacts != null) contacts.start(nickname);
        RoomAlertService.setChatVisible(true);
        startReceiver();
        if (room != null) {
            CallChannel.Signal pending = RoomAlertService.takeCall(room);
            if (pending != null) showRing(pending);
        }
        syncAlerts();
    }

    @Override protected void onResume() {
        super.onResume();
        if (profile != null && !isFinishing()) profile.resume();
    }

    @Override protected void onStop() {
        saveDraft();
        if (contacts != null) contacts.stop();
        if (profile != null) profile.pause();
        visible = false;
        RoomAlertService.setChatVisible(false);
        stopReceiver();
        stopCallWatcher();
        dismissRing();
        super.onStop();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        saveDraft();
        state.putLong("callCursor", callCursor);
        state.putString("phoneInviteTopic", phoneInviteTopic);
        if (capture != null) {
            state.putString("capture", capture.getName());
            state.putString("captureTopic", captureTopic);
        }
        if (downloadFile != null) {
            state.putString("downloadUid", downloadUid);
            state.putString("downloadFile", attachmentData(downloadFile));
        }
    }

    @Override protected void onDestroy() {
        if (photoReview != null) photoReview.delete();
        if (!isChangingConfigurations() && capture != null) discardCapture();
        if (bubbles != null) {
            bubbles.changeCursor(null);
        }
        sender.shutdown();
        searchWorker.shutdownNow();
        if (contacts != null) contacts.stop();
        contactWorker.shutdown();
        super.onDestroy();
    }

    private void showHome() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(getColor(R.color.amis_paper));
        LinearLayout frame = column();
        frame.setGravity(Gravity.CENTER);
        frame.setPadding(dp(22), dp(24), dp(22), dp(24));
        scroll.addView(frame, new ScrollView.LayoutParams(-1, -2));
        LinearLayout content = column();
        int width = Math.max(220, Math.min(440, getResources().getConfiguration().screenWidthDp - 44));
        frame.addView(content, new LinearLayout.LayoutParams(dp(width), -2));
        content.setFocusableInTouchMode(true);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.app_icon);
        content.addView(logo, new LinearLayout.LayoutParams(dp(58), dp(58)));
        add(content, label(getString(R.string.app_name), 30, getColor(R.color.amis_ink), true), 13);
        TextView tagline = label("Discussions privées, groupes et réunions.", 16, getColor(R.color.amis_muted), false);
        add(content, tagline, 5);
        add(content, label("Ton pseudo", 15, getColor(R.color.amis_ink), true), 28);
        EditText name = field("Ex. Rivo", 30, false);
        name.setId(R.id.home_nickname);
        name.setText(nickname);
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        add(content, name, 8);

        Button saveName = button("Enregistrer mon pseudo", false);
        add(content, saveName, 8);
        saveName.setOnClickListener(view -> {
            String chosen = name.getText().toString().trim();
            if (chosen.isEmpty()) {
                name.setError("Choisis ton pseudo.");
                return;
            }
            boolean firstProfile = nickname.isEmpty();
            saveNickname(chosen);
            if (firstProfile) profile.show();
            else toast("Pseudo enregistré pour l’annuaire.");
        });
        Button profileButton = button("Mon profil", false);
        add(content, profileButton, 8);
        profileButton.setOnClickListener(view -> profile.show());
        Button findContacts = button(contactsTitle(), true);
        contactsButton = findContacts;
        add(content, findContacts, 14);
        findContacts.setOnClickListener(view -> {
            String chosen = name.getText().toString().trim();
            if (chosen.isEmpty()) {
                name.setError("Choisis ton pseudo.");
                name.requestFocus();
                return;
            }
            ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(name.getWindowToken(), 0);
            openContacts(chosen);
        });
        Button phoneContact = button("Inviter un contact du téléphone", false);
        add(content, phoneContact, 8);
        phoneContact.setOnClickListener(view -> {
            String chosen = name.getText().toString().trim();
            if (chosen.isEmpty()) {
                name.setError("Choisis ton pseudo.");
                name.requestFocus();
                return;
            }
            saveNickname(chosen);
            pickPhoneContact();
        });
        Button create = button("Créer un groupe", true);
        add(content, create, 16);
        create.setOnClickListener(view -> openRoom(name, null, false));
        Button createPrivate = button("Créer une discussion privée", false);
        add(content, createPrivate, 8);
        createPrivate.setOnClickListener(view -> openRoom(name, null, true));
        TextView separator = label("J’AI DÉJÀ UNE INVITATION", 12, getColor(R.color.amis_muted), true);
        separator.setLetterSpacing(0.07f);
        add(content, separator, 25);
        EditText invite = field("Coller le code d’invitation", 80, false);
        invite.setId(R.id.home_invite);
        invite.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        add(content, invite, 8);
        Button join = button("Rejoindre le salon", false);
        add(content, join, 10);
        join.setOnClickListener(view -> openRoom(name, invite.getText().toString(), false));
        JSONArray recent = recentRooms();
        if (recent.length() > 0) {
            List<String> codes = new ArrayList<>();
            List<String> labels = new ArrayList<>();
            for (int index = 0; index < recent.length(); index++) {
                try {
                    Room saved = Room.join(recent.optString(index));
                    codes.add(saved.invite);
                    String codeLabel = saved.topic.substring(0, 6).toUpperCase(java.util.Locale.ROOT);
                    String draftLabel = drafts.read(saved.topic).isEmpty() ? "" : " · brouillon";
                    labels.add(roomLabel(saved) + " · " + codeLabel + draftLabel);
                } catch (GeneralSecurityException | IllegalArgumentException invalid) {
                    // Skip invalid saved invitations.
                }
            }
            Button rooms = button("Mes conversations (" + labels.size() + ")", false);
            add(content, rooms, 10);
            rooms.setOnClickListener(view -> new AlertDialog.Builder(this)
                    .setTitle("Mes conversations")
                    .setItems(labels.toArray(new String[0]),
                            (dialog, index) -> openRoom(name, codes.get(index), false))
                    .setNegativeButton("Fermer", null).show());
        }
        Button diagnostic = button("Tester la connexion", false);
        add(content, diagnostic, 12);
        diagnostic.setOnClickListener(view -> testConnection());
        Button appearance = button("Apparence", false);
        add(content, appearance, 8);
        appearance.setOnClickListener(view -> chooseAppearance());
        Button password = button("Changer le mot de passe", false);
        add(content, password, 8);
        password.setOnClickListener(view -> startActivity(UnlockActivity.forChange(this)));
        TextView footer = label("Messages chiffrés  ·  Connexion Internet requise", 13, getColor(R.color.amis_muted), false);
        add(content, footer, 20);
        setContentView(scroll);
        content.requestFocus();
    }

    private void openRoom(EditText name, String invite, boolean privateRoom) {
        String chosenName = name.getText().toString().trim();
        if (chosenName.isEmpty()) {
            name.setError("Choisis un pseudo.");
            name.requestFocus();
            return;
        }
        Room destination;
        try {
            destination = invite == null ? Room.create(privateRoom) : Room.join(invite);
        } catch (IllegalArgumentException exception) {
            toast("Colle le code d’invitation complet.");
            return;
        } catch (GeneralSecurityException exception) {
            toast("Ce téléphone n’a pas pu ouvrir le salon.");
            return;
        }
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(name.getWindowToken(), 0);
        showRoom(destination, chosenName);
    }

    private void openContacts(String chosenName) {
        if (!requireUnlock()) return;
        saveNickname(chosenName);
        contacts.show();
    }

    private void saveNickname(String chosen) {
        nickname = chosen;
        preferences.edit().putString("nickname", chosen).apply();
        if (visible) contacts.start(chosen);
    }

    private String contactsTitle() {
        return contactRequests == 0 ? "Contacts connectés" : "Contacts connectés (" + contactRequests + ")";
    }

    void updateContactRequests(int count, boolean announce) {
        contactRequests = count;
        if (contactsButton != null) contactsButton.setText(contactsTitle());
        if (announce) toast("Nouvelle demande dans Contacts connectés.");
    }

    void openContactConversation(Room destination, String peer, String label) {
        preferences.edit().putString("contactLabel_" + destination.topic, label)
                .putString("contactPeer_" + destination.topic, peer)
                .remove("contactBlocked_" + peer).remove("contactRemoved_" + peer).apply();
        showRoom(destination, nickname);
    }

    void contactRestrictionChanged(String peer, String message) {
        if (isFinishing() || isDestroyed()) return;
        if (room != null && peer.equals(contactPeer(preferences, room)) && !contactAllowed(preferences, room)) {
            clearRoom();
        }
        if (visible) toast(message);
    }

    private static String contactPeer(SharedPreferences preferences, Room value) {
        return preferences.getString("contactPeer_" + value.topic, "");
    }

    static boolean contactAllowed(SharedPreferences preferences, Room value) {
        String peer = contactPeer(preferences, value);
        return peer.isEmpty() || (!preferences.getBoolean("contactBlocked_" + peer, false)
                && !preferences.getBoolean("contactRemoved_" + peer, false));
    }

    private void showRoom(Room destination, String chosenName) {
        if (!contactAllowed(preferences, destination)) {
            toast("Gère ce contact depuis Contacts connectés pour rouvrir la discussion.");
            return;
        }
        saveDraft();
        stopReceiver();
        stopCallWatcher();
        dismissRing();
        if (bubbles != null) bubbles.changeCursor(null);
        room = destination;
        saveNickname(chosenName);
        callCursor = 0;
        rememberRoom(room);
        preferences.edit().putString("room", room.invite).apply();
        showChat();
        startReceiver();
        syncAlerts();
    }

    private String roomLabel(Room value) {
        String contact = preferences.getString("contactLabel_" + value.topic, "");
        if (!contact.isEmpty()) return contact;
        return value.privateRoom ? "Discussion privée" : "Groupe entre amis";
    }

    private JSONArray recentRooms() {
        try {
            return new JSONArray(preferences.getString("rooms", "[]"));
        } catch (JSONException error) {
            return new JSONArray();
        }
    }

    private void rememberRoom(Room value) {
        JSONArray before = recentRooms();
        JSONArray after = new JSONArray();
        after.put(value.invite);
        for (int index = 0; index < before.length(); index++) {
            String saved = before.optString(index);
            if (!saved.equals(value.invite)) after.put(saved);
        }
        preferences.edit().putString("rooms", after.toString()).apply();
    }

    private void showChat() {
        contactsButton = null;
        LinearLayout root = column();
        root.setBackgroundColor(getColor(R.color.amis_paper));
        root.setFocusableInTouchMode(true);

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(8), dp(8), dp(10), dp(8));
        Button options = button("‹", false);
        options.setTextSize(25);
        options.setContentDescription("Options du salon");
        toolbar.addView(options, new LinearLayout.LayoutParams(dp(45), dp(48)));
        options.setOnClickListener(view -> roomOptions());

        LinearLayout heading = column();
        heading.setPadding(dp(9), 0, dp(4), 0);
        toolbar.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        heading.addView(label(roomLabel(room), 19, getColor(R.color.amis_ink), true));
        status = label("", 12, getColor(R.color.amis_error), false);
        status.setVisibility(View.GONE);
        heading.addView(status);

        if (preferences.getString("contactLabel_" + room.topic, "").isEmpty()) {
            Button share = button("Inviter", true);
            toolbar.addView(share, new LinearLayout.LayoutParams(-2, dp(48)));
            share.setOnClickListener(view -> invite());
        }
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout callBar = new LinearLayout(this);
        callBar.setPadding(dp(10), 0, dp(10), dp(7));
        addCallButton(callBar, iconButton(R.drawable.ic_phone, "Appel audio"), "audio");
        addCallButton(callBar, iconButton(R.drawable.ic_video, "Appel vidéo"), "video");
        if (!room.privateRoom) addCallButton(callBar, button("Réunion", false), "meeting");
        root.addView(callBar, new LinearLayout.LayoutParams(-1, -2));

        View divider = new View(this);
        divider.setBackgroundColor(getColor(R.color.amis_border));
        root.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));

        FrameLayout timeline = new FrameLayout(this);
        list = new ListView(this);
        list.setDivider(null);
        list.setStackFromBottom(true);
        list.setClipToPadding(false);
        list.setPadding(dp(4), dp(10), dp(4), dp(10));
        timeline.addView(list, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout empty = column();
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(28), dp(10), dp(28), dp(10));
        TextView emptyTitle = label("La conversation commence ici", 20, getColor(R.color.amis_ink), true);
        emptyTitle.setGravity(Gravity.CENTER);
        empty.addView(emptyTitle);
        TextView emptyHint = label("Invite tes amis, puis envoie ton premier message.", 15, getColor(R.color.amis_muted), false);
        emptyHint.setGravity(Gravity.CENTER);
        add(empty, emptyHint, 8);
        timeline.addView(empty, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        list.setEmptyView(empty);
        bubbles = new Bubbles(history.messages(room.topic));
        list.setAdapter(bubbles);
        root.addView(timeline, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout compose = new LinearLayout(this);
        compose.setGravity(Gravity.BOTTOM);
        compose.setPadding(dp(12), dp(10), dp(12), dp(12));
        compose.setBackgroundColor(getColor(R.color.amis_surface));
        Button attach = button("+", false);
        attach.setTextSize(24);
        attach.setContentDescription("Joindre un fichier");
        LinearLayout.LayoutParams attachLayout = new LinearLayout.LayoutParams(dp(48), dp(50));
        attachLayout.rightMargin = dp(8);
        compose.addView(attach, attachLayout);
        attach.setOnClickListener(view -> {
            Intent choose = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            choose.addCategory(Intent.CATEGORY_OPENABLE);
            choose.setType("*/*");
            startActivityForResult(choose, PICK_ATTACHMENT);
        });
        ImageButton photo = iconButton(R.drawable.ic_photo, "Prendre une photo");
        LinearLayout.LayoutParams photoLayout = new LinearLayout.LayoutParams(dp(48), dp(50));
        photoLayout.rightMargin = dp(8);
        compose.addView(photo, photoLayout);
        photo.setOnClickListener(view -> takePhoto());
        composer = field("Écrire un message…", MESSAGE_LIMIT, true);
        composer.setText(drafts.read(room.topic));
        composer.setSelection(composer.length());
        compose.addView(composer, new LinearLayout.LayoutParams(0, -2, 1));
        Button send = button("Envoyer", true);
        LinearLayout.LayoutParams sendLayout = new LinearLayout.LayoutParams(-2, dp(50));
        sendLayout.leftMargin = dp(8);
        compose.addView(send, sendLayout);
        send.setOnClickListener(view -> sendNewMessage());
        root.addView(compose, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        root.requestFocus();
    }

    private void roomOptions() {
        String peer = contactPeer(preferences, room);
        String[] base = {"Rechercher dans le salon", "Modifier mon pseudo", "Changer de salon",
                "Tester la connexion", "Apparence", "Notifications", "Changer le mot de passe", contactsTitle(), "Mon profil"};
        String[] options = base;
        if (!peer.isEmpty()) {
            options = java.util.Arrays.copyOf(base, base.length + 1);
            options[base.length] = "Gérer ce contact";
        }
        new AlertDialog.Builder(this)
                .setTitle("Salon entre amis")
                .setItems(options,
                        (dialog, choice) -> {
                            if (choice == 0) searchHistory();
                            else if (choice == 1) rename();
                            else if (choice == 2) leaveRoom();
                            else if (choice == 3) testConnection();
                            else if (choice == 4) chooseAppearance();
                            else if (choice == 5) chooseNotifications();
                            else if (choice == 6) startActivity(UnlockActivity.forChange(this));
                            else if (choice == 7) openContacts(nickname);
                            else if (choice == 8) profile.show();
                            else contacts.manageContact(peer, roomLabel(room));
                        })
                .setNegativeButton("Fermer", null)
                .show();
    }

    private void chooseNotifications() {
        boolean enabled = preferences.getBoolean(RoomAlertService.ENABLED, false) && canNotify();
        new AlertDialog.Builder(this).setTitle("Notifications")
                .setMessage(enabled ? "La réception en arrière-plan est activée pour ce salon."
                        : "Reçois les nouveaux messages et invitations de ce salon quand Entre Amis est en arrière-plan. Android affiche une notification permanente pendant la surveillance.")
                .setPositiveButton(enabled ? "Désactiver" : "Activer", (dialog, which) -> {
                    if (enabled) {
                        preferences.edit().putBoolean(RoomAlertService.ENABLED, false).apply();
                        syncAlerts();
                    } else if (Build.VERSION.SDK_INT >= 33
                            && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
                    } else {
                        enableAlerts();
                    }
                })
                .setNeutralButton("Réglages Android", (dialog, which) -> openNotificationSettings())
                .setNegativeButton("Fermer", null).show();
    }

    private void openNotificationSettings() {
        Intent notifications = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        if (Build.VERSION.SDK_INT < 34) {
            startActivity(notifications);
            return;
        }
        new AlertDialog.Builder(this).setTitle("Réglages Android")
                .setItems(new String[]{"Notifications Android", "Appels en plein écran"}, (dialog, index) -> {
                    Intent selected = index == 0 ? notifications
                            : new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                    Uri.parse("package:" + getPackageName()));
                    try {
                        startActivity(selected);
                    } catch (android.content.ActivityNotFoundException unavailable) {
                        startActivity(notifications);
                    }
                }).setNegativeButton("Fermer", null).show();
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (!requireUnlock()) return;
        if (request == NOTIFICATION_PERMISSION && results.length > 0
                && results[0] == PackageManager.PERMISSION_GRANTED) enableAlerts();
        if (request == PHOTO_PERMISSION) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) takePhoto();
            else toast("Autorise la caméra pour prendre une photo.");
        }
    }

    private boolean canNotify() {
        return getSystemService(NotificationManager.class).areNotificationsEnabled();
    }

    private void enableAlerts() {
        if (canNotify()) {
            preferences.edit().putBoolean(RoomAlertService.ENABLED, true).apply();
            syncAlerts();
        } else {
            toast("Autorise les notifications Entre Amis dans les réglages Android.");
        }
    }

    private void syncAlerts() {
        Intent service = new Intent(this, RoomAlertService.class);
        if (room == null || !preferences.getBoolean(RoomAlertService.ENABLED, false) || !canNotify()) {
            stopService(service);
        } else if (visible) {
            try {
                startForegroundService(service);
            } catch (IllegalStateException | SecurityException failure) {
                toast("Android a interrompu les notifications. Rouvre Entre Amis pour les reprendre.");
            }
        }
    }

    private void chooseAppearance() {
        int current = preferences.getInt(APPEARANCE, FOLLOW_SYSTEM);
        new AlertDialog.Builder(this).setTitle("Apparence")
                .setSingleChoiceItems(new String[]{"Suivre le téléphone", "Clair", "Sombre"}, current,
                        (dialog, choice) -> {
                            dialog.dismiss();
                            if (choice != current) {
                                preferences.edit().putInt(APPEARANCE, choice).apply();
                                recreate();
                            }
                        })
                .setNegativeButton("Fermer", null).show();
    }

    private void testConnection() {
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Tester la connexion")
                .setMessage("Connexion à eklipse.tech…")
                .setNegativeButton("Fermer", null)
                .setPositiveButton("Copier le résultat", null).show();
        Button copy = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        copy.setEnabled(false);
        new Thread(() -> {
            String result = RelayDiagnostic.check(relay);
            ui.post(() -> {
                if (isDestroyed() || !dialog.isShowing()) return;
                dialog.setMessage(result);
                copy.setOnClickListener(view -> {
                    ClipboardManager clipboard = getSystemService(ClipboardManager.class);
                    clipboard.setPrimaryClip(ClipData.newPlainText("Diagnostic Entre Amis", result));
                    if (Build.VERSION.SDK_INT < 33) {
                        Toast.makeText(this, "Résultat copié", Toast.LENGTH_SHORT).show();
                    }
                });
                copy.setEnabled(true);
            });
        }, "entre-amis-connection").start();
    }

    private void searchHistory() {
        Room destination = room;
        if (destination == null) return;

        LinearLayout content = column();
        content.setPadding(dp(18), dp(8), dp(18), 0);
        EditText input = field("Mot, auteur ou nom de fichier", 100, false);
        content.addView(input, new LinearLayout.LayoutParams(-1, -2));
        CheckBox attachmentsOnly = new CheckBox(this);
        attachmentsOnly.setText("Pièces jointes uniquement");
        attachmentsOnly.setTextColor(getColor(R.color.amis_ink));
        content.addView(attachmentsOnly);
        TextView feedback = label("Recherche dans les messages enregistrés sur ce téléphone.", 13, getColor(R.color.amis_muted), false);
        feedback.setPadding(0, dp(6), 0, dp(5));
        content.addView(feedback, new LinearLayout.LayoutParams(-1, -2));
        ListView results = new ListView(this);
        results.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1));
        content.addView(results, new LinearLayout.LayoutParams(-1, dp(224)));

        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Rechercher dans le salon")
                .setView(content).setNegativeButton("Fermer", null).create();
        AtomicInteger generation = new AtomicInteger();
        dialog.setOnDismissListener(ignored -> {
            generation.incrementAndGet();
            ui.removeCallbacksAndMessages(dialog);
        });
        Runnable updateSearch = () -> {
            int requested = generation.incrementAndGet();
            ui.removeCallbacksAndMessages(dialog);
            results.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1));
            results.setOnItemClickListener(null);
            MessageSearch search = new MessageSearch(input.getText().toString(), attachmentsOnly.isChecked());
            if (search.isEmpty()) {
                feedback.setText("Saisis un mot ou coche « Pièces jointes uniquement ».");
                return;
            }
            feedback.setText("Recherche…");
            ui.postAtTime(() -> {
                if (!dialog.isShowing() || isDestroyed()) return;
                searchWorker.execute(() -> showSearchResults(destination, search, generation,
                        requested, dialog, results, feedback));
            }, dialog, SystemClock.uptimeMillis() + 180);
        };
        attachmentsOnly.setOnCheckedChangeListener((button, checked) -> updateSearch.run());
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence value, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence value, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable value) {
                updateSearch.run();
            }
        });
        dialog.show();
    }

    private void showSearchResults(Room destination, MessageSearch search, AtomicInteger generation,
                                   int requested, AlertDialog dialog, ListView results, TextView feedback) {
        final int maxResults = 30;
        List<Long> ids = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        DateFormat date = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
        try (Cursor cursor = history.searchableMessages(destination.topic)) {
            while (ids.size() < maxResults && generation.get() == requested
                    && !Thread.currentThread().isInterrupted() && cursor.moveToNext()) {
                String author = cursor.getString(1);
                String body = cursor.getString(2);
                Attachment file = readAttachment(cursor.getString(4));
                String attachment = file == null ? "" : file.name;
                if (!search.matches(author, body, attachment)) continue;
                ids.add(cursor.getLong(0));
                labels.add(author + " · " + date.format(new Date(cursor.getLong(3)))
                        + "\n" + MessageSearch.preview(body, attachment));
            }
        } catch (RuntimeException error) {
            ui.post(() -> {
                if (dialog.isShowing() && generation.get() == requested) {
                    feedback.setText("Impossible de lire l’historique local.");
                }
            });
            return;
        }
        ui.post(() -> {
            if (!dialog.isShowing() || generation.get() != requested || room != destination) return;
            results.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels));
            feedback.setText(ids.isEmpty() ? "Aucun résultat dans l’historique local."
                    : ids.size() == maxResults ? "30 résultats les plus récents." : ids.size() + " résultat(s).");
            results.setOnItemClickListener((parent, view, position, id) -> {
                dialog.dismiss();
                revealMessage(destination, ids.get(position));
            });
        });
    }

    private void revealMessage(Room destination, long rowId) {
        if (room != destination || bubbles == null || list == null) return;
        Cursor cursor = bubbles.getCursor();
        if (cursor == null) return;
        int oldPosition = cursor.getPosition();
        int match = -1;
        try {
            for (int index = cursor.getCount() - 1; index >= 0; index--) {
                if (!cursor.moveToPosition(index)) break;
                long candidate = cursor.getLong(0);
                if (candidate == rowId) {
                    match = index;
                    break;
                }
                if (candidate < rowId) break;
            }
        } finally {
            cursor.moveToPosition(oldPosition);
        }
        if (match >= 0) list.setSelectionFromTop(match, dp(12));
        else toast("Ce message n’est plus disponible dans le salon.");
    }

    private void rename() {
        EditText name = field("Ton pseudo", 30, false);
        name.setText(nickname);
        name.setSelection(nickname.length());
        FrameLayout frame = new FrameLayout(this);
        FrameLayout.LayoutParams layout = new FrameLayout.LayoutParams(-1, -2);
        layout.setMargins(dp(22), dp(8), dp(22), dp(8));
        frame.addView(name, layout);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Ton pseudo").setView(frame)
                .setPositiveButton("Enregistrer", null).setNegativeButton("Annuler", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    String value = name.getText().toString().trim();
                    if (value.isEmpty()) {
                        name.setError("Choisis un pseudo.");
                        return;
                    }
                    saveNickname(value);
                    dialog.dismiss();
                }));
        dialog.show();
    }

    private void leaveRoom() {
        new AlertDialog.Builder(this)
                .setTitle("Changer de salon")
                .setMessage("Tu peux retrouver ce salon et son historique dans Mes conversations.")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Changer", (dialog, which) -> clearRoom()).show();
    }

    private void clearRoom() {
        if (room == null) return;
        stopReceiver();
        stopCallWatcher();
        dismissRing();
        saveDraft();
        rememberRoom(room);
        preferences.edit().remove("room").apply();
        room = null;
        syncAlerts();
        downloadUid = null;
        downloadFile = null;
        composer = null;
        status = null;
        if (bubbles != null) bubbles.changeCursor(null);
        bubbles = null;
        list = null;
        showHome();
    }

    private void invite() {
        final String code = room.invite;
        TextView message = label(code, 17, getColor(R.color.amis_ink), true);
        message.setTextIsSelectable(true);
        message.setPadding(dp(24), dp(12), dp(24), dp(8));
        message.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        new AlertDialog.Builder(this).setTitle("Code d’invitation")
                .setMessage(room.privateRoom ? "Partage ce code privé avec un seul ami."
                        : "Partage ce code avec les amis que tu veux inviter.")
                .setView(message)
                .setNeutralButton("Par SMS", (dialog, which) -> pickPhoneContact())
                .setNegativeButton("Copier", (dialog, which) ->
                        copySensitiveText("Invitation Entre Amis", code, "Code copié."))
                .setPositiveButton("Partager", (dialog, which) -> {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_TEXT, code);
                    startActivity(Intent.createChooser(intent, "Envoyer le code d’invitation"));
                }).show();
    }

    private void pickPhoneContact() {
        if (!requireUnlock() || phoneInviteTopic != null) return;
        phoneInviteTopic = room == null ? "" : room.topic;
        try {
            startActivityForResult(new Intent(Intent.ACTION_PICK).setType(Phone.CONTENT_TYPE), PICK_PHONE_CONTACT);
        } catch (android.content.ActivityNotFoundException unavailable) {
            phoneInviteTopic = null;
            toast("Le sélecteur de contacts est indisponible.");
        }
    }

    private void sendPhoneInvitation(Uri contact, String topic) {
        Room destination = room;
        if (contact == null || topic == null || !"content".equals(contact.getScheme())
                || !topic.equals(destination == null ? "" : destination.topic)) return;
        String number = "";
        try (Cursor picked = getContentResolver().query(contact, new String[]{Phone.NUMBER}, null, null, null)) {
            if (picked != null && picked.moveToFirst()) {
                int column = picked.getColumnIndex(Phone.NUMBER);
                if (column >= 0 && !picked.isNull(column)) number = PhoneNumberUtils.normalizeNumber(picked.getString(column));
            }
        } catch (SecurityException | IllegalArgumentException unavailable) {
            toast("Impossible de lire le numéro sélectionné.");
            return;
        }
        if (!number.matches("\\+?[0-9]+")) {
            toast("Ce contact n’a pas de numéro utilisable pour un SMS.");
            return;
        }
        boolean createPrivateRoom = destination == null;
        try {
            if (createPrivateRoom) destination = Room.create(true);
            String message = "Rejoins-moi sur Entre Amis. Dans l’application, colle ce code d’invitation, puis touche « Rejoindre le salon ».\n"
                    + destination.invite;
            startActivity(new Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", number, null))
                    .putExtra("sms_body", message));
            if (createPrivateRoom) showRoom(destination, nickname);
        } catch (android.content.ActivityNotFoundException unavailable) {
            toast("Aucune application SMS n’est disponible.");
        } catch (GeneralSecurityException error) {
            toast("Impossible de créer l’invitation.");
        }
    }

    private void copySensitiveText(String label, String text, String feedback) {
        ClipboardManager clipboard = getSystemService(ClipboardManager.class);
        ClipData clip = ClipData.newPlainText(label, text);
        if (Build.VERSION.SDK_INT >= 33) {
            android.os.PersistableBundle extras = new android.os.PersistableBundle();
            extras.putBoolean(android.content.ClipDescription.EXTRA_IS_SENSITIVE, true);
            clip.getDescription().setExtras(extras);
        }
        clipboard.setPrimaryClip(clip);
        if (Build.VERSION.SDK_INT < 33) {
            toast(feedback);
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == CAPTURE_PHOTO) {
            reviewCapture(result);
            return;
        }
        if (request == PICK_PHONE_CONTACT) {
            String topic = phoneInviteTopic;
            phoneInviteTopic = null;
            if (result == RESULT_OK && data != null && requireUnlock()) sendPhoneInvitation(data.getData(), topic);
            return;
        }
        if (!requireUnlock()) return;
        Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
        if (request == PICK_ATTACHMENT && uri != null && room != null) {
            stageAttachment(uri, room, nickname);
        }
        if (request == SAVE_ATTACHMENT) {
            if (uri != null && room != null && downloadUid != null && downloadFile != null) {
                saveAttachment(uri, room, downloadUid, downloadFile);
            }
            downloadUid = null;
            downloadFile = null;
        }
    }

    private void takePhoto() {
        if (room == null || capture != null || !requireUnlock()) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, PHOTO_PERMISSION);
            return;
        }
        try {
            capture = PhotoProvider.create(this);
            captureTopic = room.topic;
            Uri photo = PhotoProvider.uri(this, capture);
            Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, photo);
            camera.setClipData(ClipData.newRawUri("Photo", photo));
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(camera, CAPTURE_PHOTO);
        } catch (IOException | android.content.ActivityNotFoundException | SecurityException unavailable) {
            discardCapture();
            toast("Appareil photo indisponible.");
        }
    }

    private void discardCapture() {
        if (capture == null) return;
        revokeUriPermission(PhotoProvider.uri(this, capture),
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        capture.delete();
        capture = null;
        captureTopic = null;
    }

    private void reviewCapture(int result) {
        if (capture == null) return;
        if (!requireUnlock() || result != RESULT_OK || room == null || !room.topic.equals(captureTopic)) {
            discardCapture();
            return;
        }
        File photo = capture;
        revokeUriPermission(PhotoProvider.uri(this, photo),
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        capture = null;
        captureTopic = null;
        if (photo.length() == 0) {
            photo.delete();
            toast("La caméra n’a pas enregistré la photo.");
            return;
        }
        photoReview = photo;
        Room destination = room;
        String name = nickname;
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Envoyer la photo ?")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Envoyer", (window, which) -> {
                    if (!requireUnlock() || room != destination) return;
                    photoReview = null;
                    sender.execute(() -> {
                        try {
                            byte[] jpeg = CapturedPhoto.jpeg(photo);
                            storeAttachment(destination, name, "Photo-" + System.currentTimeMillis() + ".jpg",
                                    "image/jpeg", jpeg);
                        } catch (IOException | GeneralSecurityException | RuntimeException error) {
                            ui.post(() -> toast("Impossible de préparer la photo."));
                        } finally {
                            photo.delete();
                        }
                    });
                }).create();
        dialog.setOnDismissListener(window -> {
            if (photoReview == photo) {
                photoReview = null;
                photo.delete();
            }
        });
        dialog.show();
    }

    private void stageAttachment(Uri uri, Room destination, String name) {
        sender.execute(() -> {
            try {
                String fileName = null;
                try (Cursor info = getContentResolver().query(uri,
                        new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                    if (info != null && info.moveToFirst()) {
                        fileName = info.getString(0);
                    }
                }
                byte[] bytes;
                try (InputStream input = getContentResolver().openInputStream(uri)) {
                    bytes = Attachment.read(input, Attachment.MAX_SIZE);
                }
                if (bytes.length == 0) {
                    ui.post(() -> toast("Ce fichier est vide."));
                    return;
                }
                storeAttachment(destination, name, fileName, getContentResolver().getType(uri), bytes);
            } catch (Attachment.TooLarge error) {
                ui.post(() -> toast("Choisis un fichier de 2 Mo maximum."));
            } catch (IOException | GeneralSecurityException | RuntimeException error) {
                ui.post(() -> toast("Impossible de lire cette pièce jointe."));
            }
        });
    }

    private void storeAttachment(Room destination, String name, String fileName, String mime, byte[] bytes)
            throws IOException, GeneralSecurityException {
        String uid = UUID.randomUUID().toString();
        Attachment file = new Attachment(fileName, mime, bytes.length);
        File stored = outgoing(uid);
        if (!stored.getParentFile().isDirectory() && !stored.getParentFile().mkdirs()) {
            throw new IOException("Dossier indisponible");
        }
        try (FileOutputStream output = new FileOutputStream(stored)) {
            output.write(destination.encryptFile(uid, bytes));
        } catch (IOException | GeneralSecurityException error) {
            stored.delete();
            throw error;
        }
        String body = "Pièce jointe · " + file.name;
        history.insert(destination.topic, uid, device, name, body,
                System.currentTimeMillis(), false, attachmentData(file), false);
        ui.post(() -> {
            if (!isDestroyed() && room == destination) {
                send(destination, uid, name, body, file);
                refresh(true);
            }
        });
    }

    private File outgoing(String uid) {
        return new File(new File(getFilesDir(), "outgoing"), uid);
    }

    private void chooseSave(String uid, Attachment file) {
        downloadUid = uid;
        downloadFile = file;
        Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        save.addCategory(Intent.CATEGORY_OPENABLE);
        save.setType(file.type);
        save.putExtra(Intent.EXTRA_TITLE, file.name);
        startActivityForResult(save, SAVE_ATTACHMENT);
    }

    private void saveAttachment(Uri uri, Room destination, String uid, Attachment file) {
        toast("Téléchargement en cours…");
        sender.execute(() -> {
            String result;
            try {
                JSONObject response = new JSONObject(relay.fetchFile(destination, uid));
                byte[] encrypted = Base64.getUrlDecoder().decode(response.getString("file"));
                byte[] bytes = destination.decryptFile(uid, encrypted);
                if (bytes.length != file.size) {
                    throw new IOException("Taille incorrecte");
                }
                try (OutputStream output = getContentResolver().openOutputStream(uri, "wt")) {
                    if (output == null) {
                        throw new IOException("Dossier indisponible");
                    }
                    output.write(bytes);
                }
                result = "Pièce jointe enregistrée.";
            } catch (IOException | JSONException | GeneralSecurityException | RuntimeException error) {
                try {
                    DocumentsContract.deleteDocument(getContentResolver(), uri);
                } catch (IOException | RuntimeException ignored) {
                    // Some document providers do not allow removing a newly created file.
                }
                result = error instanceof Relay.HttpError && ((Relay.HttpError) error).code == 404
                        ? "Cette pièce jointe n’est plus disponible."
                        : "Téléchargement interrompu. Appuie sur le fichier pour réessayer.";
            }
            final String feedback = result;
            ui.post(() -> toast(feedback));
        });
    }

    private String attachmentData(Attachment file) {
        try {
            return file.json().toString();
        } catch (JSONException error) {
            throw new IllegalStateException(error);
        }
    }

    private Attachment readAttachment(String data) {
        if (data.isEmpty()) {
            return null;
        }
        try {
            return Attachment.fromJson(new JSONObject(data));
        } catch (JSONException | IllegalArgumentException error) {
            return null;
        }
    }

    private void saveDraft() {
        if (room != null && composer != null) {
            drafts.write(room.topic, composer.getText().toString());
        }
    }

    private void sendNewMessage() {
        String body = composer.getText().toString().trim();
        if (body.isEmpty()) {
            return;
        }
        String uid = UUID.randomUUID().toString();
        history.insert(room.topic, uid, device, nickname, body, System.currentTimeMillis(), false, "", false);
        composer.setText("");
        saveDraft();
        send(room, uid, nickname, body, null);
        refresh(true);
    }

    private void send(Room destination, String uid, String name, String body, Attachment file) {
        if (!sending.add(uid)) {
            return;
        }
        sender.execute(() -> {
            String failure = null;
            try {
                JSONObject message = new JSONObject();
                message.put("uid", uid);
                message.put("device", device);
                message.put("nickname", name);
                message.put("body", body);
                byte[] encryptedFile = null;
                if (file != null) {
                    message.put("attachment", file.json());
                    try (InputStream input = new FileInputStream(outgoing(uid))) {
                        encryptedFile = Attachment.read(input, Attachment.MAX_PACKET);
                    }
                }
                relay.publish(destination, uid, destination.encrypt(message.toString()), encryptedFile,
                        Room.ownerHash(ownerProof));
                history.delivered(destination.topic, uid);
                history.managed(destination.topic, uid);
                if (file != null) {
                    outgoing(uid).delete();
                }
            } catch (Relay.HttpError exception) {
                failure = exception.code == 404
                        ? (file == null ? "Le relais Eclipse doit être activé." : "Installe le relais Eclipse 1.1 pour envoyer des fichiers.")
                        : file != null && exception.code == 413 ? "Mets à jour le relais Eclipse ou choisis un fichier plus petit."
                        : exception.code == 429 ? "Limite d’envoi atteinte. Réessaie plus tard."
                        : "Envoi interrompu. Appuie sur le message pour réessayer.";
            } catch (IOException | JSONException | GeneralSecurityException exception) {
                failure = "Envoi interrompu. Appuie sur le message pour réessayer.";
            }
            final String result = failure;
            ui.post(() -> {
                sending.remove(uid);
                if (!isDestroyed() && room == destination) {
                    refresh(false);
                    if (result != null && visible) {
                        toast(result);
                    }
                }
            });
        });
    }

    private void messageOptions(String uid, String name, String body, Attachment file, boolean managed) {
        Room destination = room;
        List<String> choices = new ArrayList<>();
        List<Runnable> actions = new ArrayList<>();
        if (file == null && !body.isEmpty()) {
            choices.add("Copier le texte");
            actions.add(() -> copySensitiveText("Message Entre Amis", body, "Texte copié."));
        }
        if (managed && file == null) {
            choices.add("Modifier");
            actions.add(() -> editMessage(destination, uid, name, body));
        }
        if (managed) {
            choices.add("Supprimer pour tous");
            actions.add(() -> new AlertDialog.Builder(this).setTitle("Supprimer pour tous ?")
                    .setNegativeButton("Annuler", null).setPositiveButton("Supprimer",
                            (dialog, which) -> changeMessage(destination, uid, name, "", "delete")).show());
        }
        choices.add("Supprimer pour moi");
        actions.add(() -> { history.hide(destination.topic, uid); refresh(false); });
        new AlertDialog.Builder(this).setTitle("Message").setItems(choices.toArray(new String[0]),
                (dialog, index) -> actions.get(index).run()).setNegativeButton("Fermer", null).show();
    }

    private void editMessage(Room destination, String uid, String name, String oldBody) {
        EditText edit = field("Texte du message", MESSAGE_LIMIT, true);
        edit.setText(oldBody);
        edit.setSelection(oldBody.length());
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Modifier le message").setView(edit)
                .setNegativeButton("Annuler", null).setPositiveButton("Enregistrer", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String text = edit.getText().toString().trim();
            if (text.isEmpty()) { edit.setError("Écris un message."); return; }
            if (!text.equals(oldBody)) changeMessage(destination, uid, name, text, "edit");
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void changeMessage(Room destination, String uid, String name, String body, String operation) {
        sender.execute(() -> {
            try {
                String eventId = UUID.randomUUID().toString();
                JSONObject event = new JSONObject();
                event.put("event", eventId).put("action", operation).put("target", uid)
                        .put("device", device).put("body", body);
                JSONObject request = new JSONObject();
                request.put("event", eventId).put("operation", operation)
                        .put("payload", destination.encrypt(event.toString()));
                if (operation.equals("edit")) {
                    JSONObject replacement = new JSONObject();
                    replacement.put("uid", uid).put("device", device).put("nickname", name)
                            .put("body", body).put("edited", true);
                    request.put("replacement", destination.encrypt(replacement.toString()));
                }
                relay.change(destination, uid, ownerProof, request.toString());
                ui.post(() -> toast(operation.equals("edit") ? "Modification envoyée." : "Suppression envoyée."));
            } catch (IOException | JSONException | GeneralSecurityException error) {
                ui.post(() -> toast("Action indisponible. Vérifie le relais Eclipse et l’âge du message."));
            }
        });
    }

    private void addCallButton(LinearLayout bar, View start, String mode) {
        LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(0, dp(48), 1);
        layout.setMargins(dp(3), 0, dp(3), 0);
        bar.addView(start, layout);
        start.setOnClickListener(view -> launchCall(mode, null));
    }

    private ImageButton iconButton(int icon, String description) {
        ImageButton button = new ImageButton(this);
        button.setContentDescription(description);
        button.setTooltipText(description);
        button.setImageResource(icon);
        button.setImageTintList(ColorStateList.valueOf(getColor(R.color.amis_accent)));
        int color = getColor(R.color.amis_pale);
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(getColor(R.color.amis_ripple)),
                rounded(color, color, 13), null));
        return button;
    }

    private void launchCall(String mode, CallChannel.Signal signal) {
        if (room == null || openingCall) return;
        openingCall = true;
        dismissRing();
        startActivity(CallActivity.intent(this, room, device, nickname, mode, signal));
    }

    private void startCallWatcher() {
        if (callWatcher != null) return;
        callWatcher = new CallChannel(relay, room, device, "", callCursor, ui, new CallChannel.Listener() {
            @Override public void signals(CallChannel channel, long cursor, List<CallChannel.Signal> signals) {
                if (callWatcher != channel) return;
                callCursor = cursor;
                for (CallChannel.Signal signal : signals) {
                    if (signal.call.equals(currentRing) && signal.sender.equals(ringingDevice)
                            && (signal.kind.equals("end") || signal.kind.equals("taken"))) dismissRing();
                    if (signal.age < 30 && signal.kind.startsWith("ring-") && ringDialog == null
                            && !openingCall && visible) showRing(signal);
                }
            }

            @Override public void error(CallChannel channel, IOException error) {
                // Text conversations remain available while the call relay is unavailable.
            }
        });
        callWatcher.start();
    }

    private void stopCallWatcher() {
        if (callWatcher != null) {
            callWatcher.interrupt();
            callWatcher = null;
        }
    }

    private String dismissedRing;

    private void showRing(CallChannel.Signal signal) {
        String mode = signal.kind.substring(5);
        if (signal.call.equals(dismissedRing) || RoomAlertService.wasRejected(signal.call)
                || !(mode.equals("audio") || mode.equals("video")
                || mode.equals("meeting")) || (mode.equals("meeting") && room.privateRoom)) return;
        currentRing = signal.call;
        ringingDevice = signal.sender;
        String from = signal.data.trim();
        if (from.length() > 30 || from.isEmpty()) from = "Un ami";
        ringDialog = new AlertDialog.Builder(this).setTitle(CallActivity.title(mode))
                .setMessage(from + (mode.equals("meeting") ? " t’invite à une réunion." : " t’appelle."))
                .setNegativeButton("Refuser", (dialog, which) -> dismissedRing = signal.call)
                .setPositiveButton("Rejoindre", (dialog, which) -> launchCall(mode, signal)).create();
        AlertDialog dialog = ringDialog;
        dialog.setOnDismissListener(ignored -> {
            if (ringDialog == dialog) dismissRing();
        });
        dialog.show();
        ui.postDelayed(() -> { if (ringDialog == dialog) dismissRing(); }, (30 - signal.age) * 1000);
    }

    private void dismissRing() {
        AlertDialog previous = ringDialog;
        ringDialog = null;
        currentRing = null;
        ringingDevice = null;
        if (previous != null) previous.dismiss();
    }

    private void startReceiver() {
        if (!visible || room == null || receiver != null || !contactAllowed(preferences, room)) {
            return;
        }
        status.setVisibility(View.GONE);
        receiver = new Receiver(room);
        receiver.start();
        startCallWatcher();
        refresh(false);
    }

    private void stopReceiver() {
        if (receiver != null) {
            receiver.interrupt();
            receiver = null;
        }
    }

    private final class Receiver extends Thread {
        final Room destination;

        Receiver(Room destination) {
            super("EntreAmis-reception");
            this.destination = destination;
        }

        @Override public void run() {
            long pause = 0;
            long backoff = 5000;
            while (!isInterrupted()) {
                try {
                    Thread.sleep(pause);
                    long after = history.lastId(destination.topic);
                    JSONObject page = new JSONObject(relay.poll(destination, after));
                    if (isInterrupted()) {
                        return;
                    }
                    JSONArray messages = page.getJSONArray("messages");
                    for (int index = 0; index < messages.length(); index++) {
                        if (isInterrupted()) {
                            return;
                        }
                        JSONObject envelope = messages.getJSONObject(index);
                        long serverId = envelope.getLong("id");
                        if (serverId > after) {
                            receive(envelope, serverId);
                            after = serverId;
                        }
                    }
                    update(null, messages.length() > 0);
                    pause = page.optBoolean("more") ? 750 : 6500;
                    backoff = 5000;
                } catch (InterruptedException stopped) {
                    return;
                } catch (Relay.HttpError error) {
                    String text = error.code == 404 ? "Relais de messagerie à activer"
                            : error.code == 403 ? "Accès au relais refusé"
                            : error.code == 429 ? "Relais occupé · nouvel essai"
                            : "Relais indisponible · nouvel essai";
                    update(text, false);
                    pause = Math.max(backoff, error.retryMs);
                    backoff = Math.min(60_000, backoff * 2);
                } catch (IOException | JSONException error) {
                    update("Connexion interrompue · nouvel essai", false);
                    pause = backoff;
                    backoff = Math.min(60_000, backoff * 2);
                }
            }
        }

        private void receive(JSONObject envelope, long serverId) {
            try {
                JSONObject message = new JSONObject(destination.decrypt(envelope.getString("payload")));
                String action = envelope.optString("action_type", "");
                if (action.equals("edit") || action.equals("delete")) {
                    String target = envelope.getString("action_target");
                    String author = message.getString("device");
                    String body = message.optString("body", "").trim();
                    if (!target.matches(UUID_FORMAT) || !author.matches(UUID_FORMAT)
                            || !target.equals(message.optString("target")) || !action.equals(message.optString("action"))
                            || !envelope.getString("uid").equals(message.optString("event"))
                            || (action.equals("edit") && (body.isEmpty() || body.length() > MESSAGE_LIMIT))) {
                        throw new IllegalArgumentException("Modification invalide");
                    }
                    history.applyChange(destination.topic, target, author, body, action.equals("delete"), serverId);
                    return;
                }
                String uid = message.getString("uid");
                String origin = message.getString("device");
                String name = message.getString("nickname").trim();
                String text = message.getString("body").trim();
                long time = envelope.getLong("created");
                if (!uid.equals(envelope.getString("uid")) || !uid.matches(UUID_FORMAT)
                        || !origin.matches(UUID_FORMAT) || name.isEmpty() || name.length() > 30
                        || text.isEmpty() || text.length() > MESSAGE_LIMIT || time <= 0) {
                    throw new IllegalArgumentException("Message invalide");
                }
                JSONObject data = message.optJSONObject("attachment");
                Attachment file = data == null ? null : readAttachment(data.toString());
                history.received(destination.topic, uid, origin, name, text, time, serverId,
                        file == null ? "" : attachmentData(file), message.optBoolean("edited"));
                if (origin.equals(device) && !envelope.isNull("action_type")) history.managed(destination.topic, uid);
            } catch (GeneralSecurityException | JSONException | IllegalArgumentException badMessage) {
                history.advance(destination.topic, serverId);
            }
        }

        private void update(String error, boolean changed) {
            ui.post(() -> {
                if (receiver == this && status != null) {
                    status.setText(error);
                    status.setVisibility(error == null ? View.GONE : View.VISIBLE);
                    if (changed) {
                        refresh(false);
                    }
                }
            });
        }
    }

    private void refresh(boolean bottom) {
        if (bubbles == null || list == null) {
            return;
        }
        boolean follow = bottom || list.getLastVisiblePosition() >= bubbles.getCount() - 2;
        int first = list.getFirstVisiblePosition();
        View top = list.getChildAt(0);
        int offset = top == null ? 0 : top.getTop();
        bubbles.changeCursor(history.messages(room.topic));
        if (follow && bubbles.getCount() > 0) {
            list.setSelection(bubbles.getCount() - 1);
        } else if (first >= 0 && first < bubbles.getCount()) {
            list.setSelectionFromTop(first, offset);
        }
    }

    private final class Bubbles extends CursorAdapter {
        private final DateFormat timeFormat = android.text.format.DateFormat.getTimeFormat(MainActivity.this);
        private final DateFormat dateFormat = android.text.format.DateFormat.getMediumDateFormat(MainActivity.this);

        Bubbles(Cursor cursor) {
            super(MainActivity.this, cursor, 0);
        }

        @Override public View newView(android.content.Context context, Cursor cursor, ViewGroup parent) {
            return new Bubble();
        }

        @Override public void bindView(View view, android.content.Context context, Cursor cursor) {
            Bubble row = (Bubble) view;
            String uid = cursor.getString(1);
            boolean own = device.equals(cursor.getString(2));
            String name = cursor.getString(3);
            String body = cursor.getString(4);
            Date time = new Date(cursor.getLong(5));
            boolean sent = cursor.getInt(6) != 0;
            boolean pending = own && !sent && sending.contains(uid);
            Attachment file = readAttachment(cursor.getString(7));
            boolean managed = own && sent && cursor.getInt(8) != 0;
            boolean edited = cursor.getInt(9) != 0;

            row.name.setText(own ? "Moi" : name);
            row.name.setTextColor(own ? getColor(R.color.amis_on_primary) : getColor(R.color.amis_accent));
            row.body.setText(body);
            row.body.setTextColor(own ? getColor(R.color.amis_on_primary) : getColor(R.color.amis_ink));
            String date = android.text.format.DateUtils.isToday(time.getTime())
                    ? timeFormat.format(time) : dateFormat.format(time) + " · " + timeFormat.format(time);
            String note = own ? (sent ? " · Envoyé" : pending ? " · Envoi…" : " · Toucher pour réessayer") : "";
            row.time.setText(date + note + (edited ? " · Modifié" : ""));
            row.time.setTextColor(own ? getColor(R.color.amis_on_primary_muted) : getColor(R.color.amis_muted));

            FrameLayout.LayoutParams position = (FrameLayout.LayoutParams) row.card.getLayoutParams();
            position.gravity = own ? Gravity.END : Gravity.START;
            row.card.setLayoutParams(position);
            int primary = getColor(R.color.amis_primary);
            row.card.setBackground(rounded(own ? primary : getColor(R.color.amis_surface),
                    own ? primary : getColor(R.color.amis_border), 17));
            row.card.setOnClickListener(own && !sent && !pending
                    ? clicked -> { send(room, uid, name, body, file); refresh(false); } : null);
            boolean downloadable = file != null && sent;
            row.save.setVisibility(downloadable ? View.VISIBLE : View.GONE);
            row.save.setOnClickListener(downloadable ? clicked -> chooseSave(uid, file) : null);
            if (downloadable) {
                row.save.setText("Enregistrer · " + android.text.format.Formatter.formatShortFileSize(
                        MainActivity.this, file.size));
            }
            row.card.setClickable(own && !sent && !pending);
            row.card.setOnLongClickListener(pressed -> {
                messageOptions(uid, name, body, file, managed);
                return true;
            });
        }
    }

    private final class Bubble extends FrameLayout {
        final LinearLayout card = column();
        final TextView name = label("", 13, getColor(R.color.amis_accent), true);
        final TextView body = label("", 16, getColor(R.color.amis_ink), false);
        final TextView time = label("", 12, getColor(R.color.amis_muted), false);
        final Button save = button("Enregistrer", false);

        Bubble() {
            super(MainActivity.this);
            setPadding(dp(10), dp(4), dp(10), dp(4));
            card.setPadding(dp(14), dp(9), dp(14), dp(9));
            int max = dp(Math.min(400, getResources().getConfiguration().screenWidthDp * 3 / 4)) - dp(28);
            name.setMaxWidth(max);
            body.setMaxWidth(max);
            time.setMaxWidth(max);
            card.addView(name);
            add(card, body, 3);
            add(card, time, 5);
            add(card, save, 8);
            addView(card, new FrameLayout.LayoutParams(-2, -2));
        }
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private void add(LinearLayout parent, View view, int marginTop) {
        LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(-1, -2);
        layout.topMargin = dp(marginTop);
        parent.addView(view, layout);
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(color);
        view.setTextSize(size);
        if (bold) {
            view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }
        return view;
    }

    private EditText field(String hint, int limit, boolean multiline) {
        EditText view = new EditText(this);
        view.setTextSize(16);
        view.setTextColor(getColor(R.color.amis_ink));
        view.setHintTextColor(getColor(R.color.amis_muted));
        view.setHint(hint);
        view.setSingleLine(!multiline);
        view.setMaxLines(multiline ? 4 : 1);
        if (multiline) {
            view.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                    | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        }
        view.setFilters(new InputFilter[]{new InputFilter.LengthFilter(limit)});
        view.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence text, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence text, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable text) { lock.touch(); }
        });
        view.setMinHeight(dp(50));
        view.setPadding(dp(13), dp(10), dp(13), dp(10));
        view.setBackground(rounded(getColor(R.color.amis_surface), getColor(R.color.amis_border), 13));
        return view;
    }

    private Button button(String text, boolean filled) {
        Button view = new Button(this);
        view.setAllCaps(false);
        view.setText(text);
        view.setTextSize(15);
        view.setTextColor(filled ? getColor(R.color.amis_on_primary) : getColor(R.color.amis_accent));
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setStateListAnimator(null);
        view.setMinWidth(0);
        view.setMinimumWidth(0);
        view.setMinHeight(dp(48));
        view.setPadding(dp(12), dp(7), dp(12), dp(7));
        int color = filled ? getColor(R.color.amis_primary) : getColor(R.color.amis_pale);
        view.setBackground(new RippleDrawable(ColorStateList.valueOf(filled ? 0x44ffffff : getColor(R.color.amis_ripple)),
                rounded(color, color, 13), null));
        return view;
    }

    private GradientDrawable rounded(int color, int stroke, int radius) {
        GradientDrawable background = new GradientDrawable();
        background.setColor(color);
        background.setCornerRadius(dp(radius));
        background.setStroke(dp(1), stroke);
        return background;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
