package fr.entreamis.chat;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

final class History extends SQLiteOpenHelper {
    static final String[] COLUMNS = {"_id", "uid", "device", "nickname", "body", "created", "sent", "attachment", "managed", "edited"};
    private static final String[] CURSOR_COLUMN = {"last_id"};

    History(Context context) {
        super(context, "conversations.db", null, 3);
        setWriteAheadLoggingEnabled(true);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE messages (_id INTEGER PRIMARY KEY, topic TEXT NOT NULL, "
                + "uid TEXT NOT NULL, device TEXT NOT NULL, nickname TEXT NOT NULL, "
                + "body TEXT NOT NULL, created INTEGER NOT NULL, sent INTEGER NOT NULL, "
                + "attachment TEXT NOT NULL DEFAULT '', managed INTEGER NOT NULL DEFAULT 0, "
                + "edited INTEGER NOT NULL DEFAULT 0, hidden INTEGER NOT NULL DEFAULT 0, "
                + "UNIQUE(topic, uid))");
        db.execSQL("CREATE INDEX by_conversation ON messages (topic, _id)");
        db.execSQL("CREATE TABLE sync_cursor (topic TEXT PRIMARY KEY, last_id INTEGER NOT NULL)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE messages ADD COLUMN attachment TEXT NOT NULL DEFAULT ''");
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE messages ADD COLUMN managed INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE messages ADD COLUMN edited INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE messages ADD COLUMN hidden INTEGER NOT NULL DEFAULT 0");
        }
    }

    Cursor messages(String topic) {
        return getReadableDatabase().query("messages", COLUMNS, "topic=? AND hidden=0", new String[]{topic},
                null, null, "_id ASC");
    }

    Cursor searchableMessages(String topic) {
        return getReadableDatabase().query("messages",
                new String[]{"_id", "nickname", "body", "created", "attachment"},
                "topic=? AND hidden=0", new String[]{topic}, null, null, "_id DESC");
    }

    long lastId(String topic) {
        try (Cursor cursor = getReadableDatabase().query("sync_cursor", CURSOR_COLUMN, "topic=?",
                new String[]{topic}, null, null, null)) {
            return cursor.moveToFirst() ? cursor.getLong(0) : 0;
        }
    }

    void insert(String topic, String uid, String device, String name, String body, long time,
                boolean sent, String attachment, boolean edited) {
        ContentValues values = new ContentValues();
        values.put("topic", topic);
        values.put("uid", uid);
        values.put("device", device);
        values.put("nickname", name);
        values.put("body", body);
        values.put("created", time);
        values.put("sent", sent ? 1 : 0);
        values.put("attachment", attachment);
        values.put("edited", edited ? 1 : 0);
        getWritableDatabase().insertWithOnConflict("messages", null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }

    void delivered(String topic, String uid) {
        ContentValues values = new ContentValues();
        values.put("sent", 1);
        getWritableDatabase().update("messages", values, "topic=? AND uid=? AND sent=0",
                new String[]{topic, uid});
    }

    void received(String topic, String uid, String device, String name, String body, long time,
                  long serverId, String attachment, boolean edited) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            insert(topic, uid, device, name, body, time * 1000, true, attachment, edited);
            delivered(topic, uid);
            advance(topic, serverId);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    void managed(String topic, String uid) {
        ContentValues values = new ContentValues();
        values.put("managed", 1);
        getWritableDatabase().update("messages", values, "topic=? AND uid=?", new String[]{topic, uid});
    }

    void hide(String topic, String uid) {
        ContentValues values = new ContentValues();
        values.put("hidden", 1);
        getWritableDatabase().update("messages", values, "topic=? AND uid=?", new String[]{topic, uid});
    }

    void applyChange(String topic, String uid, String device, String body, boolean remove, long serverId) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put("body", body);
            if (remove) {
                values.put("hidden", 1);
                values.put("attachment", "");
            } else {
                values.put("edited", 1);
            }
            db.update("messages", values, "topic=? AND uid=? AND device=?",
                    new String[]{topic, uid, device});
            advance(topic, serverId);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    void advance(String topic, long serverId) {
        getWritableDatabase().execSQL("INSERT OR IGNORE INTO sync_cursor (topic, last_id) VALUES (?, 0)",
                new Object[]{topic});
        getWritableDatabase().execSQL("UPDATE sync_cursor SET last_id=? WHERE topic=? AND last_id < ?",
                new Object[]{serverId, topic, serverId});
    }
}
