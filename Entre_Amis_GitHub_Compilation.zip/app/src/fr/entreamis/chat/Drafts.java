package fr.entreamis.chat;

import android.content.SharedPreferences;

final class Drafts {
    private final SharedPreferences preferences;

    Drafts(SharedPreferences preferences) {
        this.preferences = preferences;
    }

    String read(String topic) {
        return preferences.getString("draft." + topic, "");
    }

    void write(String topic, String text) {
        if (text.equals(read(topic))) return;
        String key = "draft." + topic;
        SharedPreferences.Editor edit = preferences.edit();
        if (text.isEmpty()) edit.remove(key);
        else edit.putString(key, text);
        edit.apply();
    }
}
