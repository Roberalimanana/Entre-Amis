package fr.entreamis.chat;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.telephony.PhoneNumberUtils;
import android.text.InputFilter;
import android.text.InputType;
import android.util.AtomicFile;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.concurrent.ExecutorService;
import org.json.JSONException;
import org.json.JSONObject;

final class ProfilePanel {
    private static final String FLOW = "profilePhotoFlow";
    private static final String VERIFIED = "profileNumberVerified";
    private static final int MAX_PHOTO = 524_288;
    private final MainActivity activity;
    private final Relay relay;
    private final SharedPreferences preferences;
    private final ExecutorService worker;
    private final Handler ui;
    private final String proof;
    private final AtomicFile photo;
    private final Runnable refresh = this::pollPhoto;
    private AlertDialog dialog;
    private ImageView avatar;
    private TextView status;
    private TextView verified;
    private Button google;
    private Button facebook;
    private Button sms;
    private boolean resumed;
    private boolean polling;

    ProfilePanel(MainActivity activity, Relay relay, SharedPreferences preferences,
                 ExecutorService worker, Handler ui, String proof) {
        this.activity = activity;
        this.relay = relay;
        this.preferences = preferences;
        this.worker = worker;
        this.ui = ui;
        this.proof = proof;
        this.photo = new AtomicFile(new File(activity.getFilesDir(), "profile-photo"));
    }

    void show() {
        if (dialog != null || !activity.requireUnlock()) return;
        ScrollView scroll = new ScrollView(activity);
        LinearLayout content = new LinearLayout(activity);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(14), dp(20), dp(10));
        scroll.addView(content);
        avatar = new ImageView(activity);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setContentDescription("Photo de profil");
        LinearLayout.LayoutParams imageSize = new LinearLayout.LayoutParams(dp(92), dp(92));
        imageSize.gravity = Gravity.CENTER_HORIZONTAL;
        content.addView(avatar, imageSize);
        verified = new TextView(activity);
        content.addView(verified);
        status = new TextView(activity);
        status.setText("Vérification des services…");
        content.addView(status);
        google = button(content, "Importer ma photo Google", () -> startPhoto("google"));
        facebook = button(content, "Importer ma photo Facebook", () -> startPhoto("facebook"));
        sms = button(content, "Vérifier mon numéro par SMS", this::askNumber);
        button(content, "Saisir le code SMS", this::askCode);
        button(content, "Retirer ma photo", this::removePhoto);
        google.setEnabled(false);
        facebook.setEnabled(false);
        sms.setEnabled(false);
        dialog = new AlertDialog.Builder(activity).setTitle("Mon profil").setView(scroll)
                .setNegativeButton("Fermer", null).create();
        dialog.setOnDismissListener(ignored -> dialog = null);
        redraw();
        dialog.show();
        request(body("status"), (reply) -> {
            if (dialog == null) return;
            google.setEnabled(reply.optBoolean("google"));
            facebook.setEnabled(reply.optBoolean("facebook"));
            sms.setEnabled(reply.optBoolean("sms"));
            preferences.edit().putBoolean(VERIFIED, reply.optBoolean("verified")).apply();
            redraw();
            status.setText(reply.optBoolean("google") || reply.optBoolean("facebook") || reply.optBoolean("sms")
                    ? "Choisis les informations à ajouter à ton profil."
                    : "Les services de profil attendent leur configuration sur Eclipse.");
        });
        pollPhoto();
    }

    void resume() {
        resumed = true;
        pollPhoto();
    }

    void pause() {
        resumed = false;
        ui.removeCallbacks(refresh);
    }

    private void startPhoto(String provider) {
        JSONObject payload = body("photo_start");
        put(payload, "provider", provider);
        request(payload, reply -> {
            String flow = reply.optString("flow");
            Uri url = Uri.parse(reply.optString("url"));
            String host = "google".equals(provider) ? "accounts.google.com" : "www.facebook.com";
            if (!flow.matches("[0-9a-f]{64}") || !"https".equals(url.getScheme()) || !host.equals(url.getHost())
                    || url.getUserInfo() != null || url.getPort() != -1) {
                message("Autorisation indisponible.");
                return;
            }
            preferences.edit().putString(FLOW, flow).apply();
            try {
                activity.startActivity(new Intent(Intent.ACTION_VIEW, url));
                message("Autorise la photo, puis reviens dans Entre Amis.");
            } catch (ActivityNotFoundException | SecurityException error) {
                preferences.edit().remove(FLOW).apply();
                message("Aucun navigateur n’est disponible.");
            }
        });
    }

    private void pollPhoto() {
        String flow = preferences.getString(FLOW, "");
        if (!resumed || polling || flow.isEmpty() || activity.isFinishing()) return;
        polling = true;
        JSONObject payload = body("photo_result");
        put(payload, "flow", flow);
        worker.execute(() -> {
            byte[] image = null;
            String state;
            try {
                JSONObject reply = fetch(payload);
                state = reply.optString("state");
                if ("ready".equals(state)) {
                    image = Base64.getDecoder().decode(reply.getString("photo"));
                    if (!validPhoto(image)) {
                        image = null;
                        state = "unavailable";
                    }
                }
            } catch (Relay.HttpError error) {
                state = error.code == 404 ? "unavailable" : "pending";
            } catch (IOException error) {
                state = "pending";
            } catch (JSONException | IllegalArgumentException error) {
                state = "unavailable";
            }
            String result = state;
            byte[] bytes = image;
            ui.post(() -> finishPhoto(flow, result, bytes));
        });
    }

    private static boolean validPhoto(byte[] image) {
        if (image.length == 0 || image.length > MAX_PHOTO) return false;
        BitmapFactory.Options size = new BitmapFactory.Options();
        size.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(image, 0, image.length, size);
        return size.outWidth > 0 && size.outWidth <= 2048 && size.outHeight > 0 && size.outHeight <= 2048;
    }

    private void finishPhoto(String flow, String state, byte[] bytes) {
        polling = false;
        if (!flow.equals(preferences.getString(FLOW, "")) || activity.isDestroyed()) return;
        if ("pending".equals(state) || !resumed || activity.isFinishing() || !activity.lock.isUnlocked()) {
            if (resumed && !activity.isFinishing()) ui.postDelayed(refresh, 5_000);
            return;
        }
        preferences.edit().remove(FLOW).apply();
        if (bytes == null) {
            message("Aucune photo disponible. Tu peux relancer l’import.");
            return;
        }
        FileOutputStream output = null;
        try {
            output = photo.startWrite();
            output.write(bytes);
            photo.finishWrite(output);
            redraw();
            message("Photo ajoutée à ton profil.");
        } catch (IOException error) {
            if (output != null) photo.failWrite(output);
            message("Impossible d’enregistrer la photo.");
        }
    }

    private void askNumber() {
        ask("Vérifier mon numéro", "Ex. +261 34 00 000 00", InputType.TYPE_CLASS_PHONE, 25, input -> {
            String number = PhoneNumberUtils.normalizeNumber(input);
            if (!number.matches("\\+[1-9][0-9]{7,14}")) {
                message("Saisis le numéro avec son indicatif, par exemple +261.");
                return;
            }
            JSONObject payload = body("sms_start");
            put(payload, "number", number);
            request(payload, reply -> askCode());
        });
    }

    private void askCode() {
        ask("Code de vérification", "Code reçu par SMS", InputType.TYPE_CLASS_NUMBER, 10, code -> {
            if (!code.matches("[0-9]{4,10}")) {
                message("Saisis le code reçu par SMS.");
                return;
            }
            JSONObject payload = body("sms_confirm");
            put(payload, "code", code);
            request(payload, reply -> {
                if (!reply.optBoolean("verified")) return;
                preferences.edit().putBoolean(VERIFIED, true).apply();
                redraw();
                message("Numéro vérifié.");
            });
        });
    }

    private void ask(String title, String hint, int type, int length, java.util.function.Consumer<String> confirm) {
        if (!activity.requireUnlock()) return;
        EditText field = new EditText(activity);
        field.setSingleLine(true);
        field.setHint(hint);
        field.setInputType(type);
        field.setFilters(new InputFilter[]{new InputFilter.LengthFilter(length)});
        new AlertDialog.Builder(activity).setTitle(title).setView(field).setNegativeButton("Annuler", null)
                .setPositiveButton("Continuer", (window, which) -> confirm.accept(field.getText().toString().trim())).show();
    }

    private void removePhoto() {
        preferences.edit().remove(FLOW).apply();
        photo.delete();
        redraw();
        message("Photo retirée.");
    }

    private void redraw() {
        if (dialog == null) return;
        Bitmap bitmap = BitmapFactory.decodeFile(photo.getBaseFile().getAbsolutePath());
        avatar.setImageBitmap(bitmap);
        avatar.setVisibility(bitmap == null ? android.view.View.GONE : android.view.View.VISIBLE);
        verified.setText(preferences.getBoolean(VERIFIED, false) ? "Numéro vérifié" : "Numéro à vérifier");
    }

    private void request(JSONObject payload, java.util.function.Consumer<JSONObject> done) {
        worker.execute(() -> {
            try {
                JSONObject reply = fetch(payload);
                ui.post(() -> {
                    if (!activity.isFinishing() && activity.lock.isUnlocked()) done.accept(reply);
                });
            } catch (Relay.HttpError error) {
                String text = error.code == 404 ? "Mets à jour le relais Eclipse pour utiliser le profil."
                        : error.code == 422 ? "Code incorrect ou expiré."
                        : error.code == 429 ? "Trop de demandes. Réessaie plus tard."
                        : error.code == 503 ? "Le service doit être configuré sur Eclipse."
                        : "Le service de profil n’a pas accepté la demande.";
                ui.post(() -> message(text));
            } catch (IOException | JSONException error) {
                ui.post(() -> message("Le service de profil est indisponible."));
            }
        });
    }

    private JSONObject fetch(JSONObject payload) throws IOException, JSONException {
        return new JSONObject(relay.profile(payload.toString(), proof));
    }

    private static JSONObject body(String action) {
        JSONObject payload = new JSONObject();
        put(payload, "action", action);
        return payload;
    }

    private static void put(JSONObject payload, String field, String value) {
        try { payload.put(field, value); }
        catch (JSONException impossible) { throw new IllegalStateException(impossible); }
    }

    private Button button(LinearLayout parent, String text, Runnable onClick) {
        Button button = new Button(activity);
        button.setText(text);
        button.setOnClickListener(view -> onClick.run());
        parent.addView(button);
        return button;
    }

    private int dp(int value) { return Math.round(value * activity.getResources().getDisplayMetrics().density); }

    private void message(String value) {
        if (activity.isFinishing() || activity.isDestroyed()) return;
        if (dialog != null) status.setText(value);
        else Toast.makeText(activity, value, Toast.LENGTH_SHORT).show();
    }
}
