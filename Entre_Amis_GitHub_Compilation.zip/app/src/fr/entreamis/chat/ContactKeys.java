package fr.entreamis.chat;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.KeyAgreement;

final class ContactKeys {
    private static final Base64.Encoder ENCODER = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder DECODER = Base64.getUrlDecoder();

    static KeyPair generate() throws GeneralSecurityException {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("EC");
        generator.initialize(new ECGenParameterSpec("secp256r1"));
        return generator.generateKeyPair();
    }

    static String encode(byte[] bytes) { return ENCODER.encodeToString(bytes); }

    static KeyPair restore(String publicKey, String privateKey) throws GeneralSecurityException {
        KeyFactory factory = KeyFactory.getInstance("EC");
        return new KeyPair(decodePublic(publicKey),
                factory.generatePrivate(new PKCS8EncodedKeySpec(DECODER.decode(privateKey))));
    }

    static Room room(KeyPair own, String device, String peerKey, String peer) throws GeneralSecurityException {
        if (device.equals(peer)) throw new GeneralSecurityException("Contact identique");
        KeyAgreement agreement = KeyAgreement.getInstance("ECDH");
        agreement.init(own.getPrivate());
        agreement.doPhase(decodePublic(peerKey), true);
        byte[] shared = agreement.generateSecret();
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            String pair = device.compareTo(peer) < 0 ? device + "/" + peer : peer + "/" + device;
            digest.update(("entre-amis-contact-v1/" + pair).getBytes(StandardCharsets.US_ASCII));
            return Room.join("AMISP1." + encode(digest.digest(shared)));
        } finally {
            Arrays.fill(shared, (byte) 0);
        }
    }

    private static PublicKey decodePublic(String encoded) throws GeneralSecurityException {
        if (!encoded.matches("[A-Za-z0-9_-]{122}")) throw new GeneralSecurityException("Clé de contact invalide");
        PublicKey key = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(DECODER.decode(encoded)));
        if (!(key instanceof ECPublicKey) || ((ECPublicKey) key).getParams().getCurve().getField().getFieldSize() != 256) {
            throw new GeneralSecurityException("Clé de contact invalide");
        }
        return key;
    }
}
