package fr.entreamis.chat;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

final class Room {
    private static final String INVITE_PREFIX = "AMIS1.";
    private static final String PRIVATE_PREFIX = "AMISP1.";
    private static final String MESSAGE_PREFIX = "ea1.";
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final Base64.Encoder ENCODER = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder DECODER = Base64.getUrlDecoder();

    final String invite;
    final boolean privateRoom;
    final String topic;
    final String accessKey;
    private final SecretKeySpec key;
    private final SecretKeySpec fileKey;
    private final SecretKeySpec callKey;

    private Room(byte[] secret, boolean privateRoom) throws GeneralSecurityException {
        this.privateRoom = privateRoom;
        invite = (privateRoom ? PRIVATE_PREFIX : INVITE_PREFIX) + ENCODER.encodeToString(secret);
        if (privateRoom) secret = derive(secret, "private-conversation-v1");
        accessKey = hex(derive(secret, "room-access-v1"));
        topic = hex(MessageDigest.getInstance("SHA-256")
                .digest(accessKey.getBytes(StandardCharsets.US_ASCII)));
        key = new SecretKeySpec(derive(secret, "room-aes-v1"), "AES");
        fileKey = new SecretKeySpec(derive(secret, "room-file-v1"), "AES");
        callKey = new SecretKeySpec(derive(secret, "room-call-v1"), "AES");
    }

    static Room create() throws GeneralSecurityException {
        return create(false);
    }

    static Room create(boolean privateRoom) throws GeneralSecurityException {
        return new Room(randomSecret(), privateRoom);
    }

    static String newOwnerProof() {
        return hex(randomSecret());
    }

    static String ownerHash(String proof) throws GeneralSecurityException {
        return hex(MessageDigest.getInstance("SHA-256").digest(proof.getBytes(StandardCharsets.US_ASCII)));
    }

    private static byte[] randomSecret() {
        byte[] secret = new byte[32];
        RANDOM.nextBytes(secret);
        return secret;
    }

    static Room join(String code) throws GeneralSecurityException {
        String invite = code.trim();
        if (!invite.matches("AMISP?1\\.[A-Za-z0-9_-]{43}")) {
            throw new IllegalArgumentException("Code incomplet");
        }
        boolean privateRoom = invite.startsWith(PRIVATE_PREFIX);
        int prefixLength = privateRoom ? PRIVATE_PREFIX.length() : INVITE_PREFIX.length();
        Room room = new Room(DECODER.decode(invite.substring(prefixLength)), privateRoom);
        if (!room.invite.equals(invite)) {
            throw new IllegalArgumentException("Code invalide");
        }
        return room;
    }

    private static byte[] derive(byte[] secret, String domain) throws GeneralSecurityException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        digest.update(domain.getBytes(StandardCharsets.US_ASCII));
        return digest.digest(secret);
    }

    private static String hex(byte[] bytes) {
        char[] digits = "0123456789abcdef".toCharArray();
        char[] value = new char[bytes.length * 2];
        for (int index = 0; index < bytes.length; index++) {
            value[index * 2] = digits[(bytes[index] & 255) >>> 4];
            value[index * 2 + 1] = digits[bytes[index] & 15];
        }
        return new String(value);
    }

    String encrypt(String message) throws GeneralSecurityException {
        return MESSAGE_PREFIX + ENCODER.encodeToString(seal(
                message.getBytes(StandardCharsets.UTF_8), key, topic));
    }

    String decrypt(String message) throws GeneralSecurityException {
        if (!message.startsWith(MESSAGE_PREFIX) || message.length() > 4096) {
            throw new IllegalArgumentException("Format de message inconnu");
        }
        return new String(open(DECODER.decode(message.substring(MESSAGE_PREFIX.length())), key, topic),
                StandardCharsets.UTF_8);
    }

    byte[] encryptFile(String uid, byte[] file) throws GeneralSecurityException {
        return seal(file, fileKey, topic + "/" + uid);
    }

    byte[] decryptFile(String uid, byte[] file) throws GeneralSecurityException {
        return open(file, fileKey, topic + "/" + uid);
    }

    String encryptCall(String context, String signal) throws GeneralSecurityException {
        return "ec1." + ENCODER.encodeToString(seal(signal.getBytes(StandardCharsets.UTF_8),
                callKey, topic + "/" + context));
    }

    String decryptCall(String context, String signal) throws GeneralSecurityException {
        if (!signal.startsWith("ec1.") || signal.length() > 49156) {
            throw new IllegalArgumentException("Signal inconnu");
        }
        return new String(open(DECODER.decode(signal.substring(4)), callKey, topic + "/" + context),
                StandardCharsets.UTF_8);
    }

    private byte[] seal(byte[] plain, SecretKeySpec secret, String associatedData)
            throws GeneralSecurityException {
        byte[] nonce = new byte[12];
        RANDOM.nextBytes(nonce);
        byte[] ciphertext = cipher(Cipher.ENCRYPT_MODE, nonce, secret, associatedData).doFinal(plain);
        return ByteBuffer.allocate(nonce.length + ciphertext.length).put(nonce).put(ciphertext).array();
    }

    private byte[] open(byte[] encrypted, SecretKeySpec secret, String associatedData)
            throws GeneralSecurityException {
        ByteBuffer packet = ByteBuffer.wrap(encrypted);
        if (packet.remaining() < 28) {
            throw new IllegalArgumentException("Message incomplet");
        }
        byte[] nonce = new byte[12];
        packet.get(nonce);
        byte[] ciphertext = new byte[packet.remaining()];
        packet.get(ciphertext);
        return cipher(Cipher.DECRYPT_MODE, nonce, secret, associatedData).doFinal(ciphertext);
    }

    private Cipher cipher(int mode, byte[] nonce, SecretKeySpec secret, String associatedData)
            throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(mode, secret, new GCMParameterSpec(128, nonce));
        cipher.updateAAD(associatedData.getBytes(StandardCharsets.US_ASCII));
        return cipher;
    }
}
