package fr.entreamis.chat;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

final class MessageSearch {
    private static final Pattern MARKS = Pattern.compile("\\p{M}+");
    private static final Pattern SPACE = Pattern.compile("[\\p{Z}\\s]+");
    private final String[] terms;
    private final boolean attachmentsOnly;

    MessageSearch(String input, boolean attachmentsOnly) {
        String query = SPACE.matcher(normalize(input)).replaceAll(" ").trim();
        terms = query.isEmpty() ? new String[0] : query.split(" ");
        this.attachmentsOnly = attachmentsOnly;
    }

    boolean isEmpty() {
        return terms.length == 0 && !attachmentsOnly;
    }

    boolean matches(String author, String body, String attachment) {
        if (isEmpty() || (attachmentsOnly && attachment.isEmpty())) return false;
        if (terms.length == 0) return true;
        String content = normalize(author + "\n" + body + "\n" + attachment);
        for (String term : terms) {
            if (!content.contains(term)) return false;
        }
        return true;
    }

    static String preview(String body, String attachment) {
        String text = SPACE.matcher(body).replaceAll(" ").trim();
        if (!attachment.isEmpty() && !text.contains(attachment)) {
            text = "📎 " + attachment + (text.isEmpty() ? "" : " · " + text);
        }
        if (text.codePointCount(0, text.length()) <= 110) return text;
        return text.substring(0, text.offsetByCodePoints(0, 109)) + "…";
    }

    private static String normalize(String value) {
        return MARKS.matcher(Normalizer.normalize(value.toLowerCase(Locale.ROOT), Normalizer.Form.NFD))
                .replaceAll("").replace("œ", "oe").replace("æ", "ae");
    }
}
