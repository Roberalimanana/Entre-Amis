package fr.entreamis.chat;

import android.content.SharedPreferences;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

final class AppPassword {
    static final int MIN_LENGTH = 8;
    private static final int ITERATIONS = 600_000;
    private static final int MAX_ATTEMPTS = 5;
    private static final long COOLDOWN_MS = 30_000;

    private final SharedPreferences preferences;

    AppPassword(SharedPreferences preferences) { this.preferences = preferences; }

    boolean configured() { return preferences.contains("password"); }

    // Called serially by the password screen's background worker.
    String submit(char[] current, char[] replacement, boolean creating, long now)
            throws GeneralSecurityException {
        if (creating == configured()) return "L’état du mot de passe a changé. Rouvre Entre Amis.";
        if (creating && replacement == null) return "Choisis un mot de passe.";
        if (replacement != null && replacement.length < MIN_LENGTH) return "Choisis au moins 8 caractères.";
        if (!creating) {
            if (current == null || current.length == 0) return "Saisis le mot de passe.";
            long remaining = preferences.getLong("blockedUntil", 0) - now;
            if (remaining > 0) return "Patiente " + ((remaining + 999) / 1000) + " s avant de réessayer.";

            byte[] salt = Base64.getDecoder().decode(preferences.getString("salt", ""));
            byte[] saved = Base64.getDecoder().decode(preferences.getString("password", ""));
            byte[] entered = derive(current, salt);
            boolean matches = MessageDigest.isEqual(entered, saved);
            Arrays.fill(entered, (byte) 0);
            if (!matches) {
                int failures = preferences.getInt("failures", 0) + 1;
                SharedPreferences.Editor edit = preferences.edit();
                boolean blocked = failures >= MAX_ATTEMPTS;
                edit.putInt("failures", blocked ? 0 : failures);
                if (blocked) edit.putLong("blockedUntil", now + COOLDOWN_MS);
                persist(edit);
                return blocked ? "Trop d’essais. Patiente 30 s." : "Mot de passe incorrect.";
            }
        }
        SharedPreferences.Editor edit = preferences.edit().remove("failures").remove("blockedUntil");
        if (replacement != null) {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            byte[] digest = derive(replacement, salt);
            edit.putString("salt", Base64.getEncoder().encodeToString(salt))
                    .putString("password", Base64.getEncoder().encodeToString(digest));
            Arrays.fill(digest, (byte) 0);
        }
        persist(edit);
        return null;
    }

    private static void persist(SharedPreferences.Editor edit) throws GeneralSecurityException {
        if (!edit.commit()) throw new GeneralSecurityException("Enregistrement impossible");
    }

    private static byte[] derive(char[] password, byte[] salt) throws GeneralSecurityException {
        PBEKeySpec spec = new PBEKeySpec(password, salt, ITERATIONS, 256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } finally {
            spec.clearPassword();
        }
    }
}
