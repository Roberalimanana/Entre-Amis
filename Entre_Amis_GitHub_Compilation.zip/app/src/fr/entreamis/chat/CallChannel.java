package fr.entreamis.chat;

import android.os.Handler;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class CallChannel extends Thread {
    static final String UUID_FORMAT = "[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}";

    interface Listener {
        void signals(CallChannel channel, long cursor, List<Signal> signals);
        void error(CallChannel channel, IOException error);
    }

    static final class Signal {
        final String call;
        final String sender;
        final String kind;
        final String data;
        final long age;

        Signal(String call, String sender, String kind, String data, long age) {
            this.call = call;
            this.sender = sender;
            this.kind = kind;
            this.data = data;
            this.age = age;
        }
    }

    private final Relay relay;
    private final Room room;
    private final String device;
    private final String call;
    private final Handler ui;
    private final Listener listener;
    private long cursor;

    CallChannel(Relay relay, Room room, String device, String call, long cursor, Handler ui, Listener listener) {
        super("EntreAmis-appels");
        this.relay = relay;
        this.room = room;
        this.device = device;
        this.call = call;
        this.cursor = cursor;
        this.ui = ui;
        this.listener = listener;
    }

    static void send(Relay relay, Room room, String call, String sender, String recipient,
                     String kind, String data)
            throws IOException, JSONException, GeneralSecurityException {
        JSONObject signal = new JSONObject();
        signal.put("kind", kind);
        signal.put("data", data);
        String encrypted = room.encryptCall(context(call, sender, recipient), signal.toString());
        relay.publishCall(room, call, sender, recipient, encrypted);
    }

    private static String context(String call, String sender, String recipient) {
        return call + "/" + sender + "/" + recipient;
    }

    @Override public void run() {
        long delay = 0;
        long backoff = 3000;
        while (!isInterrupted()) {
            try {
                Thread.sleep(delay);
                JSONObject page = new JSONObject(relay.pollCalls(room, device, call, cursor));
                if (isInterrupted()) return;
                long now = page.getLong("now");
                List<Signal> signals = new ArrayList<>();
                JSONArray entries = page.getJSONArray("signals");
                for (int index = 0; index < entries.length(); index++) {
                    JSONObject envelope = entries.getJSONObject(index);
                    cursor = Math.max(cursor, envelope.getLong("id"));
                    Signal signal = decode(envelope, now);
                    if (signal != null) signals.add(signal);
                }
                if (entries.length() > 0) {
                    long read = cursor;
                    ui.post(() -> listener.signals(this, read, signals));
                }
                delay = page.optBoolean("more") ? 120 : call.isEmpty() ? 2700 : 1050;
                backoff = 3000;
            } catch (InterruptedException stopped) {
                return;
            } catch (IOException | JSONException error) {
                IOException failure = error instanceof IOException ? (IOException) error : new IOException(error);
                ui.post(() -> listener.error(this, failure));
                long retry = failure instanceof Relay.HttpError ? ((Relay.HttpError) failure).retryMs : 0;
                delay = Math.max(backoff, retry);
                backoff = Math.min(30000, backoff * 2);
            }
        }
    }

    private Signal decode(JSONObject envelope, long now) {
        try {
            String callId = envelope.getString("call_id");
            String sender = envelope.getString("sender");
            String to = envelope.getString("recipient");
            if (!callId.matches(UUID_FORMAT) || !sender.matches(UUID_FORMAT)
                    || sender.equals(device) || (!to.isEmpty() && !to.equals(device))
                    || (!call.isEmpty() && !call.equals(callId))) {
                return null;
            }
            String decrypted = room.decryptCall(context(callId, sender, to), envelope.getString("signal"));
            JSONObject signal = new JSONObject(decrypted);
            return new Signal(callId, sender, signal.getString("kind"), signal.getString("data"),
                    Math.max(0, now - envelope.getLong("created")));
        } catch (JSONException | GeneralSecurityException | IllegalArgumentException invalid) {
            return null;
        }
    }
}
