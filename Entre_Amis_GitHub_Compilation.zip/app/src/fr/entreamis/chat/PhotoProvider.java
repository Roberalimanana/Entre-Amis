package fr.entreamis.chat;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.UUID;

public final class PhotoProvider extends ContentProvider {
    @Override public boolean onCreate() { return true; }

    static File create(Context context) throws IOException {
        File directory = new File(context.getCacheDir(), "camera");
        if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Appareil photo indisponible");
        File photo = new File(directory, "capture-" + UUID.randomUUID() + ".jpg");
        if (!photo.createNewFile()) throw new IOException("Photo temporaire indisponible");
        return photo;
    }

    static File file(Context context, String name) {
        if (name == null || !name.matches("capture-[a-f0-9-]{36}\\.jpg")) return null;
        return new File(new File(context.getCacheDir(), "camera"), name);
    }

    static Uri uri(Context context, File file) {
        return new Uri.Builder().scheme("content").authority(context.getPackageName() + ".photos")
                .appendPath(file.getName()).build();
    }

    @Override public String getType(Uri uri) { return "image/jpeg"; }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File file = resolve(uri);
        if (file == null) throw new FileNotFoundException();
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.parseMode(mode));
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String order) {
        String[] columns = projection == null
                ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
        MatrixCursor cursor = new MatrixCursor(columns, 1);
        File file = resolve(uri);
        if (file != null) {
            MatrixCursor.RowBuilder row = cursor.newRow();
            for (String column : columns) {
                if (OpenableColumns.DISPLAY_NAME.equals(column)) row.add("Photo.jpg");
                else if (OpenableColumns.SIZE.equals(column)) row.add(file.length());
                else row.add(null);
            }
        }
        return cursor;
    }

    private File resolve(Uri uri) {
        if (uri.getPathSegments().size() != 1) return null;
        File file = file(getContext(), uri.getLastPathSegment());
        return file != null && file.isFile() ? file : null;
    }

    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] args) {
        throw new UnsupportedOperationException();
    }
    @Override public int delete(Uri uri, String selection, String[] args) { throw new UnsupportedOperationException(); }
}
