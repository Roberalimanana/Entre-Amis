package fr.entreamis.chat;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.WindowManager;

abstract class ProtectedActivity extends Activity {
    AppLock lock;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        lock = AppLock.of(this);
        lock.register(this);
    }

    final boolean requireUnlock() {
        if (lock.isUnlocked() && !isFinishing()) return true;
        closeForLock();
        return false;
    }

    @Override protected void onStart() {
        super.onStart();
        requireUnlock();
    }

    @Override protected void onResume() {
        super.onResume();
        requireUnlock();
    }

    @Override public void onUserInteraction() {
        super.onUserInteraction();
        lock.touch();
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        return !requireUnlock() || super.dispatchTouchEvent(event);
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        return !requireUnlock() || super.dispatchKeyEvent(event);
    }

    void closeForLock() { finish(); }

    @Override protected void onDestroy() {
        lock.unregister(this);
        super.onDestroy();
    }
}
