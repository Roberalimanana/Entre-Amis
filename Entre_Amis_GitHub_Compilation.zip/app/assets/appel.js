'use strict';

const bridge = window.EntreAmisCall;
const grid = document.querySelector('#grid');
const peers = new Map();
const tiles = new Map();
let localStream;
let localId;
let servers;
let videoAllowed;
let active = true;

function report(state, peer = '') {
    if (active) bridge.status(state, peer);
}

function emit(kind, peer, data) {
    if (active) bridge.signal(kind, peer, JSON.stringify(data));
}

function tile(id, name, mine = false) {
    const card = document.createElement('section');
    card.className = mine ? 'tile mine' : 'tile';
    const video = document.createElement('video');
    video.autoplay = true;
    video.playsInline = true;
    video.muted = mine;
    const avatar = document.createElement('span');
    avatar.className = 'avatar';
    avatar.textContent = Array.from(name)[0] || '•';
    const label = document.createElement('span');
    label.className = 'name';
    label.textContent = name;
    const hand = document.createElement('span');
    hand.className = 'hand';
    hand.textContent = '✋';
    const mic = document.createElement('span');
    mic.className = 'mic';
    mic.textContent = 'Micro coupé';
    card.append(video, avatar, label, hand, mic);
    grid.append(card);
    const result = {card, video, name};
    tiles.set(id, result);
    grid.classList.toggle("single", tiles.size === 1);
    return result;
}

async function startCall(id, name, mode, iceServers) {
    localId = id;
    servers = iceServers;
    videoAllowed = mode !== 'audio';
    try {
        localStream = await navigator.mediaDevices.getUserMedia({
            audio: {echoCancellation: true, noiseSuppression: true},
            video: mode === 'video' ? videoConstraints() : false
        });
        if (!active) {
            localStream.getTracks().forEach(track => track.stop());
            return;
        }
        const own = tile(id, name, true);
        own.video.srcObject = localStream;
        showCamera(id, localStream.getVideoTracks().length > 0);
        report('media-ready');
    } catch (_) {
        report('media-error');
    }
}

function videoConstraints() {
    return {facingMode: 'user', width: {ideal: 480}, height: {ideal: 360}, frameRate: {ideal: 18, max: 24}};
}

function ensurePeer(id, name) {
    if (!active || !localStream || peers.has(id)) return;
    const pc = new RTCPeerConnection({iceServers: servers});
    const remote = new MediaStream();
    const remoteAudio = new MediaStream();
    const peer = {pc, remote, remoteAudio, queued: [], camera: null};
    peers.set(id, peer);
    const ui = tile(id, name);
    ui.audio = document.createElement('audio');
    ui.audio.autoplay = true;
    ui.card.append(ui.audio);
    ui.video.srcObject = remote;
    pc.addTrack(localStream.getAudioTracks()[0], localStream);
    pc.onicecandidate = event => {
        if (event.candidate) emit('ice', id, event.candidate.toJSON());
    };
    pc.ontrack = event => {
        if (event.track.kind === 'audio') {
            remoteAudio.addTrack(event.track);
            ui.audio.srcObject = remoteAudio;
            ui.audio.play().catch(() => {
                if (peers.get(id) === peer) report('audio-playback-error', id);
            });
            return;
        }
        remote.addTrack(event.track);
        if (event.track.kind === 'video') {
            event.track.onunmute = () => showCamera(id, true);
            event.track.onmute = () => showCamera(id, false);
        }
        ui.video.play().catch(() => {});
    };
    if ('connectionState' in pc) {
        pc.onconnectionstatechange = () => report('peer-' + pc.connectionState, id);
    } else {
        pc.oniceconnectionstatechange = () => report('peer-' +
            (pc.iceConnectionState === 'completed' ? 'connected' : pc.iceConnectionState), id);
    }
}

async function makeOffer(id) {
    const peer = peers.get(id);
    if (!peer) return;
    try {
        if (videoAllowed && !peer.camera) {
            const track = localStream.getVideoTracks()[0];
            const options = track
                ? {direction: 'sendrecv', streams: [localStream]}
                : {direction: 'sendrecv'};
            peer.camera = peer.pc.addTransceiver(track || 'video', options).sender;
        }
        await peer.pc.setLocalDescription(await peer.pc.createOffer());
        emit('offer', id, peer.pc.localDescription);
    } catch (_) {
        report('peer-error', id);
    }
}

async function applySignal(id, kind, encoded) {
    const peer = peers.get(id);
    if (!peer) return;
    try {
        const data = JSON.parse(encoded);
        if (kind === 'ice') {
            if (peer.pc.remoteDescription) await peer.pc.addIceCandidate(data);
            else if (peer.queued.length < 100) peer.queued.push(data);
            return;
        }
        if (data.type !== kind || (kind !== 'offer' && kind !== 'answer')) return;
        await peer.pc.setRemoteDescription(data);
        const queued = peer.queued;
        peer.queued = [];
        for (const candidate of queued) {
            try { await peer.pc.addIceCandidate(candidate); } catch (_) { /* Other candidates may work. */ }
        }
        if (kind === 'offer') {
            // The answerer must use the video transceiver assigned by the remote offer.
            if (videoAllowed) {
                const video = peer.pc.getTransceivers().find(value =>
                    value.mid !== null && value.receiver.track.kind === 'video');
                if (video) {
                    video.direction = 'sendrecv';
                    peer.camera = video.sender;
                    await peer.camera.replaceTrack(localStream.getVideoTracks()[0] || null);
                }
            }
            await peer.pc.setLocalDescription(await peer.pc.createAnswer());
            emit('answer', id, peer.pc.localDescription);
        }
    } catch (_) {
        if (kind !== 'ice') report('peer-error', id);
    }
}

function setMuted(muted) {
    if (localStream) {
        localStream.getAudioTracks().forEach(track => { track.enabled = !muted; });
        showMic(localId, muted);
    }
}

async function setCamera(enabled) {
    if (!active || !localStream || !videoAllowed) return;
    try {
        if (enabled && !localStream.getVideoTracks().length) {
            const capture = await navigator.mediaDevices.getUserMedia({video: videoConstraints()});
            if (!active) {
                capture.getTracks().forEach(track => track.stop());
                return;
            }
            localStream.addTrack(capture.getVideoTracks()[0]);
        }
        if (!enabled) {
            localStream.getVideoTracks().forEach(track => { localStream.removeTrack(track); track.stop(); });
        }
        const track = localStream.getVideoTracks()[0] || null;
        for (const [id, peer] of peers) {
            if (!peer.camera) continue;
            try {
                await peer.camera.replaceTrack(track);
            } catch (error) {
                // A participant can leave while replaceTrack is still pending.
                if (peers.get(id) === peer && peer.pc.signalingState !== 'closed') throw error;
            }
        }
        showCamera(localId, enabled);
        report(enabled ? 'camera-on' : 'camera-off');
    } catch (_) {
        localStream.getVideoTracks().forEach(track => { localStream.removeTrack(track); track.stop(); });
        showCamera(localId, false);
        report('camera-error');
    }
}

function showCamera(id, enabled) {
    const value = tiles.get(id);
    if (value) value.card.classList.toggle('video-on', enabled);
}

function showHand(id, raised) {
    const value = tiles.get(id);
    if (value) value.card.classList.toggle('raised', raised);
}

function showMic(id, muted) {
    const value = tiles.get(id);
    if (value) value.card.classList.toggle('muted', muted);
}

function dropPeer(id) {
    const peer = peers.get(id);
    if (peer) {
        peers.delete(id);
        peer.pc.close();
        peer.remote.getTracks().forEach(track => track.stop());
        peer.remoteAudio.getTracks().forEach(track => track.stop());
    }
    const value = tiles.get(id);
    if (value) {
        value.video.srcObject = null;
        if (value.audio) value.audio.srcObject = null;
        value.card.remove();
        tiles.delete(id);
        grid.classList.toggle("single", tiles.size === 1);
    }
}

function captureMeeting() {
    if (!active || !tiles.size) return;
    const image = document.createElement('canvas');
    image.width = 960;
    image.height = 560;
    const ctx = image.getContext('2d');
    ctx.fillStyle = '#17132a';
    ctx.fillRect(0, 0, image.width, image.height);
    const cols = tiles.size === 1 ? 1 : 2;
    const width = image.width / cols;
    const height = 520 / Math.ceil(tiles.size / cols);
    ctx.font = '20px sans-serif';
    ctx.fillStyle = '#eee9ff';
    ctx.fillText('Entre Amis · Réunion', 14, 26);
    let index = 0;
    for (const value of tiles.values()) {
        const x = (index % cols) * width;
        const y = 36 + Math.floor(index / cols) * height;
        ctx.fillStyle = '#292346';
        ctx.fillRect(x + 3, y + 3, width - 6, height - 6);
        const video = value.video;
        if (value.card.classList.contains('video-on') && video.readyState >= 2 && video.videoWidth) {
            const ratio = Math.min((width - 6) / video.videoWidth, (height - 6) / video.videoHeight);
            const w = video.videoWidth * ratio;
            const h = video.videoHeight * ratio;
            ctx.drawImage(video, x + (width - w) / 2, y + (height - h) / 2, w, h);
        }
        ctx.fillStyle = '#17132a';
        ctx.fillRect(x + 7, y + height - 32, width - 14, 25);
        ctx.fillStyle = '#eee9ff';
        const hand = value.card.classList.contains('raised') ? ' · main levée' : '';
        const mic = value.card.classList.contains('muted') ? ' · micro coupé' : '';
        ctx.fillText(value.name + hand + mic, x + 13, y + height - 13, width - 26);
        index++;
    }
    bridge.capture(image.toDataURL('image/png').split(',')[1]);
}

function stopCall() {
    active = false;
    for (const id of peers.keys()) dropPeer(id);
    if (localStream) localStream.getTracks().forEach(track => track.stop());
}

report('page-ready');
