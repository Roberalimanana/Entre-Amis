# Entre Amis 1.3.7

- **Mon profil** permet de vérifier un numéro par SMS et d’importer une photo de profil après autorisation Google ou Facebook. La photo est appliquée au retour dans Entre Amis et peut être retirée. Elle s’affiche sur cet appareil. La vérification du numéro est proposée à la création du profil et depuis **Mon profil**.
- Le relais conserve le statut de vérification. Le prestataire SMS reçoit le numéro saisi et le relais conserve temporairement l’identifiant de la demande.

## Configuration privée du relais 1.3.2

- Google nécessite un client OAuth de type application Web avec `ENTRE_AMIS_GOOGLE_ID` et `ENTRE_AMIS_GOOGLE_SECRET`.
- Facebook nécessite une application Meta avec Facebook Login, `ENTRE_AMIS_META_ID`, `ENTRE_AMIS_META_SECRET` et `ENTRE_AMIS_META_VERSION` réglée sur une version prise en charge par ce compte.
- Les deux fournisseurs utilisent le retour HTTPS `https://eklipse.tech/wp-json/entre-amis/v1/profil/retour` sur cette installation. L’autoriser dans la configuration de chaque fournisseur.
- Les SMS utilisent un service Twilio Verify avec `ENTRE_AMIS_TWILIO_ACCOUNT`, `ENTRE_AMIS_TWILIO_TOKEN` et `ENTRE_AMIS_TWILIO_SERVICE`. Activer les destinations réellement utilisées dans ce service.
- Définir les valeurs privées côté serveur dans `wp-config.php`. **Mon profil** et la route `/wp-json/entre-amis/v1/etat` indiquent les services configurés. Vérifier séparément un véritable SMS et une importation de chaque fournisseur avant diffusion.
- `php build/test/profile.php` vérifie le relais avec des fournisseurs simulés et des numéros fictifs.

- **Inviter un contact du téléphone** ouvre le sélecteur Android et prépare un SMS avec le code d’une nouvelle discussion privée. Dans un salon que tu peux partager, **Inviter → Par SMS** utilise le code du salon ouvert. Tu confirmes l’envoi dans ton application SMS. Entre Amis lit uniquement le numéro choisi et ne l’enregistre pas.

- L’en-tête de la conversation affiche un statut uniquement en cas de problème de connexion. Le diagnostic détaillé reste disponible dans **Tester la connexion**.

- Les icônes téléphone et caméra lancent les appels audio et vidéo. L’icône appareil photo près du champ de message ouvre la caméra. Après la prise, confirme l’envoi dans la conversation. La photo est réduite à la limite de 2 Mo du relais.
- Enregistre ton pseudo pour apparaître dans **Tous les utilisateurs**. Ton pseudo reste visible dans l’annuaire quand tu es hors ligne. Ton statut passe en ligne lorsque tu ouvres l’application déverrouillée et devient hors ligne quand la fenêtre principale se ferme ou après 45 secondes sans connexion.
- Recherche un pseudo exact ou parcours **Tous les utilisateurs** dans **Contacts connectés**. La première demande expire après sept jours. Après acceptation dans **Demandes reçues**, les deux personnes peuvent rouvrir directement le même salon. Les six caractères affichés distinguent les homonymes. Les groupes et invitations existantes restent accessibles par code.
- Tu peux annuler une demande envoyée, refuser une demande reçue, bloquer ou débloquer un utilisateur. Pour un contact accepté, fais un appui long sur sa ligne ou ouvre **Gérer ce contact** dans sa conversation. Le blocage suspend les demandes par pseudo et la discussion privée associée sur ton appareil. Retirer un contact impose une nouvelle acceptation. L’historique reste enregistré.
- L’annuaire exige le relais WordPress Entre Amis 1.3.1 et l’application à partir de la version 1.3.4. Les anciens APK continuent d’utiliser les mêmes salons, pièces jointes et appels avec le protocole de messagerie 3.

L’APK utilise l’identifiant Android d’origine `fr.entreamis.chat` et la signature de l’édition Entre Amis. Installe-le comme mise à jour d’Entre Amis pour retrouver l’historique local, les brouillons et les réglages. Les données d’Entre Amis Sécurisé restent accessibles dans cette édition, qui dispose d’un identifiant distinct.

- Au premier démarrage, crée un mot de passe local d’au moins huit caractères. Le mot de passe reste sur l’appareil sous forme d’empreinte salée. Après cinq essais incorrects, l’application impose une pause de 30 secondes.
- Conserve ce mot de passe. Effacer les données Android d’Entre Amis réinitialise le mot de passe ainsi que les conversations et brouillons enregistrés sur le téléphone.
- L’application ferme les écrans de discussion après deux minutes sans interaction ou lorsque l’écran du téléphone s’éteint. Un appel en cours reste ouvert tant qu’il est au premier plan et que l’écran est allumé. À la réouverture, saisis ton mot de passe. Pour le modifier, utilise **Changer le mot de passe** à l’accueil ou dans les options du salon.
- Les alertes génériques continuent à arriver quand l’application est verrouillée, si la réception en arrière-plan est activée. **Rejoindre** ouvre d’abord la saisie du mot de passe lorsque la session est verrouillée. Si l’invitation expire pendant la saisie, Entre Amis ouvre le salon.

- Un appel entrant peut réveiller l’écran verrouillé et afficher « Rejoindre » et « Refuser ». Sur Android 14 ou plus récent, ouvre **Notifications → Réglages Android → Appels en plein écran** et autorise Entre Amis. Tu peux également toucher la notification. Android demande le déverrouillage avant d’ouvrir l’appel si l’écran est protégé.

- Active les notifications dans **Options du salon → Notifications** et accorde l’autorisation Android. La réception en arrière-plan surveille le salon ouvert. La notification permanente permet de l’arrêter. Android 15 peut l’interrompre après six heures en arrière-plan. Rouvre Entre Amis pour reprendre la réception.
- Pendant les appels, l’application utilise le mode audio de communication d’Android. Le son reçu dispose d’un lecteur distinct de la vidéo.

- La préparation du micro et de la caméra dispose de plus de temps sur les appareils lents. Après acceptation d’un appel, un nouveau délai laisse aux deux appareils le temps d’établir la liaison.

- Le manifeste déclare la permission Android de réglage audio utilisée par WebView pour ouvrir le micro lors d’un appel.
- Un appui long sur un message texte donne accès à « Copier le texte ».
- « Apparence », à l’accueil et dans les options du salon, permet de choisir un thème clair, sombre ou celui du téléphone. Le réglage est mémorisé. Les appels gardent leur écran sombre.
- Dans « Rechercher dans le salon », cochez « Pièces jointes uniquement » pour lister les fichiers récents enregistrés dans l’historique de ce salon. Vous pouvez affiner la liste par mot, auteur ou nom de fichier.
- « Tester la connexion », à l’accueil et dans les options du salon, interroge l’adresse publique du relais Eclipse. Le résultat distingue un délai d’attente, une erreur HTTPS et un relais introuvable. Il peut être copié pour le support.
- Dans les options du salon, « Rechercher dans le salon » retrouve les messages enregistrés par mot, auteur ou nom de pièce jointe. Touchez un résultat pour afficher le message.
- Un brouillon texte est conservé sur le téléphone pour chaque salon. « Mes conversations » signale les salons avec un brouillon. Le brouillon est effacé après la mise en file du message.
- Correctif réunion : l’activation de la caméra continue pour les autres participants si l’un d’eux quitte pendant la mise à jour vidéo.
- Android 8 ou ultérieur.
- Le relais WordPress Eclipse 1.2.1 corrige l’utilisation du mot réservé `signal` dans les requêtes MariaDB. Il conserve la colonne existante et les mêmes routes. Pour mettre à jour l’extension, téléversez le ZIP et remplacez la version installée depuis WordPress, puis activez-la.
- Réunions jusqu’à quatre personnes. Les participants ouvrent le même groupe pour recevoir l’invitation. La caméra est coupée au départ en réunion.
- Les échanges audio et vidéo empruntent des liaisons WebRTC directes. Certaines connexions nécessitent un relais TURN. Ce paquet n’en configure aucun.

## Compilation

Exécuter `./build.sh` avec Android SDK 35, JDK, Bash et zip. Pour produire une mise à jour signée, renseigner `ENTRE_AMIS_SIGNING_STORE` et `ENTRE_AMIS_PASSWORD_FILE` avec les fichiers privés de l’édition Entre Amis. Fournir son précédent APK signé dans `ENTRE_AMIS_PREVIOUS_APK` pour vérifier le certificat. Conserver la clé chiffrée et son mot de passe séparément, en dehors des fichiers distribués.

## Vérification

- `AppPasswordCheck.java` vérifie la création du mot de passe, les tentatives erronées, la pause persistante et le changement de mot de passe. Il s’exécute sur le JDK avec `AppPassword.java` et le fichier `android.jar` dans le classpath.

- `MessageSearchCheck.java` couvre la recherche locale et le filtre des pièces jointes avec ou sans mot-clé. Ce test s’exécute sur le JDK avec `MessageSearch.java`, sans SDK Android.
- Exécuter `node build/test/media.cjs` avec Playwright et Chromium. La variable `ENTRE_AMIS_CHROMIUM` permet de sélectionner un binaire Chromium existant.
- `build/test/RelayDiagnosticCheck.java` vérifie la requête d’état publique et les messages du diagnostic avec le même relais de test que `RelayCheck`.
- Les fichiers `build/test/server.php` et `build/test/RelayCheck.java` testent les requêtes et la rétrocompatibilité avec un relais PHP local et une base SQLite de test. Cette vérification ne remplace pas un essai sur WordPress Eclipse et deux téléphones Android.
