<?php
/**
 * Plugin Name: Entre Amis – Relais
 * Description: Relais HTTPS des messages chiffrés de l’application Android Entre Amis.
 * Version: 1.3.2
 * Requires at least: 6.2
 * Requires PHP: 7.4
 */

defined('ABSPATH') || exit;
require_once __DIR__ . '/profil.php';

final class Entre_Amis_Relais {
    private const API = 'entre-amis/v1';
    private const CLEANUP = 'entre_amis_cleanup';
    private const RETENTION = 604800;
    private const PAGE = 60;
    private const FILE_RETENTION = 172800;
    private const MAX_FILE = 2097152;
    private const MAX_ENCODED_FILE = 2796240;
    private const FILE_SCHEMA = 'entre_amis_files_schema_1';
    private const CALL_SCHEMA = 'entre_amis_calls_schema_1';
    private const OWNER_SCHEMA = 'entre_amis_owners_schema_1';
    private const CONTACT_SCHEMA = 'entre_amis_contacts_schema_1';
    private const CONTACT_RELATIONS_SCHEMA = 'entre_amis_contact_relations_schema_1';
    private const CONTACT_INVITE_RETENTION = 604800;
    private const CALL_RETENTION = 120;
    private const CALL_PAGE = 20;
    private const UUID = '[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}';

    public static function install() {
        global $wpdb;
        $messages = $wpdb->prefix . 'entre_amis_messages';
        $limits = $wpdb->prefix . 'entre_amis_limits';
        $collation = $wpdb->get_charset_collate();
        $created = $wpdb->query("CREATE TABLE IF NOT EXISTS $messages (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            room CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            uid CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            payload VARCHAR(4096) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            created BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY room_uid (room, uid),
            KEY room_id (room, id),
            KEY expiry (created)
        ) ENGINE=InnoDB $collation");
        $limited = $wpdb->query("CREATE TABLE IF NOT EXISTS $limits (
            bucket CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            slot BIGINT UNSIGNED NOT NULL,
            hits INT UNSIGNED NOT NULL,
            PRIMARY KEY (bucket, slot),
            KEY expiry (slot)
        ) ENGINE=InnoDB $collation");
        if ($created === false || $limited === false || !self::ensure_files_table() || !self::ensure_calls_table() || !self::ensure_owners_table()) {
            wp_die('Impossible de créer les tables de messagerie.');
        }
        if (!wp_next_scheduled(self::CLEANUP)) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', self::CLEANUP);
        }
    }

    private static function ensure_files_table() {
        global $wpdb;
        if (get_option(self::FILE_SCHEMA)) {
            return true;
        }
        $table = $wpdb->prefix . 'entre_amis_files';
        $collation = $wpdb->get_charset_collate();
        $created = $wpdb->query("CREATE TABLE IF NOT EXISTS $table (
            room CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            uid CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            content MEDIUMTEXT CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            created BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (room, uid),
            KEY expiry (created)
        ) ENGINE=InnoDB $collation");
        if ($created === false) {
            return false;
        }
        add_option(self::FILE_SCHEMA, 1, '', false);
        return true;
    }

    private static function ensure_calls_table() {
        global $wpdb;
        if (get_option(self::CALL_SCHEMA)) {
            return true;
        }
        $table = $wpdb->prefix . 'entre_amis_calls';
        $collation = $wpdb->get_charset_collate();
        $created = $wpdb->query("CREATE TABLE IF NOT EXISTS $table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            room CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            call_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            sender CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            recipient VARCHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            `signal` MEDIUMTEXT CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            created BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY room_id (room, id),
            KEY room_call (room, call_id, id),
            KEY expiry (created)
        ) ENGINE=InnoDB $collation");
        if ($created === false) {
            return false;
        }
        add_option(self::CALL_SCHEMA, 1, '', false);
        return true;
    }

    private static function ensure_owners_table() {
        global $wpdb;
        if (get_option(self::OWNER_SCHEMA)) {
            return true;
        }
        $table = $wpdb->prefix . 'entre_amis_owners';
        $collation = $wpdb->get_charset_collate();
        $created = $wpdb->query("CREATE TABLE IF NOT EXISTS $table (
            room CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            uid CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            owner_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            has_file TINYINT UNSIGNED NOT NULL,
            removed TINYINT UNSIGNED NOT NULL DEFAULT 0,
            action_target VARCHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
            action_type VARCHAR(6) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
            created BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (room, uid),
            KEY expiry (created)
        ) ENGINE=InnoDB $collation");
        if ($created === false) {
            return false;
        }
        add_option(self::OWNER_SCHEMA, 1, '', false);
        return true;
    }

    public static function deactivate() {
        wp_clear_scheduled_hook(self::CLEANUP);
    }

    public static function routes() {
        register_rest_route(self::API, '/etat', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => static function () { return self::response(['ok' => true, 'version' => 3, 'max_file_size' => self::MAX_FILE, 'calls' => true, 'contacts' => true, 'contacts_version' => 2, 'profile' => Entre_Amis_Profil::available()]); },
        ]);
        register_rest_route(self::API, '/profil', [
            'methods' => 'POST',
            'permission_callback' => [Entre_Amis_Profil::class, 'authorize'],
            'callback' => static function (WP_REST_Request $request) {
                return Entre_Amis_Profil::action($request, static function (...$args) {
                    return self::rate_limit(...$args);
                });
            },
        ]);
        register_rest_route(self::API, '/profil/retour', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => [Entre_Amis_Profil::class, 'callback'],
        ]);
        register_rest_route(self::API, '/contacts', [
            'methods' => 'POST',
            'permission_callback' => [self::class, 'authorize_contact'],
            'callback' => [self::class, 'contacts'],
        ]);
        register_rest_route(self::API, '/salons/(?P<room>[0-9a-f]{64})', [
            [
                'methods' => 'GET',
                'permission_callback' => [self::class, 'authorize'],
                'callback' => [self::class, 'read'],
            ],
            [
                'methods' => 'POST',
                'permission_callback' => [self::class, 'authorize'],
                'callback' => [self::class, 'write'],
            ],
        ]);
        register_rest_route(self::API, '/salons/(?P<room>[0-9a-f]{64})/fichiers/(?P<uid>' . self::UUID . ')', [
            [
                'methods' => 'GET',
                'permission_callback' => [self::class, 'authorize'],
                'callback' => [self::class, 'download'],
            ],
            [
                'methods' => 'POST',
                'permission_callback' => [self::class, 'authorize'],
                'callback' => [self::class, 'write'],
            ],
        ]);
        register_rest_route(self::API, '/salons/(?P<room>[0-9a-f]{64})/appels', [
            [
                'methods' => 'GET',
                'permission_callback' => [self::class, 'authorize'],
                'callback' => [self::class, 'read_calls'],
            ],
            [
                'methods' => 'POST',
                'permission_callback' => [self::class, 'authorize'],
                'callback' => [self::class, 'write_call'],
            ],
        ]);
        register_rest_route(self::API, '/salons/(?P<room>[0-9a-f]{64})/messages/(?P<uid>' . self::UUID . ')', [
            'methods' => 'POST',
            'permission_callback' => [self::class, 'authorize'],
            'callback' => [self::class, 'change_message'],
        ]);
    }

    public static function authorize(WP_REST_Request $request) {
        $key = (string) $request->get_header('x-entre-amis-key');
        $room = $request->get_url_params()['room'];
        if (!preg_match('/\A[0-9a-f]{64}\z/', $key)
                || !hash_equals($room, hash('sha256', $key))) {
            return new WP_Error('entre_amis_access', 'Invitation requise.', ['status' => 403]);
        }
        return true;
    }

    public static function authorize_contact(WP_REST_Request $request) {
        $proof = (string) $request->get_header('x-entre-amis-contact');
        if (!preg_match('/\A[0-9a-f]{64}\z/', $proof)) {
            return new WP_Error('entre_amis_contact', 'Accès aux contacts invalide.', ['status' => 403]);
        }
        return true;
    }

    private static function ensure_contacts_tables() {
        global $wpdb;
        if (get_option(self::CONTACT_SCHEMA)) return true;
        $people = $wpdb->prefix . 'entre_amis_contacts';
        $invites = $wpdb->prefix . 'entre_amis_contact_invites';
        $collation = $wpdb->get_charset_collate();
        $first = $wpdb->query("CREATE TABLE IF NOT EXISTS $people (
            device CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            proof_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            public_key VARCHAR(122) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            session_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            nickname VARCHAR(120) NOT NULL,
            lookup_key CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            visible_until BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (device),
            KEY visible_name (lookup_key, visible_until),
            KEY expiry (visible_until)
        ) ENGINE=InnoDB $collation");
        $second = $wpdb->query("CREATE TABLE IF NOT EXISTS $invites (
            sender CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            recipient CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            created BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (recipient, sender),
            KEY expiry (created)
        ) ENGINE=InnoDB $collation");
        if ($first === false || $second === false) return false;
        add_option(self::CONTACT_SCHEMA, 1, '', false);
        return true;
    }

    private static function contact_name($value) {
        if (!is_string($value)) return null;
        $name = trim($value);
        return preg_match('/\A[^\p{C}]{1,30}\z/u', $name) ? $name : null;
    }

    private static function ensure_contact_relations() {
        global $wpdb;
        if (get_option(self::CONTACT_RELATIONS_SCHEMA)) return true;
        $people = $wpdb->prefix . 'entre_amis_contacts';
        $links = $wpdb->prefix . 'entre_amis_contact_links';
        $blocks = $wpdb->prefix . 'entre_amis_contact_blocks';
        $first = $wpdb->query("CREATE TABLE IF NOT EXISTS $links (
            first_device CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            second_device CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            PRIMARY KEY (first_device, second_device)
        ) ENGINE=InnoDB");
        $second = $wpdb->query("CREATE TABLE IF NOT EXISTS $blocks (
            blocker CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            blocked CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            PRIMARY KEY (blocker, blocked)
        ) ENGINE=InnoDB");
        if ($first === false || $second === false) return false;
        $directory_column = "SHOW COLUMNS FROM $people LIKE 'directory_enabled'";
        if ($wpdb->get_var($directory_column) === null
                && $wpdb->query("ALTER TABLE $people ADD COLUMN directory_enabled TINYINT UNSIGNED NOT NULL DEFAULT 0") === false
                && $wpdb->get_var($directory_column) === null) return false;
        add_option(self::CONTACT_RELATIONS_SCHEMA, 1, '', false);
        return true;
    }

    private static function contact_lookup($name) {
        return hash('sha256', strtolower(remove_accents($name)));
    }

    public static function contacts(WP_REST_Request $request) {
        global $wpdb;
        if (strlen($request->get_body()) > 2048) return self::response(['error' => 'Requête trop longue.'], 413);
        $body = $request->get_json_params();
        if (($body['protocol'] ?? null) !== 2) {
            return self::response(['error' => 'Mets à jour Entre Amis pour utiliser les contacts.'], 426);
        }
        $action = $body['action'] ?? '';
        $device = $body['device'] ?? '';
        $session = $body['session'] ?? '';
        $uuid = '/\A' . self::UUID . '\z/';
        if (!is_string($action) || !is_string($device) || !is_string($session)
                || !preg_match($uuid, $device) || !preg_match($uuid, $session)) {
            return self::response(['error' => 'Contact invalide.'], 400);
        }
        $limited = self::rate_limit('contacts', 180) ?? self::rate_limit('contacts', 4000, 1, true);
        if ($limited !== null) return $limited;
        if (!self::ensure_contacts_tables() || !self::ensure_contact_relations()) return self::unavailable();
        $people = $wpdb->prefix . 'entre_amis_contacts';
        $invites = $wpdb->prefix . 'entre_amis_contact_invites';
        $links = $wpdb->prefix . 'entre_amis_contact_links';
        $blocks = $wpdb->prefix . 'entre_amis_contact_blocks';
        $proof = hash('sha256', $request->get_header('x-entre-amis-contact'));
        $now = time();
        $valid_since = $now - self::CONTACT_INVITE_RETENTION;
        if ($action === 'visible') {
            $name = self::contact_name($body['nickname'] ?? null);
            $key = $body['publicKey'] ?? '';
            if ($name === null || !is_string($key) || !preg_match('/\A[A-Za-z0-9_-]{122}\z/', $key)) {
                return self::response(['error' => 'Pseudo ou clé de contact invalide.'], 400);
            }
            $saved = $wpdb->query($wpdb->prepare(
                "INSERT INTO $people (device, proof_hash, public_key, session_id, nickname, lookup_key, visible_until, directory_enabled)
                 VALUES (%s, %s, %s, %s, %s, %s, %d, 1)
                 ON DUPLICATE KEY UPDATE
                    session_id = IF(proof_hash = VALUES(proof_hash) AND public_key = VALUES(public_key), VALUES(session_id), session_id),
                    nickname = IF(proof_hash = VALUES(proof_hash) AND public_key = VALUES(public_key), VALUES(nickname), nickname),
                    lookup_key = IF(proof_hash = VALUES(proof_hash) AND public_key = VALUES(public_key), VALUES(lookup_key), lookup_key),
                    visible_until = IF(proof_hash = VALUES(proof_hash) AND public_key = VALUES(public_key), VALUES(visible_until), visible_until),
                    directory_enabled = IF(proof_hash = VALUES(proof_hash) AND public_key = VALUES(public_key), 1, directory_enabled)",
                $device, $proof, $key, $session, $name, self::contact_lookup($name), $now + 45
            ));
            if ($saved === false) return self::unavailable();
        }
        $registered = $wpdb->get_var($wpdb->prepare(
            "SELECT device FROM $people WHERE device = %s AND proof_hash = %s AND session_id = %s AND visible_until >= %d AND directory_enabled = 1",
            $device, $proof, $session, $now
        ));
        if ($registered === null) return self::response(['error' => 'Session de contact expirée.'], 403);
        if ($action === 'visible') {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT p.device, p.nickname FROM $invites i JOIN $people p ON p.device = i.sender
                 WHERE i.recipient = %s AND i.created >= %d AND p.directory_enabled = 1
                 AND NOT EXISTS (SELECT 1 FROM $blocks b WHERE (b.blocker = i.sender AND b.blocked = i.recipient)
                    OR (b.blocker = i.recipient AND b.blocked = i.sender))
                 AND NOT EXISTS (SELECT 1 FROM $links l WHERE (l.first_device = i.sender AND l.second_device = i.recipient)
                    OR (l.first_device = i.recipient AND l.second_device = i.sender))
                 ORDER BY i.created DESC, i.sender LIMIT 30",
                $device, $valid_since
            ), ARRAY_A);
            return $rows === null ? self::unavailable()
                : self::response(['ok' => true, 'protocol' => 2, 'requests' => $rows]);
        }
        if ($action === 'search' || $action === 'directory') {
            $after = $body['after'] ?? '';
            if (!is_string($after) || ($after !== '' && !preg_match($uuid, $after))) {
                return self::response(['error' => 'Page invalide.'], 400);
            }
            $filter = '';
            if ($action === 'search') {
                $name = self::contact_name($body['nickname'] ?? null);
                if ($name === null) return self::response(['error' => 'Pseudo invalide.'], 400);
                $filter = $wpdb->prepare(' AND p.lookup_key = %s', self::contact_lookup($name));
            }
            $query = $wpdb->prepare(
                "SELECT p.device, p.nickname, CASE WHEN p.visible_until >= %d THEN 1 ELSE 0 END AS online,
                    CASE WHEN b.blocker IS NOT NULL THEN 1 ELSE 0 END AS blocked,
                    CASE WHEN l.first_device IS NOT NULL AND b.blocker IS NULL AND r.blocker IS NULL
                        THEN 1 ELSE 0 END AS trusted,
                    CASE WHEN i.sender IS NOT NULL AND b.blocker IS NULL AND r.blocker IS NULL
                        AND l.first_device IS NULL THEN 1 ELSE 0 END AS pending
                 FROM $people p
                 LEFT JOIN $blocks b ON b.blocker = %s AND b.blocked = p.device
                 LEFT JOIN $blocks r ON r.blocker = p.device AND r.blocked = %s
                 LEFT JOIN $links l ON (l.first_device = %s AND l.second_device = p.device)
                    OR (l.first_device = p.device AND l.second_device = %s)
                 LEFT JOIN $invites i ON i.sender = %s AND i.recipient = p.device AND i.created >= %d
                 WHERE p.device <> %s AND p.device > %s AND p.directory_enabled = 1",
                $now, $device, $device, $device, $device, $device, $valid_since, $device, $after
            );
            $rows = $wpdb->get_results($query . $filter . ' ORDER BY p.device LIMIT 31', ARRAY_A);
            if ($rows === null) return self::unavailable();
            $next = count($rows) > 30 ? $rows[29]['device'] : '';
            return self::response(['ok' => true, 'contacts' => array_slice($rows, 0, 30), 'next' => $next]);
        }
        if ($action === 'hidden') {
            $changed = $wpdb->query($wpdb->prepare(
                "UPDATE $people SET visible_until = %d WHERE device = %s AND proof_hash = %s AND session_id = %s",
                $now - 1, $device, $proof, $session
            ));
            return $changed === false ? self::unavailable() : self::response(['ok' => true]);
        }
        $peer = $body['peer'] ?? '';
        if (!is_string($peer) || !preg_match($uuid, $peer) || $peer === $device) {
            return self::response(['error' => 'Contact invalide.'], 400);
        }
        [$first, $second] = strcmp($device, $peer) < 0 ? [$device, $peer] : [$peer, $device];
        if ($action === 'block') {
            $changed = $wpdb->query($wpdb->prepare(
                "INSERT IGNORE INTO $blocks (blocker, blocked) VALUES (%s, %s)", $device, $peer
            ));
            if ($changed === false) return self::unavailable();
            self::clear_contact_invites($invites, $device, $peer);
            return self::response(['ok' => true]);
        }
        if ($action === 'unblock') {
            if (!self::clear_contact_invites($invites, $device, $peer)) return self::unavailable();
            $changed = $wpdb->query($wpdb->prepare(
                "DELETE FROM $blocks WHERE blocker = %s AND blocked = %s", $device, $peer
            ));
            return $changed === false ? self::unavailable() : self::response(['ok' => true]);
        }
        if ($action === 'remove') {
            if (!self::clear_contact_invites($invites, $device, $peer)) return self::unavailable();
            $changed = $wpdb->query($wpdb->prepare(
                "DELETE FROM $links WHERE first_device = %s AND second_device = %s", $first, $second
            ));
            return $changed === false ? self::unavailable() : self::response(['ok' => true]);
        }
        if ($action === 'dismiss' || $action === 'cancel') {
            $sender = $action === 'cancel' ? $device : $peer;
            $recipient = $action === 'cancel' ? $peer : $device;
            $changed = $wpdb->query($wpdb->prepare(
                "DELETE FROM $invites WHERE recipient = %s AND sender = %s", $recipient, $sender
            ));
            return $changed === false ? self::unavailable() : self::response(['ok' => true]);
        }
        $blocked = $wpdb->get_var($wpdb->prepare(
            "SELECT blocker FROM $blocks WHERE (blocker = %s AND blocked = %s)
                OR (blocker = %s AND blocked = %s) LIMIT 1", $device, $peer, $peer, $device
        ));
        if ($wpdb->last_error !== '') return self::unavailable();
        if ($blocked !== null) return self::response(['error' => 'Contact indisponible.'], 409);
        if ($action === 'accept') {
            $accepted = $wpdb->query($wpdb->prepare(
                "INSERT IGNORE INTO $links (first_device, second_device)
                 SELECT %s, %s FROM $invites WHERE recipient = %s AND sender = %s AND created >= %d",
                $first, $second, $device, $peer, $valid_since
            ));
            if ($accepted === false) return self::unavailable();
        }
        $trusted = $wpdb->get_var($wpdb->prepare(
            "SELECT first_device FROM $links WHERE first_device = %s AND second_device = %s",
            $first, $second
        ));
        if ($wpdb->last_error !== '') return self::unavailable();
        if ($action === 'open' || $action === 'accept' || ($action === 'invite' && $trusted !== null)) {
            if ($trusted === null) return self::response(['error' => 'Acceptation nécessaire.'], 409);
            if ($action === 'accept') self::clear_contact_invites($invites, $device, $peer);
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT device, nickname, public_key FROM $people WHERE device = %s AND directory_enabled = 1", $peer
            ), ARRAY_A);
            if ($rows === null) return self::unavailable();
            if (count($rows) !== 1) return self::response(['error' => 'Contact indisponible.'], 409);
            return self::response(['ok' => true, 'contact' => $rows[0]]);
        }
        if ($action === 'invite') {
            $limited = self::rate_limit('contacts-invite', 12);
            if ($limited !== null) return $limited;
            $available = $wpdb->get_var($wpdb->prepare(
                "SELECT device FROM $people WHERE device = %s AND directory_enabled = 1", $peer
            ));
            if ($available === null) return self::response(['error' => 'Contact indisponible.'], 409);
            $changed = $wpdb->query($wpdb->prepare(
                "INSERT INTO $invites (sender, recipient, created) VALUES (%s, %s, %d)
                 ON DUPLICATE KEY UPDATE created = VALUES(created)", $device, $peer, $now
            ));
            return $changed === false ? self::unavailable() : self::response(['ok' => true, 'pending' => true]);
        }
        return self::response(['error' => 'Action de contact inconnue.'], 400);
    }

    private static function clear_contact_invites($invites, $device, $peer) {
        global $wpdb;
        return $wpdb->query($wpdb->prepare(
            "DELETE FROM $invites WHERE (sender = %s AND recipient = %s) OR (sender = %s AND recipient = %s)",
            $device, $peer, $peer, $device
        )) !== false;
    }

    public static function no_cache($response, $server, WP_REST_Request $request) {
        if (strpos($request->get_route(), '/' . self::API . '/') === 0) {
            $response->header('Cache-Control', 'no-store, private, max-age=0');
            $response->header('X-Robots-Tag', 'noindex, nofollow');
        }
        return $response;
    }

    public static function read(WP_REST_Request $request) {
        global $wpdb;
        $after = (string) ($request->get_query_params()['after'] ?? '0');
        if (!preg_match('/\A[0-9]{1,18}\z/', $after)) {
            return self::response(['error' => 'Curseur invalide.'], 400);
        }
        $limit = self::rate_limit('read', 180);
        if ($limit !== null) {
            return $limit;
        }
        if (!self::ensure_owners_table()) {
            return self::unavailable();
        }
        $table = $wpdb->prefix . 'entre_amis_messages';
        $owners = $wpdb->prefix . 'entre_amis_owners';
        $room = $request->get_url_params()['room'];
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT m.id, m.uid, m.payload, m.created, o.action_target, o.action_type
             FROM $table m LEFT JOIN $owners o ON o.room = m.room AND o.uid = m.uid
             WHERE m.room = %s AND m.id > %d AND m.created >= %d ORDER BY m.id ASC LIMIT %d",
            $room, (int) $after, time() - self::RETENTION, self::PAGE + 1
        ), ARRAY_A);
        if ($wpdb->last_error !== '') {
            return self::unavailable();
        }
        $more = count($rows) > self::PAGE;
        return self::response(['messages' => array_slice($rows, 0, self::PAGE), 'more' => $more]);
    }

    public static function write(WP_REST_Request $request) {
        global $wpdb;
        if (strlen($request->get_body()) > self::MAX_ENCODED_FILE + 4300) {
            return self::response(['error' => 'Message trop long.'], 413);
        }
        $data = $request->get_json_params();
        $uid = $data['uid'] ?? null;
        $payload = $data['payload'] ?? null;
        $file = $data['file'] ?? null;
        $owner = $data['owner'] ?? null;
        $file_uid = $request->get_url_params()['uid'] ?? null;
        if (($file_uid === null && $file !== null) || ($file_uid !== null && ($file === null || $uid !== $file_uid))) {
            return self::response(['error' => 'Pièce jointe invalide.'], 400);
        }
        if (($owner !== null && (!is_string($owner) || !preg_match('/\A[0-9a-f]{64}\z/', $owner)))
                || !is_string($uid) || !is_string($payload)
                || !preg_match('/\A' . self::UUID . '\z/', $uid)
                || !preg_match('/\Aea1\.[A-Za-z0-9_-]{38,4092}\z/', $payload)) {
            return self::response(['error' => 'Message invalide.'], 400);
        }
        $limit = self::rate_limit('write', 60);
        if ($limit !== null) {
            return $limit;
        }
        if ($file !== null) {
            if (!is_string($file) || strlen($file) < 39 || strlen($file) > self::MAX_ENCODED_FILE
                    || strlen($file) % 4 === 1
                    || strspn($file, 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-') !== strlen($file)) {
                return self::response(['error' => 'Pièce jointe invalide.'], 400);
            }
            $limit = self::rate_limit('file_upload', 20, 1440);
            if ($limit !== null) {
                return $limit;
            }
            $limit = self::rate_limit('file_total', 50, 1440, true);
            if ($limit !== null) {
                return $limit;
            }
            if (!self::ensure_files_table()) {
                return self::unavailable();
            }
        }

        if ($owner !== null && !self::ensure_owners_table()) {
            return self::unavailable();
        }
        $messages = $wpdb->prefix . 'entre_amis_messages';
        $files = $wpdb->prefix . 'entre_amis_files';
        $owners = $wpdb->prefix . 'entre_amis_owners';
        $room = $request->get_url_params()['room'];
        // Serialize inserts within a room so a reader can safely resume by row ID.
        $lock = hash('sha256', $messages . '/' . $room);
        if ((string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 3)', $lock)) !== '1') {
            return self::unavailable();
        }
        $transaction = false;
        try {
            if ($file !== null || $owner !== null) {
                $transaction = $wpdb->query('START TRANSACTION') !== false;
                if (!$transaction) {
                    return self::unavailable();
                }
            }
            $now = time();
            $result = $wpdb->query($wpdb->prepare(
                "INSERT INTO $messages (room, uid, payload, created) VALUES (%s, %s, %s, %d)
                 ON DUPLICATE KEY UPDATE uid = uid",
                $room, $uid, $payload, $now
            ));
            if ($result === false) {
                return self::unavailable();
            }
            if ($transaction) {
                if ($result > 0 && $file !== null && $wpdb->query($wpdb->prepare(
                    "INSERT INTO $files (room, uid, content, created) VALUES (%s, %s, %s, %d)
                     ON DUPLICATE KEY UPDATE uid = uid",
                    $room, $uid, $file, $now
                )) === false) {
                    return self::unavailable();
                }
                if ($result > 0 && $owner !== null && $wpdb->query($wpdb->prepare(
                    "INSERT INTO $owners (room, uid, owner_hash, has_file, created)
                     VALUES (%s, %s, %s, %d, %d) ON DUPLICATE KEY UPDATE uid = uid",
                    $room, $uid, $owner, $file === null ? 0 : 1, $now
                )) === false) {
                    return self::unavailable();
                }
                if ($wpdb->query('COMMIT') === false) {
                    return self::unavailable();
                }
                $transaction = false;
            }
            return self::response(['ok' => true]);
        } finally {
            if ($transaction) {
                $wpdb->query('ROLLBACK');
            }
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
    }

    public static function download(WP_REST_Request $request) {
        global $wpdb;
        $limit = self::rate_limit('file_download', 40, 60);
        if ($limit !== null) {
            return $limit;
        }
        if (!self::ensure_files_table()) {
            return self::unavailable();
        }
        $table = $wpdb->prefix . 'entre_amis_files';
        $params = $request->get_url_params();
        $file = $wpdb->get_var($wpdb->prepare(
            "SELECT content FROM $table WHERE room = %s AND uid = %s AND created >= %d",
            $params['room'], $params['uid'], time() - self::FILE_RETENTION
        ));
        if ($wpdb->last_error !== '') {
            return self::unavailable();
        }
        return $file === null ? self::response(['error' => 'Pièce jointe indisponible.'], 404)
                : self::response(['file' => $file]);
    }

    public static function change_message(WP_REST_Request $request) {
        global $wpdb;
        if (strlen($request->get_body()) > 10000) {
            return self::response(['error' => 'Modification trop longue.'], 413);
        }
        $data = $request->get_json_params();
        $uid = $data['event'] ?? '';
        $operation = $data['operation'] ?? '';
        $event = $data['payload'] ?? '';
        $replacement = $data['replacement'] ?? '';
        $proof = (string) $request->get_header('x-entre-amis-owner');
        $params = $request->get_url_params();
        $room = $params['room'];
        $target = $params['uid'];
        if (!self::is_uuid($uid) || $uid === $target || !preg_match('/\A[0-9a-f]{64}\z/', $proof)
                || !in_array($operation, ['edit', 'delete'], true)
                || !self::valid_message($event)
                || ($operation === 'edit' && !self::valid_message($replacement))) {
            return self::response(['error' => 'Modification invalide.'], 400);
        }
        $limit = self::rate_limit('message_change', 40);
        if ($limit !== null) {
            return $limit;
        }
        if (!self::ensure_owners_table() || !self::ensure_files_table()) {
            return self::unavailable();
        }

        $messages = $wpdb->prefix . 'entre_amis_messages';
        $owners = $wpdb->prefix . 'entre_amis_owners';
        $files = $wpdb->prefix . 'entre_amis_files';
        $lock = hash('sha256', $messages . '/' . $room);
        if ((string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 3)', $lock)) !== '1') {
            return self::unavailable();
        }
        $transaction = false;
        try {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT owner_hash, has_file, removed FROM $owners WHERE room = %s AND uid = %s AND action_type = ''", $room, $target
            ), ARRAY_A);
            if ($wpdb->last_error !== '') {
                return self::unavailable();
            }
            $owner = $rows[0] ?? null;
            if ($owner === null || !hash_equals($owner['owner_hash'], hash('sha256', $proof))) {
                return self::response(['error' => 'Modification réservée à l’auteur.'], 403);
            }
            if ($wpdb->get_var($wpdb->prepare(
                "SELECT id FROM $messages WHERE room = %s AND uid = %s", $room, $uid
            )) !== null) {
                return self::response(['ok' => true]);
            }
            if ((int) $owner['removed'] !== 0 || ($operation === 'edit' && (int) $owner['has_file'] !== 0)) {
                return self::response(['error' => 'Message indisponible pour cette action.'], 409);
            }

            $transaction = $wpdb->query('START TRANSACTION') !== false;
            if (!$transaction) {
                return self::unavailable();
            }
            if ($wpdb->query($wpdb->prepare(
                "UPDATE $messages SET payload = %s WHERE room = %s AND uid = %s",
                $operation === 'delete' ? '' : $replacement, $room, $target
            )) === false) {
                return self::unavailable();
            }
            if ($operation === 'delete' && ($wpdb->query($wpdb->prepare(
                "UPDATE $owners SET removed = 1 WHERE room = %s AND uid = %s", $room, $target
            )) === false || $wpdb->query($wpdb->prepare(
                "DELETE FROM $files WHERE room = %s AND uid = %s", $room, $target
            )) === false)) {
                return self::unavailable();
            }
            if ($wpdb->query($wpdb->prepare(
                "INSERT INTO $messages (room, uid, payload, created) VALUES (%s, %s, %s, %d)",
                $room, $uid, $event, time()
            )) === false || $wpdb->query($wpdb->prepare(
                "INSERT INTO $owners (room, uid, owner_hash, has_file, created, action_target, action_type)
                 VALUES (%s, %s, %s, 0, %d, %s, %s)",
                $room, $uid, $owner['owner_hash'], time(), $target, $operation
            )) === false || $wpdb->query('COMMIT') === false) {
                return self::unavailable();
            }
            $transaction = false;
            return self::response(['ok' => true]);
        } finally {
            if ($transaction) {
                $wpdb->query('ROLLBACK');
            }
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
    }

    private static function valid_message($payload) {
        return is_string($payload) && preg_match('/\Aea1\.[A-Za-z0-9_-]{38,4092}\z/', $payload) === 1;
    }

    public static function read_calls(WP_REST_Request $request) {
        global $wpdb;
        $query = $request->get_query_params();
        $after = $query['after'] ?? '0';
        $device = $query['device'] ?? '';
        $call = $query['call'] ?? '';
        if (!is_string($after) || !preg_match('/\A[0-9]{1,18}\z/', $after)
                || !self::is_uuid($device) || ($call !== '' && !self::is_uuid($call))) {
            return self::response(['error' => 'Paramètres d’appel invalides.'], 400);
        }
        $limit = self::rate_limit('call_read', 240);
        if ($limit !== null) {
            return $limit;
        }
        if (!self::ensure_calls_table()) {
            return self::unavailable();
        }
        $table = $wpdb->prefix . 'entre_amis_calls';
        $room = $request->get_url_params()['room'];
        $now = time();
        $clause = $call === '' ? "recipient = ''" : $wpdb->prepare(
            "(recipient = %s OR recipient = '') AND call_id = %s", $device, $call
        );
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, call_id, sender, recipient, `signal`, created FROM $table
             WHERE room = %s AND id > %d AND created >= %d AND sender <> %s AND $clause
             ORDER BY id ASC LIMIT %d",
            $room, (int) $after, $now - self::CALL_RETENTION, $device, self::CALL_PAGE + 1
        ), ARRAY_A);
        if ($wpdb->last_error !== '') {
            return self::unavailable();
        }
        return self::response([
            'signals' => array_slice($rows, 0, self::CALL_PAGE),
            'more' => count($rows) > self::CALL_PAGE,
            'now' => $now,
        ]);
    }

    public static function write_call(WP_REST_Request $request) {
        global $wpdb;
        if (strlen($request->get_body()) > 49500) {
            return self::response(['error' => 'Signal d’appel trop long.'], 413);
        }
        $data = $request->get_json_params();
        $call = $data['call'] ?? null;
        $sender = $data['sender'] ?? null;
        $recipient = $data['recipient'] ?? null;
        $signal = $data['signal'] ?? null;
        if (!self::is_uuid($call) || !self::is_uuid($sender)
                || ($recipient !== '' && !self::is_uuid($recipient)) || $sender === $recipient
                || !is_string($signal) || !preg_match('/\Aec1\.[A-Za-z0-9_-]{39,49152}\z/', $signal)) {
            return self::response(['error' => 'Signal d’appel invalide.'], 400);
        }
        $limit = self::rate_limit('call_write', 150);
        if ($limit !== null) {
            return $limit;
        }
        if (!self::ensure_calls_table()) {
            return self::unavailable();
        }
        $table = $wpdb->prefix . 'entre_amis_calls';
        $room = $request->get_url_params()['room'];
        $lock = hash('sha256', $table . '/' . $room);
        if ((string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 3)', $lock)) !== '1') {
            return self::unavailable();
        }
        try {
            $result = $wpdb->query($wpdb->prepare(
                "INSERT INTO $table (room, call_id, sender, recipient, `signal`, created)
                 VALUES (%s, %s, %s, %s, %s, %d)",
                $room, $call, $sender, $recipient, $signal, time()
            ));
        } finally {
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
        return $result === false ? self::unavailable() : self::response(['ok' => true]);
    }

    private static function is_uuid($value) {
        return is_string($value) && preg_match('/\A' . self::UUID . '\z/', $value) === 1;
    }

    public static function cleanup() {
        global $wpdb;
        $messages = $wpdb->prefix . 'entre_amis_messages';
        $limits = $wpdb->prefix . 'entre_amis_limits';
        $files = $wpdb->prefix . 'entre_amis_files';
        if (get_option(self::CONTACT_SCHEMA)) {
            $invites = $wpdb->prefix . 'entre_amis_contact_invites';
            $wpdb->query($wpdb->prepare("DELETE FROM $invites WHERE created < %d", time() - self::CONTACT_INVITE_RETENTION));
        }
        if (get_option(self::OWNER_SCHEMA)) {
            $owners = $wpdb->prefix . 'entre_amis_owners';
            $wpdb->query($wpdb->prepare("DELETE FROM $owners WHERE created < %d", time() - self::RETENTION));
        }
        if (get_option(self::CALL_SCHEMA)) {
            $calls = $wpdb->prefix . 'entre_amis_calls';
            $wpdb->query($wpdb->prepare("DELETE FROM $calls WHERE created < %d", time() - self::CALL_RETENTION));
        }
        if (get_option(self::FILE_SCHEMA)) {
            $wpdb->query($wpdb->prepare("DELETE FROM $files WHERE created < %d", time() - self::FILE_RETENTION));
        }
        $wpdb->query($wpdb->prepare("DELETE FROM $messages WHERE created < %d", time() - self::RETENTION));
        $wpdb->query($wpdb->prepare("DELETE FROM $limits WHERE slot < %d", intdiv(time(), 60) - 2880));
    }

    private static function rate_limit($kind, $max, $period = 1, $global = false) {
        global $wpdb;
        $ip = $global ? 'global' : ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        $bucket = hash_hmac('sha256', $kind . '/' . $ip, wp_salt('nonce'));
        $now = time();
        $slot = intdiv($now, 60 * $period) * $period;
        $table = $wpdb->prefix . 'entre_amis_limits';
        $recorded = $wpdb->query($wpdb->prepare(
            "INSERT INTO $table (bucket, slot, hits) VALUES (%s, %d, 1)
             ON DUPLICATE KEY UPDATE hits = hits + 1",
            $bucket, $slot
        ));
        if ($recorded === false) {
            return self::unavailable();
        }
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT hits FROM $table WHERE bucket = %s AND slot = %d", $bucket, $slot
        ));
        if ($count === null) {
            return self::unavailable();
        }
        if ((int) $count <= $max) {
            return null;
        }
        $response = self::response(['error' => 'Trop de requêtes.'], 429);
        $response->header('Retry-After', (string) ($slot * 60 + $period * 60 - $now));
        return $response;
    }

    private static function unavailable() {
        return self::response(['error' => 'Relais momentanément indisponible.'], 503);
    }

    private static function response(array $data, $status = 200) {
        return new WP_REST_Response($data, $status);
    }
}

register_activation_hook(__FILE__, [Entre_Amis_Relais::class, 'install']);
register_deactivation_hook(__FILE__, [Entre_Amis_Relais::class, 'deactivate']);
add_action('rest_api_init', [Entre_Amis_Relais::class, 'routes']);
add_action('entre_amis_cleanup', [Entre_Amis_Relais::class, 'cleanup']);
add_filter('rest_post_dispatch', [Entre_Amis_Relais::class, 'no_cache'], 10, 3);
