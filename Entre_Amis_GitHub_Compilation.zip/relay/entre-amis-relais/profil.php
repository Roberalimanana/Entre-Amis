<?php
defined('ABSPATH') || exit;

final class Entre_Amis_Profil {
    private const TTL = 600;
    private const MAX_PHOTO = 524288;

    public static function available() {
        $meta = self::config('META_VERSION');
        return [
            'google' => self::configured('GOOGLE_ID', 'GOOGLE_SECRET'),
            'facebook' => self::configured('META_ID', 'META_SECRET') && preg_match('/^v[0-9]+\.[0-9]+$/D', $meta) === 1,
            'sms' => preg_match('/^AC[0-9a-fA-F]{32}$/D', self::config('TWILIO_ACCOUNT')) === 1
                && preg_match('/^VA[0-9a-fA-F]{32}$/D', self::config('TWILIO_SERVICE')) === 1
                && self::configured('TWILIO_TOKEN'),
        ];
    }

    public static function authorize(WP_REST_Request $request) {
        if (preg_match('/^[0-9a-f]{64}$/D', (string) $request->get_header('x-entre-amis-profile'))) return true;
        return new WP_Error('entre_amis_profile', 'Accès au profil invalide.', ['status' => 403]);
    }

    public static function action(WP_REST_Request $request, callable $limit) {
        if (strlen($request->get_body()) > 1024) return self::error('Requête trop longue.', 413);
        $body = $request->get_json_params();
        $action = $body['action'] ?? '';
        $proof = (string) $request->get_header('x-entre-amis-profile');
        $owner = hash_hmac('sha256', $proof, wp_salt('nonce'));
        $settings = self::available();
        if ($action === 'status') {
            return self::reply($settings + ['verified' => (bool) get_option('ea_verified_' . $owner)]);
        }
        if ($action === 'photo_start') {
            $provider = $body['provider'] ?? '';
            if (!is_string($provider) || !in_array($provider, ['google', 'facebook'], true) || !$settings[$provider]) {
                return self::error('Ce fournisseur de photo doit être configuré sur Eclipse.', 503);
            }
            return $limit('profile_photo', 8, 10) ?? self::photo_start($owner, $provider);
        }
        if ($action === 'photo_result') {
            $flow = $body['flow'] ?? '';
            if (!is_string($flow) || !preg_match('/^[0-9a-f]{64}$/D', $flow)) return self::error('Import invalide.', 400);
            $state = get_transient('ea_photo_' . $flow);
            if (!is_array($state) || !hash_equals($state['owner'], $owner)) return self::error('Cet import a expiré.', 404);
            return self::reply(['state' => $state['state'], 'photo' => $state['photo'] ?? null]);
        }
        if ($action === 'sms_start' || $action === 'sms_confirm') {
            if (!$settings['sms']) return self::error('Le service SMS doit être configuré sur Eclipse.', 503);
            if ($action === 'sms_start') {
                $number = $body['number'] ?? '';
                if (!is_string($number) || !preg_match('/^\+[1-9][0-9]{7,14}$/D', $number)) return self::error('Saisis un numéro au format international.', 400);
                $number_key = hash_hmac('sha256', $number, wp_salt('nonce'));
                return $limit('profile_sms', 4, 10)
                    ?? $limit('profile_sms_number/' . $number_key, 3, 30, true)
                    ?? $limit('profile_sms_total', 30, 60, true)
                    ?? self::sms_start($owner, $number);
            }
            $code = $body['code'] ?? '';
            if (!is_string($code) || !preg_match('/^[0-9]{4,10}$/D', $code)) return self::error('Saisis le code reçu par SMS.', 400);
            return $limit('profile_sms_check/' . $owner, 6, 10, true)
                ?? $limit('profile_sms_check_ip', 20, 10)
                ?? self::sms_confirm($owner, $code);
        }
        return self::error('Action de profil inconnue.', 400);
    }

    private static function photo_start($owner, $provider) {
        $flow = bin2hex(random_bytes(32));
        $state = bin2hex(random_bytes(32));
        $verifier = bin2hex(random_bytes(32));
        $redirect = rest_url('entre-amis/v1/profil/retour', 'https');
        $params = [
            'client_id' => self::config($provider === 'google' ? 'GOOGLE_ID' : 'META_ID'),
            'redirect_uri' => $redirect,
            'response_type' => 'code',
            'state' => $state,
        ];
        if ($provider === 'google') {
            $url = 'https://accounts.google.com/o/oauth2/v2/auth';
            $params += [
                'scope' => 'openid profile',
                'prompt' => 'select_account',
                'code_challenge' => rtrim(strtr(base64_encode(hash('sha256', $verifier, true)), '+/', '-_'), '='),
                'code_challenge_method' => 'S256',
            ];
        } else {
            $url = 'https://www.facebook.com/' . self::config('META_VERSION') . '/dialog/oauth';
            $params['scope'] = 'public_profile';
        }
        if (!set_transient('ea_photo_' . $flow, ['owner' => $owner, 'state' => 'pending'], self::TTL)
            || !set_transient('ea_oauth_' . $state, [
                'flow' => $flow, 'provider' => $provider, 'redirect' => $redirect, 'verifier' => $verifier,
            ], self::TTL)) {
            return self::error('Impossible de démarrer l’import.', 503);
        }
        return self::reply(['flow' => $flow, 'url' => $url . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986)]);
    }

    public static function callback(WP_REST_Request $request) {
        $query = $request->get_query_params();
        $state = $query['state'] ?? '';
        if (!is_string($state) || !preg_match('/^[0-9a-f]{64}$/D', $state)) return self::error('Autorisation invalide.', 400);
        $session = get_transient('ea_oauth_' . $state);
        if (!is_array($session) || !delete_transient('ea_oauth_' . $state)) return self::error('Autorisation expirée.', 410);
        $key = 'ea_photo_' . $session['flow'];
        $profile = get_transient($key);
        if (!is_array($profile)) return self::error('Autorisation expirée.', 410);
        $code = $query['code'] ?? '';
        $photo = null;
        if (is_string($code) && strlen($code) > 0 && strlen($code) <= 2048 && !isset($query['error'])) {
            $photo = self::provider_photo($session, $code);
        }
        $profile['state'] = $photo === null ? 'unavailable' : 'ready';
        $profile['photo'] = $photo;
        if (!set_transient($key, $profile, self::TTL)) return self::error('Import indisponible.', 503);
        return self::reply(['message' => $photo === null
            ? 'Photo indisponible. Reviens dans Entre Amis.'
            : 'Photo prête. Reviens dans Entre Amis pour l’afficher.']);
    }

    private static function provider_photo($session, $code) {
        $google = $session['provider'] === 'google';
        $client = [
            'client_id' => self::config($google ? 'GOOGLE_ID' : 'META_ID'),
            'client_secret' => self::config($google ? 'GOOGLE_SECRET' : 'META_SECRET'),
            'redirect_uri' => $session['redirect'],
            'code' => $code,
        ];
        if ($google) {
            $client += ['grant_type' => 'authorization_code', 'code_verifier' => $session['verifier']];
            $token = self::request_json('https://oauth2.googleapis.com/token', ['method' => 'POST', 'body' => $client]);
        } else {
            $base = 'https://graph.facebook.com/' . self::config('META_VERSION');
            $token = self::request_json($base . '/oauth/access_token?' . http_build_query($client, '', '&', PHP_QUERY_RFC3986));
        }
        $access = $token['access_token'] ?? '';
        if (!is_string($access) || $access === '' || strlen($access) > 4096 || preg_match('/[\r\n]/', $access)) return null;
        $headers = ['Authorization' => 'Bearer ' . $access];
        if ($google) {
            $profile = self::request_json('https://openidconnect.googleapis.com/v1/userinfo', ['headers' => $headers]);
            $url = $profile['picture'] ?? '';
        } else {
            $query = ['fields' => 'picture.width(256).height(256)',
                'appsecret_proof' => hash_hmac('sha256', $access, self::config('META_SECRET'))];
            $profile = self::request_json($base . '/me?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986), ['headers' => $headers]);
            $url = $profile['picture']['data']['url'] ?? '';
        }
        return self::download_photo($url, $google);
    }

    private static function download_photo($url, $google) {
        $hosts = $google ? '/^(?:[a-z0-9-]+\.)*googleusercontent\.com$/D'
            : '/^(?:[a-z0-9-]+\.)*(?:fbcdn\.net|fbsbx\.com)$/D';
        $bytes = '';
        for ($attempt = 0; $attempt < 3; $attempt++) {
            if (!is_string($url) || strlen($url) > 4096) return null;
            $parts = wp_parse_url($url);
            $host = strtolower($parts['host'] ?? '');
            if (($parts['scheme'] ?? '') !== 'https' || !preg_match($hosts, $host)
                    || isset($parts['user']) || isset($parts['pass']) || isset($parts['port'])) return null;
            $response = wp_safe_remote_get($url, [
                'timeout' => 8, 'redirection' => 0, 'limit_response_size' => self::MAX_PHOTO + 1,
            ]);
            if (is_wp_error($response)) return null;
            $status = wp_remote_retrieve_response_code($response);
            if ($status === 200) {
                $bytes = wp_remote_retrieve_body($response);
                break;
            }
            if (!in_array($status, [301, 302, 303, 307, 308], true)) return null;
            $url = wp_remote_retrieve_header($response, 'location');
        }
        if ($bytes === '' || strlen($bytes) > self::MAX_PHOTO) return null;
        $info = @getimagesizefromstring($bytes);
        if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)
                || $info[0] > 2048 || $info[1] > 2048) return null;
        return base64_encode($bytes);
    }

    private static function sms_start($owner, $number) {
        $result = self::twilio('Verifications', ['To' => $number, 'Channel' => 'sms']);
        $sid = $result['sid'] ?? '';
        if (($result['status'] ?? '') !== 'pending' || !is_string($sid) || !preg_match('/^VE[0-9a-fA-F]{32}$/D', $sid)) {
            return self::error('Le service SMS n’a pas accepté la demande.', 502);
        }
        if (!set_transient('ea_sms_' . $owner, $sid, self::TTL)) return self::error('Impossible de conserver la demande SMS.', 503);
        return self::reply(['pending' => true]);
    }

    private static function sms_confirm($owner, $code) {
        $key = 'ea_sms_' . $owner;
        $sid = get_transient($key);
        if (!is_string($sid)) {
            return get_option('ea_verified_' . $owner) ? self::reply(['verified' => true])
                : self::error('Demande un nouveau code.', 409);
        }
        $result = self::twilio('VerificationCheck', ['VerificationSid' => $sid, 'Code' => $code]);
        if (($result['status'] ?? '') !== 'approved') return self::error('Code incorrect ou expiré.', 422);
        $verified = 'ea_verified_' . $owner;
        if (!get_option($verified) && !add_option($verified, 1, '', false) && !get_option($verified)) {
            return self::error('Impossible d’enregistrer la vérification.', 503);
        }
        delete_transient($key);
        return self::reply(['verified' => true]);
    }

    private static function twilio($route, $body) {
        $url = 'https://verify.twilio.com/v2/Services/' . self::config('TWILIO_SERVICE') . '/' . $route;
        return self::request_json($url, [
            'method' => 'POST', 'body' => $body,
            'headers' => ['Authorization' => 'Basic ' . base64_encode(self::config('TWILIO_ACCOUNT') . ':' . self::config('TWILIO_TOKEN'))],
        ]);
    }

    private static function request_json($url, $args = []) {
        $response = wp_safe_remote_request($url, $args + ['timeout' => 8, 'redirection' => 0, 'limit_response_size' => 32768]);
        if (is_wp_error($response)) return [];
        $status = wp_remote_retrieve_response_code($response);
        if ($status < 200 || $status >= 300) return [];
        $body = json_decode(wp_remote_retrieve_body($response), true);
        return is_array($body) ? $body : [];
    }

    private static function configured(...$names) {
        foreach ($names as $name) if (self::config($name) === '') return false;
        return true;
    }

    private static function config($name) {
        $name = 'ENTRE_AMIS_' . $name;
        return defined($name) ? trim((string) constant($name)) : '';
    }

    private static function reply($data) { return new WP_REST_Response(['ok' => true] + $data, 200); }
    private static function error($message, $status) { return new WP_REST_Response(['error' => $message], $status); }
}
